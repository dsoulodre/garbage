#pragma once
#include <cstddef>

#define CL_UNUSED(var) (static_cast<void>(var))

#ifdef NDEBUG
	#define CL_DEBUG 0
#elif defined(DEBUG) || defined(_DEBUG)
	#define CL_DEBUG 1
#else
	#error "Cannot determine build type"
#endif

#define CL_RELEASE !CL_DEBUG


#if defined(_MSC_VER) || defined(_WIN32)
	#define CL_WINDOWS_BUILD 1
#elif defined(__linux__)
	#define CL_LINUX_BUILD 1
#else
	#error "Unsupported platform"
#endif // defined(_MSC_VER) || defined(_WIN32)

#ifndef CL_WINDOWS_BUILD
#define CL_WINDOWS_BUILD 0
#endif // !defined(CL_WINDOWS_BUILD)

#ifndef CL_LINUX_BUILD
#define CL_LINUX_BUILD 0
#endif // !defined(CL_LINUX_BUILD)

namespace CamdenLabs
{
	using SampleType = double;
	namespace Constants
	{
		constexpr double defaultSampleRate = 48000.0;

		constexpr size_t defaultBufferSize = 480;

		constexpr double minFrequency = 10.0;
		constexpr double maxFrequency = 20000.0;

		constexpr int numInputs = 2;
		constexpr int numOutputs = 4;

		constexpr size_t numBuiltInPresets = 8;
	} // namespace Constants
} // namespace CamdenLabs