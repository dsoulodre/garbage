/*
  ================================================================================
  *      File                                      AudioComponent.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "Helpers/AudioParameter.h"

#include <vector>

namespace CamdenLabs
{

class AudioComponent
{
public:
    virtual ~AudioComponent() = default;

    virtual void setParameterValue(int index, double value) = 0;

    virtual void setEnabled(bool shouldBeEnabled) = 0;

    virtual std::vector<AudioParameter*> getParameters() = 0;  

    virtual void setSampleRate(double newSampleRate) = 0;

    virtual int numOutputChannels() const = 0;
};



class AudioSourceComponent : public AudioComponent
{
public:
    virtual ~AudioSourceComponent() = default;

    virtual std::vector<std::vector<SampleType>> getNextBuffer(int bufferSize) = 0;
};



class AudioProcessorComponent : public AudioComponent
{
public:
    virtual ~AudioProcessorComponent() = default;

    virtual std::vector<SampleType>& processBlock(std::vector<SampleType>& input) = 0;
    virtual std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) = 0;

    virtual int numInputChannels() const = 0;
};

} // namespace CamdenLabs