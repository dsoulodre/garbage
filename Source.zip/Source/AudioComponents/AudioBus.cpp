/*
  ==============================================================================

    AudioBus.cpp
    Created: 13 Nov 2023 2:30:33pm
    Author:  14372

  ==============================================================================
*/

#include "AudioComponents/AudioBus.h"

namespace CamdenLabs
{

AudioBus::AudioBus()
    : mAccumulator(Constants::numOutputs)
{
    this->numOutputChannels();
}

AudioBus::AudioBus(const AudioBus& other)
{
    CLAssert(&other != this);
    std::scoped_lock lock(other.mMutex);
    this->mInputs = other.mInputs;
    this->mProcessing = other.mProcessing;
    this->mAccumulator = other.mAccumulator;
}

auto AudioBus::getParameters() -> std::vector<AudioParameter*>
{
    return {};
}

void AudioBus::setSampleRate(double newSampleRate)
{
    CL_UNUSED(newSampleRate);
}

int AudioBus::numOutputChannels() const
{
    int channels = 1;
    for (auto& it : mProcessing)
    {
        channels = std::max(channels, it->numOutputChannels());
    }

    return channels;
}

auto AudioBus::getNextBuffer(int bufferSize) -> std::vector<std::vector<SampleType>>
{
    std::scoped_lock lock(mMutex);
    mAccumulator.reset(bufferSize);
    for (auto it : mInputs)
    {
        mAccumulator.write(it->getNextBuffer(bufferSize));
    }
    std::vector<std::vector<SampleType>> audioSamples = mAccumulator.read();
    for (auto it : mProcessing)
    {
        it->processBlock(audioSamples);
    }
    return audioSamples;
}

void AudioBus::addInput(AudioSourceComponent& inputToAdd)
{
    std::scoped_lock lock(mMutex);
    mInputs.push_back(&inputToAdd);
}

void AudioBus::removeInput(AudioSourceComponent& inputToRemove)
{
    std::scoped_lock lock(mMutex);
    auto it = std::find(mInputs.begin(), mInputs.end(), &inputToRemove);
    if (it == mInputs.end())
    {
        return;
    }
    mInputs.erase(it);
}

void AudioBus::addProcessor(AudioProcessorComponent& processorToAdd)
{
    std::scoped_lock lock(mMutex);
    mProcessing.push_back(&processorToAdd);
}

void AudioBus::removeProcessor(AudioProcessorComponent& processorToRemove)
{
    std::scoped_lock lock(mMutex);
    auto it = std::find(mProcessing.begin(), mProcessing.end(), &processorToRemove);
    if (it == mProcessing.end())
    {
        return;
    }
    mProcessing.erase(it);
}

} // namespace CamdenLabs

