/*
  ================================================================================
  *      File                                         EffectsIMPL.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "Helpers/AudioParameter.h"
#include "AudioComponents/Effect.h"
#include "Helpers/SummingBlock.h"
#include "Helpers/SineGenerator.h"
#include "AudioComponents/FilterIMPL.h"

#include <vector>
#include <array>

namespace CamdenLabs
{

class NullEffect final : public Effect
{
public:
    NullEffect() = default;
    SampleType processSample(SampleType) override;
    std::vector<SampleType>& processBlock(std::vector<SampleType>&) override;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>&) override;
    void setParameterValue(int, double) override;
    void setEnabled(bool) override;
    void setSampleRate(double) override;
    std::vector<AudioParameter*> getParameters() override;
    int numInputChannels() const override;
    int numOutputChannels() const override;
};

class Phaser final : public Effect
{
public:
    enum class Parameters
    {
        Feedback = 1,
        Rate,
        Depth,
        WetGain
    };
    Phaser();

    void setParameterValue(int index, double value) override;

    SampleType processSample(SampleType inputSample) override;

    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override;

    void setFeedback(double value);
    void setRate(double value);
    void setDepth(double value);
    void setWetGain(double value);

    void setSampleRate(double newSampleRate) override;

    std::vector<AudioParameter*> getParameters() override;

    int numInputChannels() const override;
    int numOutputChannels() const override;

private:

    struct LFO : public SineGenerator
    {
        LFO()
        {
            //setWaveTable(Waveform::sineWave);
            //frequency.setRange(0.1, 5.0);
            setFrequency(0.1);
        }
        SampleType run()
        {
            return alpha + beta * getNextSample();
        }
        SampleType alpha{ 0.0f };
        SampleType beta{ 0.0f };
    }lowFrequencyOscillator;
    
    std::vector<AllPassFilter> allPassFilters;
    HighPassFilter highPassFilter;

    AudioParameter feedbackGain;
    AudioParameter rate;
    AudioParameter depth;
    AudioParameter wetGain;

    SampleType feedbackSample{ 0.0f };

    double mSampleRate{ Constants::defaultSampleRate };

};

//========================================================================================

class Compressor final : public Effect
{
public:

    enum class Parameters
    {
        Ratio = 1,
        Threshold,
        Knee,
        Attack,
        Release,
        Gain
    };

    Compressor();

    void setParameterValue(int index, double value) override;

    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override;

    std::vector<AudioParameter*> getParameters() override;

    void setSampleRate(double newSampleRate) override;

    void setRatio(double value);
    void setThreshold(double value);
    void setKnee(double value);
    void setAttack(double value);
    void setRelease(double value);
    void setGain(double value);

    int numInputChannels() const override;
    int numOutputChannels() const override;

    static constexpr double minGain = 0.5;
    static constexpr double maxGain = 2.0;

private:

    SampleType processSample(SampleType input) override;

    AudioParameter ratio;
    AudioParameter threshold;
    AudioParameter kneeWidth;
    AudioParameter attack;
    AudioParameter release;
    AudioParameter gain;

    double mAttackGain{ 1.0 };
    double mReleaseGain{ 1.0 };
    double lastCompressionGain{ 0.0 };

};

//========================================================================================

class Distortion final : public Effect
{
public:

    enum class Parameters
    {
        Type = 1,
        Drive,
        Mix
    };

    Distortion();

    void setParameterValue(int index, double value) override;

    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override;

    void setSampleRate(double newSampleRate) override;

    std::vector<AudioParameter*> getParameters() override;

    void setHardClip(bool useHardClip);

    void setDrive(double value);

    void setMix(double value);

    int numInputChannels() const override;
    int numOutputChannels() const override;

private:

    SampleType processSample(SampleType sample) override;

    SampleType getSampleHardClip(SampleType input);
    SampleType getSampleSoftClip(SampleType input);

    AudioParameter hardClip;
    AudioParameter drive;
    AudioParameter mix;

};

//========================================================================================

class BitCrusher final : public Effect
{
public:

    enum class Parameters
    {
        Drive = 1,
        Mix
    };

    BitCrusher();

    void setParameterValue(int index, double value) override;

    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override;

    void setSampleRate(double newSampleRate) override;

    std::vector<AudioParameter*> getParameters() override;

    void setDrive(double value);

    void setMix(double value);

    int numInputChannels() const override;
    int numOutputChannels() const override;

private:

    SampleType processSample(SampleType input) override;

    AudioParameter drive;
    AudioParameter mix;


};

//========================================================================================

class Chopper final : public Effect
{
public:

    enum class Parameters
    {
        Rate = 1,
        DutyCycle,
        Depth,
        Smoothing
    };

    Chopper();

    void setParameterValue(int index, double value) override;

    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override;

    void setSampleRate(double newSampleRate) override;

    std::vector<AudioParameter*> getParameters() override;

    void setRate(double value);

    void setDutyCycle(double value);

    void setDepth(double value);

    void setSmoothing(double value);

    int numInputChannels() const override;
    int numOutputChannels() const override;

private:

    SampleType processSample(SampleType input) override;

    int period{ 0 };
    int chopCount{ 0 };
    int onCount{ 0 };

    // Smoothing
    float alpha{ 1.f };
    float beta{0.f};
    float chopGain{ 0.f };

    AudioParameter rate;
    AudioParameter dutyCycle;
    AudioParameter depth;
    AudioParameter smoothing;

    double mSampleRate{ Constants::defaultSampleRate };
};

//========================================================================================

class Expander final : public Effect
{
public:

    enum class Parameters
    {
        Size = 1,
        Mix
    };

    Expander();

    void setParameterValue(int index, double value) override;

    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override;

    void setSampleRate(double newSampleRate) override;

    std::vector<AudioParameter*> getParameters() override;

    void setSize(double value);

    void setMix(double value);

    int numInputChannels() const override;
    int numOutputChannels() const override;

private:

    struct LFO : private SineGenerator
    {
        LFO();
        void setOffset(double phaseOffset);
        void setSampleRate(double sampleRate);
        SampleType run();
    };

    struct DelayTap
    {
        int maxDelay{};
        int currentDelay{ 0 };
        SampleType gain{ 0.f };
        int readPtr{ 0 };

        LFO lfo;
    };

    // No mono processing
    SampleType processSample(SampleType) override { return 0.f; }

    std::pair<SampleType, SampleType> processSample(SampleType& inputLeft, SampleType& inputRight);

    static constexpr size_t delayBufferSize = 1 << 16;
    static constexpr size_t numTaps = 4;
    static constexpr int maxDelayAt48k[numTaps] = { 5520, 6513, 7686, 9069 };

    int writePtr{ 0 };

    std::array<std::array<DelayTap, numTaps>, 2> delayTaps;

    std::vector<std::vector<SampleType>> delayBuffer;

    AudioParameter size;
    AudioParameter mix;

    double mSampleRate{ Constants::defaultSampleRate };
};

//========================================================================================

class Chorus final : public Effect
{
public:

    enum class Parameters
    {
        Rate = 1,
        Depth,
        Mix
    };

    Chorus();

    void setParameterValue(int index, double value) override;

    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override;

    void setRate(double value);

    void setDepth(double value);

    void setMix(double value);

    std::vector<AudioParameter*> getParameters() override;

    void setSampleRate(double newSampleRate) override;

    int numInputChannels() const override;
    int numOutputChannels() const override;

private:

    // No mono processing
    SampleType processSample(SampleType) override { return 0.f; }

    std::pair<SampleType, SampleType> processSample(SampleType& inputLeft, SampleType& inputRight);

    static constexpr int chorusBufferSize = 2400;
    static constexpr int maxDelay = 1440;
    static constexpr int numTaps = 4;
    static constexpr float minRate = 0.1f;
    static constexpr float maxRate = 7.f;
    static constexpr float freqDelta = 0.091f; // Factor of difference between left and right channel rates

    struct DelayTap
    {
        int delay{ maxDelay / 2 };
        int readPtr{ maxDelay / 2 };
        float phase{ 0.f };
    };

    std::array<std::array<DelayTap, numTaps>, 2> delayTaps;

    std::vector<std::vector<SampleType>> delayBuffer;

    std::pair<SampleType, SampleType> modulationFreq{ 0.5f, 6.3f };

    int writePtr{ 0 };

    size_t timer{ 0 };

    AudioParameter rate;
    AudioParameter depth;
    AudioParameter mix;

    double mSampleRate{ Constants::defaultSampleRate };
};

} // namespace CamdenLabs