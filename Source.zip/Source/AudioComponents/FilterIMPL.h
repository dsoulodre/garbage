/*
  ================================================================================
  *      File                                          FilterIMPL.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "Helpers/AudioParameter.h"
#include "AudioComponents/Filter.h"
#include "Helpers/DelayBlock.h"

#include <vector>
#include <array>

namespace CamdenLabs
{

class Biquad : public Filter
{
public:

    Biquad();
    virtual ~Biquad() = default;

    SampleType processSample(SampleType inputSample) final;
    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) final;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) final;

    void setSampleRate(double newSampleRate) final;

    int numOutputChannels() const final;

    void setFrequency(double value);

    auto getCoefficients() const -> std::pair<std::array<double, 3>, std::array<double, 3>>;

    double getFrequency() const;

protected:

    virtual void calculateCoefficients() = 0;
    void normalizeCoefficients();

    AudioParameter frequency;

    std::array<double, 3> aCoeffs;
    std::array<double, 3> bCoeffs;

    double mSampleRate{ Constants::defaultSampleRate };

private:

    std::array<double, 3> yStates;
    std::array<double, 3> xStates;
};

//========================================================================================

class LowPassFilter final : public Biquad
{
public:
    enum class Parameters
    {
        Cutoff = 1,
        Resonance
    };

    LowPassFilter();
    void setParameterValue(int index, double value) override;
    void setFilterQ(double value);

    std::vector<AudioParameter*> getParameters() override;

private:

    void calculateCoefficients() override;

    AudioParameter qFactor;
};

//========================================================================================

class HighPassFilter final : public Biquad
{
public:
    enum class Parameters
    {
        Cutoff = 1,
        Resonance
    };
    HighPassFilter();

    void setParameterValue(int index, double value) override;
    void setFilterQ(double value);

    std::vector<AudioParameter*> getParameters() override;

private:

    void calculateCoefficients() override;

    AudioParameter qFactor;
};

//========================================================================================

class PeakFilter final : public Biquad
{
public:
    enum class Parameters
    {
        Frequency = 1,
        FilterQ,
        Gain
    };
    PeakFilter();

    void setParameterValue(int index, double value) override;
    void setFilterQ(double value);
    void setGain(double value);

    std::vector<AudioParameter*> getParameters() override;

private:
    void calculateCoefficients() override;

    AudioParameter qFactor;
    AudioParameter dbGain;
};

//========================================================================================

class BandPassFilter final : public Biquad
{
public:
    enum class Parameters
    {
        Frequency = 1,
        BandWidth
    };
    BandPassFilter();

    void setParameterValue(int index, double value) override;
    void setBandwidth(double value);

    std::vector<AudioParameter*> getParameters() override;

private:

    void calculateCoefficients() override;

    AudioParameter bandwidth;
};

//========================================================================================

class NotchFilter final : public Biquad
{
public:
    enum class Parameters
    {
        Frequency = 1,
        Width
    };
    NotchFilter();

    void setParameterValue(int index, double value) override;
    void setBandwidth(double value);

    std::vector<AudioParameter*> getParameters() override;

private:

    void calculateCoefficients() override;

    AudioParameter bandwidth;
};

//========================================================================================

class LowShelfFilter final : public Biquad
{
public:
    enum class Parameters
    {
        Frequency = 1,
        Slope,
        Gain
    };
    LowShelfFilter();

    void setParameterValue(int index, double value) override;
    void setShelfSlope(double value);
    void setGain(double value);

    std::vector<AudioParameter*> getParameters() override;

private:

    void calculateCoefficients() override;

    AudioParameter shelfSlope;
    AudioParameter dbGain;
};

//========================================================================================

class HighShelfFilter final : public Biquad
{
public:
    enum class Parameters
    {
        Frequency = 1,
        Slope,
        Gain
    };
    HighShelfFilter();

    void setParameterValue(int index, double value) override;
    void setShelfSlope(double value);
    void setGain(double value);

    std::vector<AudioParameter*> getParameters() override;

private:

    void calculateCoefficients() override;

    AudioParameter shelfSlope;
    AudioParameter dbGain;
};

//========================================================================================

class AllPassFilter final : public Filter
{
public:
    enum class Parameters
    {
        Gain = 1
    };
    AllPassFilter();

    void setParameterValue(int index, double value) override;
    void setGain(double value);

    SampleType processSample(SampleType inputSample) override;
    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override;

    std::vector<AudioParameter*> getParameters() override;

    void setSampleRate(double) override {}

    int numOutputChannels() const override;

private:

    SampleType xState{ 0.0f };
    SampleType yState{ 0.0f };
    SampleType delaySample{ 0.0f };

    AudioParameter gain;
};

//========================================================================================

class CombFilter final : public Filter
{
public:
    enum class Parameters
    {
        Pitch = 1,
        Damping,
        Feedback
    };
    CombFilter();

    void setParameterValue(int index, double value) override;
    void setPitch(double value);
    void setDamping(double value);
    void setFeedback(double value);

    SampleType processSample(SampleType inputSample) override;
    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override;

    std::vector<AudioParameter*> getParameters() override;

    void setSampleRate(double newSampleRate) override;

    int numOutputChannels() const override;

private:
    HighPassFilter hpf;
    LowPassFilter lpf;
    DelayBlock delay;
    SampleType yState{ 0.0f };

    AudioParameter pitch;
    AudioParameter damping;
    AudioParameter feedbackGain;
};

} // namespace CamdenLabs
