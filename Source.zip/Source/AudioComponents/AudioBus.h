/*
  ================================================================================
  *      File                                            AudioBus.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "AudioComponents/AudioComponent.h"
#include "AudioComponents/PostProcessingBlock.h"
#include "Helpers/SummingBlock.h"
#include "Helpers/CLAssert.h"

#include <mutex>


namespace CamdenLabs
{

/** Simple wrapper class for a post-processing block that keeps track of inputs. Allows getNextBuffer() to be called and handles
* combining the input signals and processing them.
*/

class AudioBus final : public AudioSourceComponent
{
public:

	AudioBus();

	AudioBus(const AudioBus& other);

	void setParameterValue(int, double) override {}

	void setEnabled(bool) override {}

	auto getParameters() -> std::vector<AudioParameter*> override;

	void setSampleRate(double newSampleRate) override;

	int numOutputChannels() const override;

	auto getNextBuffer(int bufferSize) -> std::vector<std::vector<SampleType>> override;

	void addInput(AudioSourceComponent& inputToAdd);

	void removeInput(AudioSourceComponent& inputToRemove);

	void addProcessor(AudioProcessorComponent& processorToAdd);

	void removeProcessor(AudioProcessorComponent& processToRemove);

private:

	mutable std::mutex mMutex;
	std::vector<AudioSourceComponent*> mInputs;
	std::vector<AudioProcessorComponent*> mProcessing;
	SummingBlock<> mAccumulator;

};

} // namespace CamdenLabs
