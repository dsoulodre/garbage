/*
  ================================================================================
  *      File                             PostProcessingComponent.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "AudioComponents/AudioComponent.h"

#include <memory>
#include <vector>
#include <mutex>

namespace CamdenLabs
{

class PostProcessingComponent : public AudioProcessorComponent
{
public:

    enum class ComponentType
    {
        LowpassFilter = 1,
        HighpassFilter,
        PeakFilter,
        BandpassFilter,
        NotchFilter,
        LowShelfFilter,
        HighShelfFilter,
        AllPassFilter,
        CombFilter,
        Phaser,
        Compressor,
        Distortion,
        BitCrusher,
        Chopper,
        Expander,
        Chorus
    };
    static constexpr int numComponentTypes = 18;

    PostProcessingComponent(ComponentType type, int numChannels = 2 );

    // Used to set component type through setParameterValue()
    static constexpr int componentTypeParameterIndex = 15;

    static std::unique_ptr<AudioProcessorComponent> createProcessorComponent(ComponentType type);

    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override;

    void setParameterValue(int index, double value) override;

    std::vector<AudioParameter*> getParameters() override;

    void setSampleRate(double newSampleRate) override;

    void setEnabled(bool shouldBeEnabled) override;

    void setNumChannels(unsigned int numChannels);
    
    int numInputChannels() const override;
    int numOutputChannels() const override;

    bool isEnabled() const;

    ComponentType componentType() const;

private:

    std::vector<std::unique_ptr<AudioProcessorComponent>> components;
    std::mutex ioMutex;

    int mNumChannels{ 0 };
    int channelsPerComponent{ 1 };

    ComponentType currentType;

    bool mEnabled{ true };
};


struct NullProcessingComponent final : public AudioProcessorComponent
{
    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override { return input; }
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override { return input; }
    void setParameterValue(int, double) override {}
    void setEnabled(bool) override {}

    std::vector<AudioParameter*> getParameters() override { return {}; }

    int numOutputChannels() const override { return 1; }
};


} // namespace CamdenLabs
