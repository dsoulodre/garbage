/*
  ================================================================================
  *      File                                       EffectsIMPL.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "EffectsIMPL.h"
#include "Helpers/CLAssert.h"
#include "Helpers/Utility.h"

#include <cmath>

namespace CamdenLabs
{

constexpr float PI = 3.1415926535f;

// Factory
std::unique_ptr<Effect> Effect::createEffect(EffectType type)
{
    //using Type = Effect::EffectType;
    //switch (type)
    //{
    //    case Type::NoEffect:
    //    return std::make_unique<Null
    //}

    CL_UNUSED(type);

    return nullptr;
}

// Null Effect
//===========================================================================================================

SampleType NullEffect::processSample(SampleType input)
{
    return input;
}

std::vector<SampleType>& NullEffect::processBlock(std::vector<SampleType>& input)
{
    return input;
}

std::vector<std::vector<SampleType>>& NullEffect::processBlock(std::vector<std::vector<SampleType>>& input)
{
    return input;
}

void NullEffect::setParameterValue(int, double)
{

}

void NullEffect::setEnabled(bool)
{

}

void NullEffect::setSampleRate(double)
{

}

std::vector<AudioParameter*> NullEffect::getParameters()
{
    return {};
}

int NullEffect::numInputChannels() const
{
    return 1;
}

int NullEffect::numOutputChannels() const
{
    return 1;
}


// Phaser
//===========================================================================================================

Phaser::Phaser()
    :   allPassFilters(4)
{
    highPassFilter.setFrequency(125.f);
    lowFrequencyOscillator.alpha = 0.95f - depth.toFloat() / 2.0f;
    lowFrequencyOscillator.beta = depth.toFloat() / 2.0f;

    feedbackGain.setRange(0.0, -0.75);
    rate.setRange(0.1, 5.0);
    depth.setRange(0.0, 0.85);

    feedbackGain.setID(Parameters::Feedback);
    rate.setID(Parameters::Rate);
    depth.setID(Parameters::Depth);
    wetGain.setID(Parameters::WetGain);
}

void Phaser::setParameterValue(int index, double value)
{
    if (value < 0.0f || value > 1.0f) 
    {
        CLAssert(0);
        return;
    }
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Feedback:
        feedbackGain.setValue(value);
        break;

    case Parameters::Rate:
        rate.setValue(value);
        lowFrequencyOscillator.setFrequency(rate);
        break;

    case Parameters::Depth:
        depth.setValue(value);
        lowFrequencyOscillator.alpha = 0.95f - depth.toFloat() / 2.0f;
        lowFrequencyOscillator.beta = depth.toFloat() / 2.0f;
        break;

    case Parameters::WetGain:
        wetGain.setValue(value);
        break;
    }
}

void Phaser::setFeedback(double value)
{
    feedbackGain.setValueUnchecked(value);
}

void Phaser::setRate(double value)
{
    rate.setValueUnchecked(value);
    lowFrequencyOscillator.setFrequency(rate, mSampleRate);
}

void Phaser::setDepth(double value)
{
    depth.setValueUnchecked(value);
    lowFrequencyOscillator.alpha = 0.95f - depth.toFloat() / 2.0f;
    lowFrequencyOscillator.beta = depth.toFloat() / 2.0f;
}

void Phaser::setWetGain(double value)
{
    wetGain.setValueUnchecked(value);
}

void Phaser::setSampleRate(double newSampleRate)
{
    for (auto& it : allPassFilters)
    {
        it.setSampleRate(newSampleRate);
    }
    highPassFilter.setSampleRate(newSampleRate);

    double lfoFreq = lowFrequencyOscillator.frequency(mSampleRate);
    lowFrequencyOscillator.setFrequency(lfoFreq, newSampleRate);

    mSampleRate = newSampleRate;
}

std::vector<AudioParameter*> Phaser::getParameters()
{
    return std::vector<AudioParameter*>{&feedbackGain, &rate, &depth, &wetGain};
}

SampleType Phaser::processSample(SampleType inputSample)
{
    SampleType temp = highPassFilter.processSample(inputSample) + feedbackSample;
    SampleType lfoOutput = lowFrequencyOscillator.run();

    for (auto& apf : allPassFilters)
    {
        apf.setGain(lfoOutput);
        temp = apf.processSample(temp);
    }
       
    feedbackSample = temp * feedbackGain.toFloat(); // -0.75 <= feedBack <= 0

    return inputSample + temp * wetGain.toFloat(); // 0 <= wetGain <= 1

    // For constistent output level :
    // return inputSample * (1.0f - wetGain) + temp * wetGain;
}

std::vector<SampleType>& Phaser::processBlock(std::vector<SampleType>& input)
{
    for (auto& it : input)
    {
        it = processSample(it);
    }
    return input;
}

std::vector<std::vector<SampleType>>& Phaser::processBlock(std::vector<std::vector<SampleType>>& input)
{
    // This class cannot process multiple channels at once
    CLAssert(input.size() == 1);
    
    input[0] = processBlock(input[0]);
    return input;
}

int Phaser::numInputChannels() const
{
    return 1;
}

int Phaser::numOutputChannels() const
{
    return 1;
}

// Compressor
//===========================================================================================================

Compressor::Compressor()
{
    ratio.setRange(1.0, 10.0);
    threshold.setRange(-40.0, 0.0);
    kneeWidth.setRange(0.0, 20.0);
    attack.setRange(0.1, 100.0);
    release.setRange(30.0, 1000.0);
    gain.setRange(0.5, 2.0);

    gain.setDefaultValue(1.0);

    ratio.setID(Parameters::Ratio);
    threshold.setID(Parameters::Threshold);
    kneeWidth.setID(Parameters::Knee);
    attack.setID(Parameters::Attack);
    release.setID(Parameters::Release);
    gain.setID(Parameters::Gain);
}

void Compressor::setParameterValue(int index, double value)
{
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Ratio:
        setRatio(ratio.denormalize(value));
        break;

    case Parameters::Threshold:
        setThreshold(threshold.denormalize(value));
        break;

    case Parameters::Knee:
        setKnee(kneeWidth.denormalize(value));
        break;

    case Parameters::Attack:
        setAttack(attack.denormalize(value));
        break;

    case Parameters::Release:
        setRelease(release.denormalize(value));
        break;

    case Parameters::Gain:
        setGain(gain.denormalize(value));
        break;
    }
}

std::vector<SampleType>& Compressor::processBlock(std::vector<SampleType>& input)
{
    for (auto& it : input)
    {
        it = processSample(it);
    }
    return input;
}

std::vector<std::vector<SampleType>>& Compressor::processBlock(std::vector<std::vector<SampleType>>& input)
{
    // This class cannot process multiple channels at once
    CLAssert(input.size() == 1);

    input[0] = processBlock(input[0]);
    return input;
}

std::vector<AudioParameter*> Compressor::getParameters()
{
    return { &ratio, &threshold, &kneeWidth, &attack, &release, &gain };  
}

void Compressor::setSampleRate(double newSampleRate)
{
    CL_UNUSED(newSampleRate);
}

void Compressor::setRatio(double value)
{
    ratio.setValueUnchecked(value);
}

void Compressor::setThreshold(double value)
{
    threshold.setValueUnchecked(value);
}

void Compressor::setKnee(double value)
{
    kneeWidth.setValueUnchecked(value);
}

void Compressor::setAttack(double value)
{
    attack.setValueUnchecked(value);
    mAttackGain = std::exp(-1.0 / (attack * 48.0));
}

void Compressor::setRelease(double value)
{
    release.setValueUnchecked(value);
    mReleaseGain = std::exp(-1.0 / (release * 48.0));
}

void Compressor::setGain(double value)
{
    gain.setValueUnchecked(value);
}

int Compressor::numInputChannels() const
{
    return 1;
}

int Compressor::numOutputChannels() const
{
    return 1;
}

SampleType Compressor::processSample(SampleType input)
{
    static constexpr auto zTol = static_cast<SampleType>(0.000001);

    auto inputdB = 20.f * std::log10(std::abs(input) + zTol);

    auto sideChainGain = inputdB;

    if(std::abs(threshold - inputdB) < kneeWidth / 2.0)
    {
        sideChainGain = static_cast<float>(inputdB + (1.0 / ratio - 1.0) * (inputdB - threshold + kneeWidth / 2.0) / (2.0 * kneeWidth));
    }
    else if (inputdB > (threshold + kneeWidth / 2.0))
    {
        sideChainGain = static_cast<float>(threshold + (inputdB - threshold) * 1.0 / ratio);
    }

    float compressionGain = static_cast<float>(sideChainGain - inputdB);

    if (compressionGain < lastCompressionGain)
    {
        compressionGain = static_cast<float>(mAttackGain * lastCompressionGain + (1.f - mAttackGain) * compressionGain);
    }
    else
    {
        compressionGain = static_cast<float>(mReleaseGain * lastCompressionGain + (1.f - mReleaseGain) * compressionGain);
    }

    lastCompressionGain = compressionGain;

    float linearGain = std::pow(10.f, compressionGain / 20.f);

    return input * linearGain * gain.toFloat();
}

// Distortion
//===========================================================================================================

Distortion::Distortion()
{
    hardClip.setDefaultValue(1.0);


    drive.setRange(1.0, 10.0);
    mix.setDefaultValue(0.5);

    hardClip.setID(Parameters::Type);
    drive.setID(Parameters::Drive);
    mix.setID(Parameters::Mix);
}

void Distortion::setParameterValue(int index, double value)
{
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Type:
        setHardClip(hardClip.denormalize(value));
        break;

    case Parameters::Drive:
        setDrive(drive.denormalize(value));
        break;

    case Parameters::Mix:
        setMix(mix.denormalize(value));
        break;
    }
}

void Distortion::setHardClip(bool useHardClip)
{
    hardClip.setValueUnchecked(useHardClip);
}

void Distortion::setDrive(double value)
{
    drive.setValueUnchecked(value);
}

void Distortion::setMix(double value)
{
    mix.setValueUnchecked(value);
}

std::vector<SampleType>& Distortion::processBlock(std::vector<SampleType>& input)
{

    //auto&& getSample = (hardClip.toBool()) ? getSampleHardClip : getSampleSoftClip;
    //
    //for (auto& it : input)
    //{
    //    getSample(it);
    //}

    if (hardClip.toBool())
    {
        for (auto& it : input)
        {
            it = getSampleHardClip(it);
        }
    }
    else
    {
        for (auto& it : input)
        {
            it = getSampleSoftClip(it);
        }
    }
    return input;
}

std::vector<std::vector<SampleType>>& Distortion::processBlock(std::vector<std::vector<SampleType>>& input)
{
    // This class cannot process multiple channels at once
    CLAssert(input.size() == 1);

    input[0] = processBlock(input[0]);
    return input;
}

void Distortion::setSampleRate(double newSampleRate)
{
    CL_UNUSED(newSampleRate);
}

std::vector<AudioParameter*> Distortion::getParameters()
{
    return { &hardClip, &drive, &mix };
}

int Distortion::numInputChannels() const
{
    return 1;
}

int Distortion::numOutputChannels() const
{
    return 1;
}

SampleType Distortion::processSample(SampleType sample)
{
    return (this->hardClip.toBool()) ? getSampleHardClip(sample) : getSampleSoftClip(sample);
}

SampleType Distortion::getSampleHardClip(SampleType input)
{
    SampleType sample{};

    if (input > (1.f / drive.toFloat()))
    {
        sample = 1.f / drive.toFloat();
    }
    else if (input < (-1.f / drive.toFloat()))
    {
        sample = -1.f / drive.toFloat();
    }
    else
    {
        sample = input;
    }

    SampleType dry = (1.f - mix.toFloat()) * input;
    SampleType wet = mix.toFloat() * sample * drive.toFloat() / 2.f;

    return dry + wet;
}

SampleType Distortion::getSampleSoftClip(SampleType input)
{
    SampleType sample = std::tanh(input * drive) / drive;
    
    SampleType dry = (1.f - mix.toFloat()) * input;
    SampleType wet = mix * sample * drive / 2.0;

    return dry + wet;
}

// Bit Crusher
//===========================================================================================================

BitCrusher::BitCrusher()
{
    drive.setRange(1.0, 20.0);
    mix.setDefaultValue(0.5);

    drive.setID(Parameters::Drive);
    mix.setID(Parameters::Mix);
}

void BitCrusher::setParameterValue(int index, double value)
{
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Drive:
        setDrive(drive.denormalize(value));
        break;

    case Parameters::Mix:
        setMix(mix.denormalize(value));
        break;
    }
}

std::vector<SampleType>& BitCrusher::processBlock(std::vector<SampleType>& input)
{
    for (auto& it : input)
    {
        it = processSample(it);
    }
    return input;
}

std::vector<std::vector<SampleType>>& BitCrusher::processBlock(std::vector<std::vector<SampleType>>& input)
{
    // This class cannot process multiple channels at once
    CLAssert(input.size() == 1);

    input[0] = processBlock(input[0]);
    return input;
}

void BitCrusher::setSampleRate(double newSampleRate)
{
    CL_UNUSED(newSampleRate);
}

std::vector<AudioParameter*> BitCrusher::getParameters()
{
    return { &drive, &mix };
}

int BitCrusher::numInputChannels() const
{
    return 1;
}

int BitCrusher::numOutputChannels() const
{
    return 1;
}

void BitCrusher::setDrive(double value)
{
    drive.setValueUnchecked(value);
}

void BitCrusher::setMix(double value)
{
    mix.setValueUnchecked(value);
}

SampleType BitCrusher::processSample(SampleType input)
{
    SampleType temp = drive * 0.01;
    SampleType distortedSample = std::floor(input / temp) * temp;

    SampleType dry = (1.0 - mix) * input;
    SampleType wet = mix * distortedSample;

    return dry + wet;
}

// Chopper
//===========================================================================================================

Chopper::Chopper()
{
    rate.setRange(1.0, 200.0);
    rate.setExponential(0.3);

    dutyCycle.setDefaultValue(0.5);

    smoothing.setRange(0.0, 100.0);

    rate.setID(Parameters::Rate);
    dutyCycle.setID(Parameters::DutyCycle);
    depth.setID(Parameters::Depth);
    smoothing.setID(Parameters::Smoothing);

    setRate(rate.defaultValue());
    setDutyCycle(dutyCycle.defaultValue());
    setDepth(depth.defaultValue());
    setSmoothing(smoothing.defaultValue());
}

void Chopper::setParameterValue(int index, double value)
{
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Rate:
        setRate(rate.denormalize(value));
        break;

    case Parameters::DutyCycle:
        setDutyCycle(dutyCycle.denormalize(value));
        break;

    case Parameters::Depth:
        setDepth(depth.denormalize(value));
        break;

    case Parameters::Smoothing:
        setSmoothing(smoothing.denormalize(value));
        break;
    }
}

std::vector<SampleType>& Chopper::processBlock(std::vector<SampleType>& input)
{
    for (auto& it : input)
    {
        it = processSample(it);
    }
    return input;
}

std::vector<std::vector<SampleType>>& Chopper::processBlock(std::vector<std::vector<SampleType>>& input)
{
    // This class cannot process multiple channels at once
    CLAssert(input.size() == 1);

    input[0] = processBlock(input[0]);
    return input;
}

void Chopper::setSampleRate(double newSampleRate)
{
    mSampleRate = newSampleRate;

    // Update dependent values
    setRate(rate);
    setDutyCycle(dutyCycle);
}

std::vector<AudioParameter*> Chopper::getParameters()
{
    return { &rate, &dutyCycle, &depth, &smoothing };
}

int Chopper::numInputChannels() const
{
    return 1;
}

int Chopper::numOutputChannels() const
{
    return 1;
}

void Chopper::setRate(double value)
{
    rate.setValueUnchecked(value);
    period = static_cast<int>(mSampleRate / rate);
    onCount = static_cast<int>(period * dutyCycle);
}

void Chopper::setDutyCycle(double value)
{
    dutyCycle.setValueUnchecked(value);
    onCount = static_cast<int>(period * dutyCycle);
}

void Chopper::setDepth(double value)
{
    depth.setValueUnchecked(value);
}

void Chopper::setSmoothing(double value)
{
    smoothing.setValueUnchecked(value);
    beta = std::pow(0.9997f, (101.f - smoothing.toFloat()));
    alpha = 1.f - beta;
}

SampleType Chopper::processSample(SampleType input)
{
    if (chopCount >= period)
    {
        chopCount = 0;
    }

    if (chopCount < onCount)
    {
        chopGain = alpha + chopGain * beta;
    }
    else
    {
        chopGain = (1.f - depth.toFloat()) * alpha + chopGain * beta;
    }
    input *= chopGain;
    ++chopCount;

    return input;
}

// Expander
//===========================================================================================================


Expander::Expander()
    :   delayBuffer(2, std::vector<SampleType>(delayBufferSize, 0.f))
{
    size.setDefaultValue(0.13);
    mix.setDefaultValue(0.5);

    size.setID(Parameters::Size);
    mix.setID(Parameters::Mix);

    for (auto& it : delayTaps)
    {
        it[0].maxDelay = maxDelayAt48k[0];
        it[1].maxDelay = maxDelayAt48k[1];
        it[2].maxDelay = maxDelayAt48k[2];
        it[3].maxDelay = maxDelayAt48k[3];

        it[0].lfo.setOffset(0.f);
        it[1].lfo.setOffset(1.57079f);
        it[2].lfo.setOffset(3.14159f);
        it[3].lfo.setOffset(-1.57079f);
    }

    setSize(size.defaultValue());
}

void Expander::setParameterValue(int index, double value)
{
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Size:
        setSize(size.denormalize(value));
        break;

    case Parameters::Mix:
        setMix(mix.denormalize(value));
        break;
    }
}

std::vector<SampleType>& Expander::processBlock(std::vector<SampleType>& input)
{
    // This effect ONLY processes stereo
    CLAssert(0);
    std::vector<std::vector<SampleType>> dualMonoInput = { input, input };
    dualMonoInput = processBlock(dualMonoInput);
    input = dualMonoInput[0];
    return input;
}

std::vector<std::vector<SampleType>>& Expander::processBlock(std::vector<std::vector<SampleType>>& input)
{
    CLAssert(input.size() == 2);
    // This component ONLY processes stereo

    for (int i = 0; i < input[0].size(); ++i)
    {
        // Following usual pattern of using return value:
        auto samples = processSample(input[0][i], input[1][i]);
        input[0][i] = samples.first;
        input[1][i] = samples.second;
    }
    return input;
}

void Expander::setSampleRate(double newSampleRate)
{
    double scalingFactor = newSampleRate / 48'000.0;
    for (auto& chan : delayTaps)
    {
        for (size_t i = 0; i < numTaps; ++i)
        {
            auto& tap = chan[i];
            tap.lfo.setSampleRate(newSampleRate);
            tap.maxDelay = static_cast<int>(maxDelayAt48k[i] * scalingFactor);
        }
    }
    mSampleRate = newSampleRate;
    // Update delays
    setSize(size.get());
}

std::vector<AudioParameter*> Expander::getParameters()
{
    return { &size, &mix };
}

int Expander::numInputChannels() const
{
    return 2;
}

int Expander::numOutputChannels() const
{
    return 2;
}

void Expander::setSize(double value)
{
    size.setValueUnchecked(value);
    for (auto& it : delayTaps[0])
    {
        it.readPtr = it.currentDelay = static_cast<int>(it.maxDelay * size.get());
    }
    for (auto& it : delayTaps[1])
    {
        it.readPtr = it.currentDelay = static_cast<int>(it.maxDelay * size.get() * 0.9);
    }
    writePtr = 0;
}

void Expander::setMix(double value)
{
    mix.setValueUnchecked(value);
}

auto Expander::processSample(SampleType& inputLeft, SampleType& inputRight) -> std::pair<SampleType, SampleType>
{
    SampleType outputLeft = 0.f;
    SampleType outputRight = 0.f;

    delayBuffer[0][writePtr] = inputLeft;
    delayBuffer[1][writePtr] = inputRight;

    // Update gains
    for (auto& it : delayTaps)
    {
        for (auto& tap : it)
        {
            tap.gain = tap.lfo.run();
        }
    }

    for (int i = 0; i < numTaps; ++i)
    {
        auto readLeft  = delayTaps[0][i].readPtr;
        auto readright = delayTaps[1][i].readPtr;

        auto gainLeft = delayTaps[0][i].gain;
        auto gainRight = delayTaps[1][i].gain;

        auto leftSample = delayBuffer[0][readLeft];
        auto rightSample = delayBuffer[1][readright];

        outputLeft += gainLeft * (leftSample + rightSample);
        outputRight += gainRight * -1.f * (leftSample + rightSample);
    }

    //if constexpr (Utility::isPowerOfTwo(delayBufferSize))
    //{
    //    constexpr size_t mask = ~delayBufferSize;
    //    constexpr size_t dec = delayBufferSize - 1;
    //    writePtr += dec;
    //    writePtr &= mask;
    //}
    //else
    //{
    //    if (writePtr == 0)
    //    {
    //        writePtr = delayBufferSize;
    //    }
    //    --writePtr;
    //}

    writePtr -= 1;
    if (writePtr < 0)
    {
        writePtr = delayBufferSize - 1;
    }

    for (auto& it : delayTaps)
    {
        for (auto& tap : it)
        {
            tap.readPtr -= 1;
            if (tap.readPtr < 0)
            {
                tap.readPtr = delayBufferSize - 1;
            }
        }
    }

    return std::make_pair(inputLeft + mix.toFloat() * outputLeft, inputRight + mix.toFloat() * outputRight);
}

Expander::LFO::LFO()
{
    setFrequency(0.97);
}

void Expander::LFO::setOffset(double phaseOffset)
{
    constexpr double twoPi = 6.2831853071795864769;
    CLAssert(phaseOffset >= -1.0 * twoPi && phaseOffset <= twoPi);
    // Force positive value from modulo
    double tablePos = std::fmod(2.0 + phaseOffset / twoPi, 1.0);
    tableIndex = mTableSize * tablePos;
}

void Expander::LFO::setSampleRate(double sampleRate)
{
    setFrequency(0.97, sampleRate);
}

SampleType Expander::LFO::run()
{
    return SineGenerator::getNextSample();
}

// Chorus
//===========================================================================================================

Chorus::Chorus()
    :   delayBuffer(2, std::vector<SampleType>(chorusBufferSize, 0.f))
{
    rate.setRange(minRate, maxRate);

    rate.setDefaultValue(0.5);
    depth.setDefaultValue(0.5);
    mix.setDefaultValue(0.5);

    rate.setID(Parameters::Rate);
    depth.setID(Parameters::Depth);
    mix.setID(Parameters::Mix);

    float tempPhase = 2.f * PI / static_cast<float>(numTaps);

    for (int i = 0; i < numTaps; i++)
    {
        delayTaps[0][i].phase = static_cast<float>(i) * tempPhase;
        delayTaps[1][i].phase = static_cast<float>(i) * tempPhase + PI / 4.f;
    }
}

void Chorus::setParameterValue(int index, double value)
{
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Rate:
        setRate(rate.denormalize(value));
        break;

    case Parameters::Depth:
        setDepth(depth.denormalize(value));
        break;

    case Parameters::Mix:
        setMix(mix.denormalize(value));
        break;
    }
}

std::vector<SampleType>& Chorus::processBlock(std::vector<SampleType>& input)
{
    CLAssert(0);
    // This component only processes stereo

    std::vector<std::vector<SampleType>> dualMonoInput = { input, input };
    dualMonoInput = processBlock(dualMonoInput);
    input = dualMonoInput[0];
    return input;
}

std::vector<std::vector<SampleType>>& Chorus::processBlock(std::vector<std::vector<SampleType>>& input)
{
    CLAssert(input.size() == 2);

    for (int i = 0; i < input[0].size(); ++i)
    {
        auto samples = processSample(input[0][i], input[1][i]);
        input[0][i] = samples.first;
        input[1][i] = samples.second;
    }

    return input;
}

void Chorus::setRate(double value)
{
    rate.setValueUnchecked(value);
    modulationFreq.first = rate.toFloat();
    modulationFreq.second = rate.toFloat() * freqDelta;
}

void Chorus::setDepth(double value)
{
    depth.setValueUnchecked(value);
    auto read = static_cast<int>(depth * maxDelay);

    for (auto& tapChannels : delayTaps)
    {
        for (auto& tap : tapChannels)
        {
            tap.readPtr = tap.delay = read;
        }
    }
}

void Chorus::setMix(double value)
{
    mix.setValueUnchecked(value);
}

std::vector<AudioParameter*> Chorus::getParameters()
{
    return { &rate, &depth, &mix };
}

void Chorus::setSampleRate(double newSampleRate)
{
    mSampleRate = newSampleRate;
    timer = 0;
}

int Chorus::numInputChannels() const
{
    return 2;
}

int Chorus::numOutputChannels() const
{
    return 2;
}

auto Chorus::processSample(SampleType& inputLeft, SampleType& inputRight) -> std::pair<SampleType, SampleType>
{
    delayBuffer[0][writePtr] = inputLeft;
    delayBuffer[1][writePtr] = inputRight;

    float t = static_cast<float>(2.0f * PI / mSampleRate * timer++);
    float freqLeft = static_cast<float>(t * modulationFreq.first);
    float freqRight = static_cast<float>(t * modulationFreq.second);


    for (int i = 0; i < numTaps; i++)
    {
        auto& tapLeft = delayTaps[0][i];
        auto& tapRight = delayTaps[1][i];

        float phaseLeft = tapLeft.phase;
        float phaseRight = tapRight.phase;

        float sinLL = std::sin(freqLeft + phaseLeft);
        float sinRL = std::sin(freqRight + phaseLeft);
        float sinLR = std::sin(freqLeft + phaseRight);
        float sinRR = std::sin(freqRight + phaseRight);

        float tempReadLeft = (1.0f + sinLL) / 8.f + (1.0f + sinRL) / 4.f;
        tapLeft.readPtr = static_cast<int>(tempReadLeft * tapLeft.delay) + writePtr;

        float tempReadRight = (1.f + sinLR) / 8.f + (1.f + sinRR) / 4.f;
        tapRight.readPtr = static_cast<int>(tempReadRight * tapRight.delay) + writePtr;
    }

    for (auto& tapChannels : delayTaps)
    {
        for (auto& tap : tapChannels)
        {
            if (tap.readPtr >= chorusBufferSize)
            {
                tap.readPtr -= chorusBufferSize;
            }
            Utility::checkRange(tap.readPtr, 0, chorusBufferSize - 1);
        }
    }
    SampleType outputLeft = 0.f;
    SampleType outputRight = 0.f;

    for (size_t i = 0; i < 2; i++)
    {
        int readL = delayTaps[0][i].readPtr;
        int readR = delayTaps[1][i].readPtr;
        int readLP = delayTaps[0][i + 2].readPtr;
        int readRP = delayTaps[1][i + 2].readPtr;

        outputLeft += delayBuffer[0][readL] + 0.25f * delayBuffer[1][readRP];
        outputRight += delayBuffer[1][readR] + 0.25f * delayBuffer[0][readLP];
    }
    for (size_t i = 2; i < 4; i++)
    {
        int readL = delayTaps[0][i].readPtr;
        int readR = delayTaps[1][i].readPtr;
        int readLP = delayTaps[0][i - 2].readPtr;
        int readRP = delayTaps[1][i - 2].readPtr;

        outputLeft += delayBuffer[1][readR] + 0.25f * delayBuffer[0][readLP];
        outputRight += delayBuffer[0][readL] + 0.25f * delayBuffer[1][readRP];
    }

    writePtr -= 1;
    if (writePtr < 0)
    {
        writePtr = chorusBufferSize - 1;
    }

    outputLeft = outputLeft * mix.toFloat() + inputLeft;
    outputRight = outputRight * mix.toFloat() + inputRight;

    return { outputLeft, outputRight };
}

} // namespace CamdenLabs