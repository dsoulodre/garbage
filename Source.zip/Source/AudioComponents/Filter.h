/*
  ================================================================================
  *      File                                              Filter.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "AudioComponents/AudioComponent.h"

#include <vector>
#include <memory>

namespace CamdenLabs
{
	
class Filter : public AudioProcessorComponent
{
public:

	enum class FilterType
	{
		Lowpass,
		Highpass,
		Peak,
		Bandpass,
		Notch,
		LowShelf,
		HighShelf,
		AllPass,
		Comb
	};

	virtual ~Filter() = default;

	static std::unique_ptr<Filter> createFilter(FilterType filterType);

	// Filters cannot be disabled
	virtual void setEnabled(bool) override {}

	virtual SampleType processSample(SampleType inputSample) = 0;

	int numInputChannels() const final
	{
		return 1;
	}
};

} // namespace CamdenLabs