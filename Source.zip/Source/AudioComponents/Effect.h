/*
  ================================================================================
  *      File                                              Effect.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "AudioComponents/AudioComponent.h"

#include <vector>
#include <memory>

namespace CamdenLabs
{

class Effect : public AudioProcessorComponent
{
public:

    enum class EffectType
    {
        NoEffect = 1,
        Phaser,
        Compressor,
        Distortion,
        BitCrusher,
        Chopper,
        Expander,
        Chorus,
    };
    static constexpr int numEffectTypes = 8;

    virtual ~Effect() = default;

    static std::unique_ptr<Effect> createEffect(EffectType type);

    virtual void setEnabled(bool) override {}

    virtual SampleType processSample(SampleType inputSample) = 0;

};

} // namespace CamdenLabs