/*
  ================================================================================
  *      File                             PostProcessingComponent.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "AudioComponents/PostProcessingComponent.h"
#include "AudioComponents/FilterIMPL.h"
#include "AudioComponents/EffectsIMPL.h"
#include "Helpers/Utility.h"

#include <algorithm>

namespace CamdenLabs
{

// Factory method
std::unique_ptr<AudioProcessorComponent> PostProcessingComponent::createProcessorComponent(PostProcessingComponent::ComponentType type)
{
    using Type = ComponentType;
    switch (type)
    {
    case Type::LowpassFilter:
        return std::make_unique<LowPassFilter>();

    case Type::HighpassFilter:
        return std::make_unique<HighPassFilter>();

    case Type::PeakFilter:
        return std::make_unique<PeakFilter>();

    case Type::BandpassFilter:
        return std::make_unique<BandPassFilter>();

    case Type::NotchFilter:
        return std::make_unique<NotchFilter>();

    case Type::LowShelfFilter:
        return std::make_unique<LowShelfFilter>();

    case Type::HighShelfFilter:
        return std::make_unique<HighShelfFilter>();

    case Type::AllPassFilter:
        return std::make_unique<AllPassFilter>();

    case Type::CombFilter:
        return std::make_unique<CombFilter>();

    case Type::Phaser:
        return std::make_unique<Phaser>();

    case Type::Compressor:
        return std::make_unique<Compressor>();

    case Type::Distortion:
        return std::make_unique<Distortion>();

    case Type::BitCrusher:
        return std::make_unique<BitCrusher>();

    case Type::Chopper:
        return std::make_unique<Chopper>();

    case Type::Expander:
        return std::make_unique<Expander>();

    case Type::Chorus:
        return std::make_unique<Chorus>();

    default:
        CLAssert(0);
        return nullptr;
    }
}

PostProcessingComponent::PostProcessingComponent(ComponentType type, int numChannels)
{
    if (numChannels < 1 || numChannels > Constants::numOutputs)
    {
        CLAssert(0);
        numChannels = 1;
    }

    components.emplace_back(createProcessorComponent(type));
    channelsPerComponent = components[0]->numOutputChannels();

    if (numChannels < channelsPerComponent)
    {
        CLAssert(0);
        numChannels = channelsPerComponent;
    }

    if (numChannels % channelsPerComponent != 0)
    {
        CLAssert(0);
        numChannels -= numChannels % channelsPerComponent; // ?
    }

    for (int i = channelsPerComponent; i < numChannels; i += channelsPerComponent)
    {
        components.push_back(createProcessorComponent(type));
    }


    //components.resize(numChannels);
    //for (auto& it : components)
    //{
    //    it = createProcessorComponent(type);
    //}
    mNumChannels = numChannels;
    currentType = type;
}

std::vector<SampleType>& PostProcessingComponent::processBlock(std::vector<SampleType>& input)
{
    if (this->isEnabled())
    {
        std::scoped_lock<std::mutex> guard(ioMutex);

        // This function processes mono. If numOutputChannels() != 1 but channelsPerComponent == 1, audio will be processed correctly, but this is probably a mistake at some level
        CLAssert(numOutputChannels() == 1 || channelsPerComponent == 1);

        input = components[0]->processBlock(input);
    }
    return input;
}

std::vector<std::vector<SampleType>>& PostProcessingComponent::processBlock(std::vector<std::vector<SampleType>>& input)
{
    if (!this->isEnabled())
    {
        return input;
    }

    std::scoped_lock<std::mutex> guard(ioMutex);

    // Will still work, but this is probably unintentional
    CLAssert(input.size() >= this->numInputChannels() && input.size() >= this->numOutputChannels());

    int maxChan = std::min<int>(numOutputChannels(), static_cast<int>(input.size()));


    if (channelsPerComponent == 1)
    {
        for (int chan = 0; chan < maxChan; ++chan)
        {
            input[chan] = components[chan]->processBlock(input[chan]);
        }
    }
    else if (channelsPerComponent == 2)
    {
        maxChan -= maxChan % channelsPerComponent;

        for (int iChan = 0, iComp = 0; iChan < maxChan; iChan += channelsPerComponent, ++iComp)
        {
            std::vector<std::vector<SampleType>> temp = { input[iChan], input[iChan + 1] };
            temp = components[iComp]->processBlock(temp);
            input[iChan]     = std::move(temp[0]);
            input[iChan + 1] = std::move(temp[1]);
        }
    }
    else
    {
        CLAssert(0);
    }

    // More generic (agnostic to number of channels) way of doing it
#if 0
    if (maxChan % channelsPerComponent != 0)
    {
        CLAssert(0);
        maxChan -= maxChan % channelsPerComponent;
    }
    size_t iComp = 0;
    for (size_t iComp = 0; iComp < maxChan; iComp += channelsPerComponent)
    {
        auto& component = components[iComp];
        std::vector<std::vector<float>> temp(channelsPerComponent);

        for (size_t chan = iComp * channelsPerComponent; chan < channelsPerComponent; ++i)
        {
            temp.push_back(std::move(input[chan]));
        }
        component->processBlock(temp);

        for (size_t tempChan = 0; tempChan < channelsPerComponent; ++tempChan)
        {
            size_t inputChan = iComp * channelsPerComponent + tempChan;
            input[inputChan] = std::move(temp[tempChan]);
        }
    }
#endif

    return input;
}

void PostProcessingComponent::setParameterValue(int index, double value)
{
    std::scoped_lock<std::mutex> guard(ioMutex);
    for (auto& it : components)
    {
        it->setParameterValue(index, value);
    }
}

std::vector<AudioParameter*> PostProcessingComponent::getParameters()
{
    if (components.empty())
    {
        return std::vector<AudioParameter*>();
    }
    return components[0]->getParameters();

}

void PostProcessingComponent::setSampleRate(double newSampleRate)
{
    for (auto& it : components)
    {
        it->setSampleRate(newSampleRate);
    }
}

void PostProcessingComponent::setEnabled(bool shouldBeEnabled)
{
    std::scoped_lock<std::mutex> guard(ioMutex);
    mEnabled = shouldBeEnabled;
}

void PostProcessingComponent::setNumChannels(unsigned int numChannels)
{
    std::scoped_lock<std::mutex> guard(ioMutex);
    if (numChannels < 1 || numChannels > Constants::numOutputs)
    {
        CLAssert(0);
        return;
    }
    components.resize(numChannels);

    for (auto& it : components)
    {
        it = createProcessorComponent(currentType);
    }
}

int PostProcessingComponent::numInputChannels() const
{
    if (components.empty())
    {
        CLAssert(0);
        return 1;
    }

    int sum = 0;
    for (const auto& it : components)
    {
        sum += it->numInputChannels();
    }
    return sum;
}

int PostProcessingComponent::numOutputChannels() const
{
    if (components.empty())
    {
        CLAssert(0);
        return 1;
    }
    int sum = 0;
    for (const auto& it : components)
    {
        sum += it->numOutputChannels();
    }
    return sum;
}

bool PostProcessingComponent::isEnabled() const
{
    return mEnabled;
}

auto PostProcessingComponent::componentType() const -> PostProcessingComponent::ComponentType
{
    return currentType;
}

} // namespace CamdenLabs