/*
  ================================================================================
  *      File                                 PostProcessingBlock.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "AudioComponents/AudioComponent.h"
#include "AudioComponents/PostProcessingComponent.h"

#include <vector>
#include <memory>
#include <mutex>

namespace CamdenLabs
{


class PostProcessingBlock : public AudioProcessorComponent
{
public:

    PostProcessingBlock(int numChannels = 1);

    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override;

    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override;

    void setParameterValue(int, double) override {}

    std::vector<AudioParameter*> getParameters() override;

    void setSampleRate(double newSampleRate) override;

    void setNumChannels(int numChannels);

    void setEnabled(bool) override {}

    void addComponent(std::unique_ptr<PostProcessingComponent>&& newComponent);

    void removeComponent(PostProcessingComponent* componentPtr);

    void removeComponent(AudioComponent* componentPtr);

    std::vector<AudioComponent*> getComponents();

    int numInputChannels() const override;
    int numOutputChannels() const override;

private:
    std::vector<std::unique_ptr<PostProcessingComponent>> components;
    int mNumChannels{ 1 };

    std::mutex ioMutex;
};

}