/*
  ================================================================================
  *      File                               PostProcessingBlock.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "AudioComponents/PostProcessingBlock.h"
#include "Helpers/CLAssert.h"

#include <vector>
#include <memory>

namespace CamdenLabs
{

PostProcessingBlock::PostProcessingBlock(int numChannels)
    :   mNumChannels(numChannels)
{
    if (numChannels < 1)
    {
        CLAssert(0);
        numChannels = 1;
    }
    else if (numChannels > Constants::numOutputs)
    {
        CLAssert(0);
        numChannels = Constants::numOutputs;
    }

    mNumChannels = numChannels;
}

std::vector<SampleType>& PostProcessingBlock::processBlock(std::vector<SampleType>& input)
{
    std::scoped_lock<std::mutex> guard(ioMutex);
    for (auto& it : components)
    {
        input = it->processBlock(input);
    }
    return input;
}
std::vector<std::vector<SampleType>>& PostProcessingBlock::processBlock(std::vector<std::vector<SampleType>>& input)
{
    std::scoped_lock<std::mutex> guard(ioMutex);
    for (auto& it : components)
    {
        input = it->processBlock(input);
    }
    return input;
}

std::vector<AudioParameter*> PostProcessingBlock::getParameters()
{
    return std::vector<AudioParameter*>{};
}

void PostProcessingBlock::setSampleRate(double newSampleRate)
{
    std::scoped_lock<std::mutex> guard(ioMutex);
    for (auto& it : components)
    {
        it->setSampleRate(newSampleRate);
    }
}

void PostProcessingBlock::setNumChannels(int numChannels) 
{
    CLAssert(numChannels > 0);
    std::scoped_lock<std::mutex> guard(ioMutex);

    this->mNumChannels = numChannels;
    for (auto& it : components)
    {
        it->setNumChannels(numChannels);
    }
}

void PostProcessingBlock::addComponent(std::unique_ptr<PostProcessingComponent>&& newComponent)
{
    std::scoped_lock<std::mutex> guard(ioMutex);
    components.push_back(std::move(newComponent));
}

void PostProcessingBlock::removeComponent(PostProcessingComponent* componentPtr)
{
    std::scoped_lock<std::mutex> guard(ioMutex);
    auto predicate = [&, componentPtr](const std::unique_ptr<PostProcessingComponent>& comp) { return comp.get() == componentPtr; };
    auto it = std::find_if(components.begin(), components.end(), predicate);

    if (it == components.end())
    {
        CLAssert(0);
        return;
    }
    components.erase(it);
}

void PostProcessingBlock::removeComponent(AudioComponent* componentPtr)
{
    if (auto ptr = dynamic_cast<PostProcessingComponent*>(componentPtr))
    {
        removeComponent(ptr);
        return;
    }
    // Cast failed
    CLAssert(0);
    return;
}

std::vector<AudioComponent*> PostProcessingBlock::getComponents() 
{
    std::vector<AudioComponent*> audioComponents;
    for (auto& it : this->components)
    {
        audioComponents.push_back(it.get());
    }
    return audioComponents;
}

int PostProcessingBlock::numInputChannels() const
{
#if CL_DEBUG
    for (auto& it : components)
    {
        CLAssert(it->numInputChannels() == it->numOutputChannels() && it->numInputChannels() == mNumChannels);
    }
#endif
    return mNumChannels;
}

int PostProcessingBlock::numOutputChannels() const
{
#if CL_DEBUG
    for (auto& it : components)
    {
        CLAssert(it->numInputChannels() == it->numOutputChannels() && it->numInputChannels() == mNumChannels);
    }
#endif
    return mNumChannels;
}

} // namespace CamdenLabs

