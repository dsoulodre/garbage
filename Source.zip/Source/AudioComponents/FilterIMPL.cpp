/*
  ================================================================================
  *      File                                        FilterIMPL.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "AudioComponents/FilterIMPL.h"
#include "Helpers/CLAssert.h"
#include "Helpers/Utility.h"

#include <cmath>

constexpr double Pi = 3.1415926535897932384626;
constexpr float minFreq = CamdenLabs::Constants::minFrequency;
constexpr float maxFreq = CamdenLabs::Constants::maxFrequency;

namespace CamdenLabs
{
// Factory
std::unique_ptr<Filter> Filter::createFilter(FilterType filterType)
{
    switch (filterType)
    {
    case FilterType::Lowpass:
        return std::make_unique<LowPassFilter>();

    case FilterType::Highpass:
        return std::make_unique<HighPassFilter>();

    case FilterType::Peak:
        return std::make_unique<PeakFilter>();

    case FilterType::Bandpass:
        return std::make_unique<BandPassFilter>();

    case FilterType::Notch:
        return std::make_unique<NotchFilter>();

    case FilterType::LowShelf:
        return std::make_unique<LowShelfFilter>();

    case FilterType::HighShelf:
        return std::make_unique<HighShelfFilter>();

    case FilterType::AllPass:
        return std::make_unique<AllPassFilter>();

    case FilterType::Comb:
        return std::make_unique<CombFilter>();

    default:
        CLAssert(0);
        return nullptr;
    }
}

//========================================================================================
// Biquad

Biquad::Biquad()   
{
    frequency.setRange(minFreq, maxFreq);
    frequency.setExponential(0.2);
    frequency.setDefaultValue(500.0);

    aCoeffs.fill(0.f);
    bCoeffs.fill(0.f);
    xStates.fill(0.f);
    yStates.fill(0.f);
}

SampleType Biquad::processSample(SampleType inputSample)
{
    xStates[0] = inputSample;
    
    yStates[0] = xStates[0] * bCoeffs[0] 
               + xStates[1] * bCoeffs[1] 
               + xStates[2] * bCoeffs[2] 
               -
               ( yStates[1] * aCoeffs[1]
               + yStates[2] * aCoeffs[2] );
              
    xStates[2] = xStates[1];
    xStates[1] = xStates[0];

    yStates[2] = yStates[1];
    yStates[1] = yStates[0];

    return yStates[0];
}

std::vector<SampleType>& Biquad::processBlock(std::vector<SampleType>& input)
{
    for (auto& it : input)
    {
        it = processSample(it);
    }
    return input;
}

std::vector<std::vector<SampleType>>& Biquad::processBlock(std::vector<std::vector<SampleType>>& input)
{
    // This class cannot process multiple channels at once
    CLAssert(input.size() == 1);

    input[0] = processBlock(input[0]);
    return { input };
}

void Biquad::setSampleRate(double newSampleRate)
{
    mSampleRate = newSampleRate;
    calculateCoefficients();
}

int Biquad::numOutputChannels() const
{
    return 1;
}

void Biquad::setFrequency(double newFrequency)
{
    frequency.setValueUnchecked(newFrequency);
    calculateCoefficients();
}

auto Biquad::getCoefficients() const -> std::pair < std::array<double, 3>, std::array<double, 3>>
{
    return { aCoeffs, bCoeffs };
}

double Biquad::getFrequency() const
{
    return frequency;
}

void Biquad::normalizeCoefficients()
{
    aCoeffs[1] /= aCoeffs[0];
    aCoeffs[2] /= aCoeffs[0];
    bCoeffs[0] /= aCoeffs[0];
    bCoeffs[1] /= aCoeffs[0];
    bCoeffs[2] /= aCoeffs[0];
    aCoeffs[0] = 1.0;
}

//========================================================================================
// Low Pass

LowPassFilter::LowPassFilter()
{
    frequency.setID(Parameters::Cutoff);

    qFactor.setRange(0.1, 2.0);
    qFactor.setDefaultValue(0.707106781);
    qFactor.setID(Parameters::Resonance);

    calculateCoefficients();
}

void LowPassFilter::setParameterValue(int index, double value)
{
    CLAssert(value >= 0.f && value <= 1.f);
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Cutoff:
        frequency.setValue(value);
        break;

    case Parameters::Resonance:
        qFactor.setValue(value);
        break;

    default:
        return;
    }
    calculateCoefficients();
}

std::vector<AudioParameter*> LowPassFilter::getParameters()
{
    return std::vector<AudioParameter*>{&frequency, &qFactor};
}

void LowPassFilter::setFilterQ(double newFilterQ)
{
    qFactor.setValueUnchecked(newFilterQ);
    calculateCoefficients();
}

void LowPassFilter::calculateCoefficients()
{
    double omega = 2.0 * Pi / mSampleRate;
    double w0 = omega * frequency;
    double sinW0 = std::sin(w0);
    double cosW0 = std::cos(w0);
    double alpha = sinW0 / (2.0 * qFactor);

    bCoeffs[0] = (1.0 - cosW0) / 2.0;
    bCoeffs[1] =  1.0 - cosW0;
    bCoeffs[2] = (1.0 - cosW0) / 2.0;
    aCoeffs[0] =  1.0 + alpha;
    aCoeffs[1] = -2.0 * cosW0;
    aCoeffs[2] =  1.0 - alpha;

    normalizeCoefficients();
}

//========================================================================================
// High Pass

HighPassFilter::HighPassFilter()
{
    frequency.setID(Parameters::Cutoff);

    qFactor.setRange(0.1, 2.0);
    qFactor.setDefaultValue(0.707106781);
    qFactor.setID(Parameters::Resonance);

    calculateCoefficients();
}

void HighPassFilter::setParameterValue(int index, double value)
{
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Cutoff:
        frequency.setValue(value);
        break;

    case Parameters::Resonance:
        qFactor.setValue(value);
        break;

    default:
        CLAssert(0);
        return;
    }
    calculateCoefficients();
}

std::vector<AudioParameter*> HighPassFilter::getParameters() 
{
    return std::vector<AudioParameter*>{&frequency, &qFactor};
}

void HighPassFilter::setFilterQ(double newFilterQ)
{
    qFactor.setValueUnchecked(newFilterQ);
    calculateCoefficients();
}

void HighPassFilter::calculateCoefficients()
{
    double omega = 2.0 * Pi / mSampleRate;
    double w0 = omega * frequency;
    double sinW0 = std::sin(w0);
    double cosW0 = std::cos(w0);
    double alpha = sinW0 / (2.0 * qFactor);

    bCoeffs[0] =  (1.0 + cosW0) / 2.0 ;
    bCoeffs[1] = -(1.0 + cosW0);
    bCoeffs[2] =  (1.0 + cosW0) / 2.0 ;
    aCoeffs[0] =   1.0 + alpha;
    aCoeffs[1] =  -2.0 * cosW0;
    aCoeffs[2] =   1.0 - alpha;

    normalizeCoefficients();
}

//========================================================================================
// Peak

PeakFilter::PeakFilter() 
{
    frequency.setID(Parameters::Frequency);

    qFactor.setRange(0.1, 10.0);
    qFactor.setDefaultValue(0.707106781);
    qFactor.setID(Parameters::FilterQ);

    dbGain.setRange(-12.0, 12.0);
    dbGain.setDefaultValue(0.0);
    dbGain.setID(Parameters::Gain);

    calculateCoefficients(); 
}

void PeakFilter::setParameterValue(int index, double value)
{
    CLAssert(value >= 0.f && value <= 1.f);
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Frequency:
        frequency.setValue(value);
        break;

    case Parameters::FilterQ:
        qFactor.setValue(value);
        break;

    case Parameters::Gain:
        dbGain.setValue(value);
        break;

    default:
        CLAssert(0);
        return;
    }
    calculateCoefficients();
}

std::vector<AudioParameter*> PeakFilter::getParameters() 
{
    return std::vector<AudioParameter*>{&frequency, &qFactor, &dbGain};
}

void PeakFilter::setFilterQ(double newFilterQ)
{
    qFactor.setValueUnchecked(newFilterQ);
    calculateCoefficients();
}

void PeakFilter::setGain(double newGain)
{
    dbGain.setValueUnchecked(newGain);
    calculateCoefficients();
}

void PeakFilter::calculateCoefficients()
{
    double omega = 2.0 * Pi / mSampleRate;
    double w0 = omega * frequency;
    double sinW0 = std::sin(w0);
    double cosW0 = std::cos(w0);
    double alpha = sinW0 / (2.0 * qFactor);
    double A = std::pow(10.0, dbGain / 40.0);

    bCoeffs[0] =  1.0 + alpha * A;
    bCoeffs[1] = -2.0 * cosW0;
    bCoeffs[2] =  1.0 - alpha * A;
    aCoeffs[0] =  1.0 + alpha / A;
    aCoeffs[1] = -2.0 * cosW0;
    aCoeffs[2] =  1.0 - alpha / A;

    normalizeCoefficients();
}

//========================================================================================
// Band Pass

BandPassFilter::BandPassFilter() 
{ 
    frequency.setID(Parameters::Frequency);

    bandwidth.setRange(0.1, 3.0);
    bandwidth.setDefaultValue(1.0);
    bandwidth.setID(Parameters::BandWidth);

    calculateCoefficients(); 
}

void BandPassFilter::setParameterValue(int index, double value)
{
    CLAssert(value >= 0.f && value <= 1.f);
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Frequency:
        frequency.setValue(value);
        break;

        // Bandwith is in octaves
    case Parameters::BandWidth:
        bandwidth.setValue(value);
        break;

    default:
//        assert(0);
        return;
    }
    calculateCoefficients();
}

std::vector<AudioParameter*> BandPassFilter::getParameters() 
{
    return std::vector<AudioParameter*>{&frequency, &bandwidth};
}

void BandPassFilter::setBandwidth(double newBandwidth)
{
    bandwidth.setValueUnchecked(newBandwidth);
    calculateCoefficients();
}

void BandPassFilter::calculateCoefficients()
{
    double omega = 2.0 * Pi / mSampleRate;
    double w0 = omega * frequency;
    double sinW0 = std::sin(w0);
    double cosW0 = std::cos(w0);
    double alpha = sinW0 * std::sinh(0.1505149978 * bandwidth * w0 / sinW0); // Magic number is log10(2)/2

    bCoeffs[0] = alpha;
    bCoeffs[1] = 0.0;
    bCoeffs[2] = -alpha;
    aCoeffs[0] =  1.0 + alpha;
    aCoeffs[1] = -2.0 * cosW0;
    aCoeffs[2] =  1.0 - alpha;

    normalizeCoefficients();
}

//========================================================================================
// Notch

NotchFilter::NotchFilter()
{ 
    frequency.setID(Parameters::Frequency);

    bandwidth.setRange(0.1, 3.0);
    bandwidth.setDefaultValue(0.1);
    bandwidth.setID(Parameters::Width);

    calculateCoefficients(); 
}

void NotchFilter::setParameterValue(int index, double value)
{
    CLAssert(value >= 0.f && value <= 1.f);
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Frequency:
        frequency.setValue(value);
        break;

        // Bandwidth is in octaves
    case Parameters::Width:
        bandwidth.setValue(value);
        break;

    default:
//        assert(0);
        return;
    }
    calculateCoefficients();
}

std::vector<AudioParameter*> NotchFilter::getParameters() 
{
    return std::vector<AudioParameter*>{&frequency, &bandwidth};
}

void NotchFilter::setBandwidth(double newBandwidth)
{
    bandwidth.setValueUnchecked(newBandwidth);
    calculateCoefficients();
}

void NotchFilter::calculateCoefficients()
{
    double omega = 2.0 * Pi / mSampleRate;
    double w0 = omega * frequency;
    double sinW0 = std::sin(w0);
    double cosW0 = std::cos(w0);
    double alpha = sinW0 * std::sinh(0.1505149978 * bandwidth * w0 / sinW0); // Magic number is log10(2)/2

    bCoeffs[0] = 1.0;
    bCoeffs[1] = -2.0 * cosW0;
    bCoeffs[2] = 1.0;
    aCoeffs[0] =  1.0 + alpha;
    aCoeffs[1] = -2.0 * cosW0;
    aCoeffs[2] =  1.0 - alpha;

    normalizeCoefficients();
}

//========================================================================================
// Low Shelf

LowShelfFilter::LowShelfFilter() 
{
    frequency.setID(Parameters::Frequency);

    shelfSlope.setRange(0.1, 1.0);
    shelfSlope.setDefaultValue(0.2436974789915966); // 3dB/oct
    shelfSlope.setID(Parameters::Slope);

    dbGain.setRange(-12.0, 12.0);
    dbGain.setDefaultValue(0.0);
    dbGain.setID(Parameters::Gain);

    calculateCoefficients(); 
}

void LowShelfFilter::setParameterValue(int index, double value)
{
    CLAssert(value >= 0.f && value <= 1.f);
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Frequency:
        frequency.setValue(value);
        break;

    case Parameters::Slope:
        shelfSlope.setValue(value);
        break;

    case Parameters::Gain:
        dbGain.setValue(value);
        break;

    default:
        CLAssert(0);
        return;
    }
    calculateCoefficients();
}

std::vector<AudioParameter*> LowShelfFilter::getParameters()  
{
    return std::vector<AudioParameter*>{&frequency, &shelfSlope, &dbGain};
}

void LowShelfFilter::setShelfSlope(double slope)
{
    shelfSlope.setValueUnchecked(slope);
    calculateCoefficients();
}

void LowShelfFilter::setGain(double newGain)
{
    dbGain.setValueUnchecked(newGain);
    calculateCoefficients();
}

void LowShelfFilter::calculateCoefficients()
{
    double omega = 2.0 * Pi / mSampleRate;
    double A = std::pow(10.0, dbGain / 40.0);
    double w0 = omega * frequency;
    double sinW0 = std::sin(w0);
    double cosW0 = std::cos(w0);
    double alpha = (sinW0 * 0.5) * std::sqrt((A + (1.0 / A)) * ((1.0 / shelfSlope) - 1.0) + 2.0);
    double twoAlphaSqrtA = 2.0 * std::sqrt(A) * alpha;

    bCoeffs[0] =        A * ( (A + 1.0) - (A - 1.0) * cosW0 + twoAlphaSqrtA );
    bCoeffs[1] =  2.0 * A * ( (A - 1.0) - (A + 1.0) * cosW0 )                ;
    bCoeffs[2] =        A * ( (A + 1.0) - (A - 1.0) * cosW0 - twoAlphaSqrtA );
    aCoeffs[0] =              (A + 1.0) + (A - 1.0) * cosW0 + twoAlphaSqrtA  ;
    aCoeffs[1] = -2.0 *     ( (A - 1.0) + (A + 1.0) * cosW0 )                ;
    aCoeffs[2] =              (A + 1.0) + (A - 1.0) * cosW0 - twoAlphaSqrtA  ;

    normalizeCoefficients();
}

//========================================================================================
// High Shelf

HighShelfFilter::HighShelfFilter() 
{ 
    frequency.setID(Parameters::Frequency);

    shelfSlope.setRange(0.1, 1.0);
    shelfSlope.setDefaultValue(0.2436974789915966); // 3dB/oct
    shelfSlope.setID(Parameters::Slope);

    dbGain.setRange(-12.0, 12.0);
    dbGain.setDefaultValue(0.0);
    dbGain.setID(Parameters::Gain);

    calculateCoefficients(); 
}

void HighShelfFilter::setParameterValue(int index, double value)
{
    CLAssert(value >= 0.f && value <= 1.f);
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Frequency:
        frequency.setValue(value);
        break;

    case Parameters::Slope:
        shelfSlope.setValue(value);
        break;

    case Parameters::Gain:
        dbGain.setValue(value);
        break;

    default:
      //  assert(0);
        return;
    }
    calculateCoefficients();
}

std::vector<AudioParameter*> HighShelfFilter::getParameters()
{
    return std::vector<AudioParameter*>{&frequency, & shelfSlope, & dbGain};
}

void HighShelfFilter::setShelfSlope(double slope)
{
    shelfSlope.setValueUnchecked(slope);
    calculateCoefficients();
}

void HighShelfFilter::setGain(double newGain)
{
    dbGain.setValueUnchecked(newGain);
    calculateCoefficients();
}

void HighShelfFilter::calculateCoefficients()
{
    double omega = 2.0 * Pi / mSampleRate;
    double A = std::pow(10.0, dbGain / 40.0);
    double w0 = omega * frequency;
    double sinW0 = std::sin(w0);
    double cosW0 = std::cos(w0);
    double alpha = (sinW0 * 0.5) * std::sqrt((A + (1.0 / A)) * ((1.0 / shelfSlope) - 1.0) + 2.0);
    double twoAlphaSqrtA = 2.0 * std::sqrt(A) * alpha;

    bCoeffs[0] =        A * ( (A + 1.0) + (A - 1.0) * cosW0   + twoAlphaSqrtA );
    bCoeffs[1] = -2.0 * A * ( (A - 1.0) + (A + 1.0) * cosW0 )                  ;
    bCoeffs[2] =        A * ( (A + 1.0) + (A - 1.0) * cosW0   - twoAlphaSqrtA );
    aCoeffs[0] =              (A + 1.0) - (A - 1.0) * cosW0   + twoAlphaSqrtA  ;
    aCoeffs[1] =  2.0 *     ( (A - 1.0) - (A + 1.0) * cosW0 )                  ;
    aCoeffs[2] =              (A + 1.0) - (A - 1.0) * cosW0   - twoAlphaSqrtA  ;

    normalizeCoefficients();
}

//========================================================================================
// All Pass

AllPassFilter::AllPassFilter()
{
    gain.setID(Parameters::Gain);
}

void AllPassFilter::setParameterValue(int index, double value)
{
    CLAssert(value >= 0.f && value <= 1.f);
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Gain:
        gain.setValue(value);
        break;

    default:
//        assert(0);
        return;
    }
}

std::vector<AudioParameter*> AllPassFilter::getParameters()
{
    return std::vector<AudioParameter*>{&gain};
}

void AllPassFilter::setGain(double newGain)
{
    gain.setValueUnchecked(newGain);
}

SampleType AllPassFilter::processSample(SampleType inputSample)
{
    yState = gain.toFloat() * yState + xState - gain.toFloat() * inputSample;
    xState = inputSample;
    return yState;
}

std::vector<SampleType>& AllPassFilter::processBlock(std::vector<SampleType>& input)
{
    for (auto& it : input)
    {
        it = processSample(it);
    }
    return input;
}

std::vector<std::vector<SampleType>>& AllPassFilter::processBlock(std::vector<std::vector<SampleType>>& input)
{
    // This class cannot process multiple channels at once
    CLAssert(input.size() == 1);
    input[0] = processBlock(input[0]);
    return input;
}

int AllPassFilter::numOutputChannels() const
{
    return 1;
}

//========================================================================================
// Comb

CombFilter::CombFilter()
    :   delay(750)
{
    hpf.setFrequency(125.f);

    pitch.setRange(1, 750);
    pitch.setDefaultValue(150.0);

    damping.setRange(30, 12000);
    damping.setExponential(0.2);
    damping.setDefaultValue(500.0);

    feedbackGain.setRange(0, 0.95);

    pitch.setID(Parameters::Pitch);
    damping.setID(Parameters::Damping);
    feedbackGain.setID(Parameters::Feedback);
}

void CombFilter::setParameterValue(int index, double value)
{
    CLAssert(value >= 0.f && value <= 1.f);

    switch (static_cast<Parameters>(index))
    {
    case Parameters::Pitch:
        // Pitch \in [0,1] maps to delayLength \in [1,750]
        setPitch(pitch.denormalize(value));
        break;

    case Parameters::Damping:
        // Damping \in [0,1] maps to lpf cutoff \in [30,12k]
        setDamping(damping.denormalize(value));
        break;

    case Parameters::Feedback:
        // 0<= feedbackGain <= 0.95
        feedbackGain.setValue(value);
        break;

    default:
        CLAssert(0);
        return;
    }
}

std::vector<AudioParameter*> CombFilter::getParameters()
{
    return std::vector<AudioParameter*>{&pitch, &damping, &feedbackGain};
}

void CombFilter::setPitch(double newPitch)
{
    pitch.setValueUnchecked(newPitch);
    delay.setDelayLength(pitch.toInt());
}

void CombFilter::setDamping(double value)
{
    damping.setValueUnchecked(value);
    lpf.setFrequency(damping);
}

void CombFilter::setFeedback(double value)
{
    feedbackGain.setValueUnchecked(value);
}

SampleType CombFilter::processSample(SampleType inputSample)
{
    yState = hpf.processSample(yState);
    yState = lpf.processSample(yState);
    yState = delay.run(yState);
    yState *= feedbackGain.toFloat();
    yState += inputSample;

    return yState;
}

std::vector<SampleType>& CombFilter::processBlock(std::vector<SampleType>& input)
{
    for (auto& it : input)
    {
        it = processSample(it);
    }
    return input;
}

std::vector<std::vector<SampleType>>& CombFilter::processBlock(std::vector<std::vector<SampleType>>& input)
{
    // This class cannot process multiple channels at once
    CLAssert(input.size() == 1);
    input[0] = processBlock(input[0]);
    return input;
}

void CombFilter::setSampleRate(double newSampleRate)
{
    hpf.setSampleRate(newSampleRate);
    lpf.setSampleRate(newSampleRate);
}

int CombFilter::numOutputChannels() const
{
    return 1;
}

} // namespace CamdenLabs
