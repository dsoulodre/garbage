/*
  ==============================================================================

    Preset.h
    Created: 3 Apr 2024 2:49:55pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "ComponentManager/ComponentID.h"
#include "Helpers/XmlHelpers.h"

#include "JuceHeader.h"
#include <memory>

namespace CamdenLabs
{

// Forward declaration
class AudioComponentManager;

class Preset
{
private:
    Preset() = default;
    Preset(const Preset&) = delete;
    Preset(Preset&&) = delete;

public:

    struct ParamData
    {
        uint64_t parameterID;
        double value;
    };

    static auto createPreset(const AudioComponentManager& componentManager) -> std::unique_ptr<Preset>;
    static auto loadPreset(juce::File file) -> std::unique_ptr<Preset>;

    /** Write data to XML file
    */
    void saveToFile(std::string filePath);

    /** Remove all data associated with this component from the preset
    */
    void removeComponentData(uint64_t componentID);



    auto paramData() const -> const std::vector<ParamData>&;

    auto postProcessingComponents() const -> const std::vector<uint64_t>&;

private:

    using Node = CamdenLabs::XmlHelpers::Node;

    std::vector<ParamData> mParamData;
    std::vector<uint64_t> mPostProcessingComponents;
};

class PresetReadError : public std::runtime_error
{
public:
    PresetReadError() : std::runtime_error("Error reading preset") {}
};

} // namespace CamdenLabs