/*
  ==============================================================================

    AudioComponentManager.cpp
    Created: 2 Mar 2024 4:40:39pm
    Author:  14372

  ==============================================================================
*/

#include "AudioComponentManager.h"
#include "GUI/GUIComponent.h"
#include "GUI/MainWindow.h"
#include "AudioComponents/PostProcessingBlock.h"
#include "GUI/GUIFactory.h"


namespace CamdenLabs
{

void AudioComponentManager::setSampleRate(double sampleRate)
{
    std::scoped_lock<std::mutex> guard(mMutex);
    mSampleRate = sampleRate;
}

auto AudioComponentManager::createComponent(uint64_t parentID, ComponentIDs::PostProcessingType componentType) -> std::unique_ptr<GUIComponent>
{
    namespace CLID = ComponentIDs;

    CLAssert(CLID::getSubComponentType(parentID) == CLID::PostProcessingBlock);
    uint64_t postProcID = CLID::getSubComponentID(parentID);
    auto* postProcessingObj = dynamic_cast<PostProcessingBlock*>(find(postProcID));
    if (postProcessingObj == nullptr)
    {
        CLAssert(0);
        return nullptr;
    }

    uint64_t newID = createID(parentID, componentType);
    auto type = static_cast<PostProcessingComponent::ComponentType>(componentType);

    auto newComponent = std::make_unique<PostProcessingComponent>(type, postProcessingObj->numOutputChannels());
    newComponent->setSampleRate(mSampleRate);

    auto gui = createGUI(type);
    addComponent(newID, newComponent.get(), gui.get());
    postProcessingObj->addComponent(std::move(newComponent));

    return gui;
}

void AudioComponentManager::addComponent(uint64_t id, AudioComponent* component, GUIComponent* gui)
{
    std::scoped_lock<std::mutex> guard(mMutex);
    CLAssert(findInternal(id) == nullptr);

    gui->addListener(createListener(id, component));

    mMap.insert(std::make_pair(id, ComponentData{ gui, component }));
}

void AudioComponentManager::addComponent(uint64_t componentID, AudioComponent& component, GUIComponent& gui)
{
    addComponent(componentID, &component, &gui);
}

void AudioComponentManager::addAudioComponent(uint64_t id, AudioComponent* component)
{
    std::scoped_lock<std::mutex> guard(mMutex);
    if (auto* data = findInternal(id))
    {
        CLAssert(data->component == nullptr && data->gui != nullptr);
        data->component = component;
        data->gui->addListener(createListener(id, component));
        return;
    }

    ComponentData newData{ nullptr, component };
    mMap.insert({ id, newData });
}

void AudioComponentManager::addGUIComponent(uint64_t id, GUIComponent* component)
{
    std::scoped_lock<std::mutex> guard(mMutex);
    if (auto* data = findInternal(id))
    {
        CLAssert(data->gui == nullptr && data->component != nullptr);
        data->gui = component;
        component->addListener(createListener(id, data->component));
        return;
    }

    ComponentData newData{ component, nullptr };
    mMap.insert({ id, newData });
}

void AudioComponentManager::deleteComponent(uint64_t componentID)
{
    namespace CLID = ComponentIDs;
    std::scoped_lock<std::mutex> guard(mMutex);

    auto it = mMap.find(componentID);
    if (it == mMap.end())
    {
        CLAssert(0);
        return;
    }

    auto* component = it->second.component;
    CLAssert(component != nullptr);
    mMap.erase(it);

    uint64_t parentID = CLID::getParentID(componentID);

    if (CLID::getSubComponentType(parentID) != CLID::SubComponentType::PostProcessingBlock)
    {
        CLAssert(0);
        return;
    }

    auto* parent = dynamic_cast<PostProcessingBlock*>(find(parentID));
    if (parent == nullptr)
    {
        CLAssert(0);
        return;
    }
    parent->removeComponent(component);
}

auto AudioComponentManager::deleteAudioComponent(uint64_t componentID) -> AudioComponent*
{
    std::scoped_lock<std::mutex> guard(mMutex);

    auto it = mMap.find(componentID);
    if (it == mMap.end())
    {
        CLAssert(0);
        return nullptr;
    }

    auto ptr = it->second.component;

    // The entry is removed from the map only if the GUI has already been deleted
    if (it->second.gui == nullptr)
    {
        mMap.erase(it);
    }
    else
    {
        it->second.component = nullptr;
    }

    return ptr;
}

uint64_t AudioComponentManager::deleteAudioComponent(AudioComponent* component)
{
    std::scoped_lock<std::mutex> guard(mMutex);

    uint64_t componentID = find(component);
    if (componentID == 0ULL)
    {
        CLAssert(0);
        return 0ULL;
    }

    auto data = findInternal(componentID);

    // The entry is removed from the map only if the GUI has already been deleted
    if (data->gui == nullptr)
    {
        mMap.erase(componentID);
    }
    else
    {
        data->component = nullptr;
    }
    return componentID;
}

auto AudioComponentManager::deleteGUIComponent(uint64_t id) -> GUIComponent*
{
    std::scoped_lock<std::mutex> guard(mMutex);

    auto it = mMap.find(id);
    if (it == mMap.end())
    {
        CLAssert(0);
        return nullptr;
    }

    auto ptr = it->second.gui;

    // The entry is removed from the map only if the AudioComponent has already been deleted
    if (it->second.component == nullptr)
    {
        mMap.erase(it);
    }
    else
    {
        it->second.gui = nullptr;
    }

    return ptr;
}

uint64_t AudioComponentManager::deleteGUIComponent(GUIComponent* component)
{
    std::scoped_lock<std::mutex> guard(mMutex);

    uint64_t componentID = findGUI(component);
    if (componentID == 0ULL)
    {
        CLAssert(0);
        return 0ULL;
    }

    auto data = findInternal(componentID);

    // The entry is removed from the map only if the GUI has already been deleted
    if (data->component == nullptr)
    {
        mMap.erase(componentID);
    }
    else
    {
        data->gui = nullptr;
    }
    return componentID;
}

auto AudioComponentManager::find(uint64_t id) const -> AudioComponent* const
{
    auto it = mMap.find(id);
    if (it != mMap.end())
    {
        return it->second.component;
    }

    return nullptr;
}

auto AudioComponentManager::find(AudioComponent* component) const -> uint64_t
{
    auto predicate = [component](const std::pair<const uint64_t, ComponentData>& entry) { return entry.second.component == component; };
    auto it = std::find_if(mMap.begin(), mMap.end(), predicate);
    if (it != mMap.end())
    {
        return it->first;
    }


    return 0ULL;
}

auto AudioComponentManager::find(GUIComponent* component) const -> AudioComponent* const
{
    auto predicate = [component](const std::pair<const uint64_t, ComponentData>& entry) { return entry.second.gui == component; };
    auto it = std::find_if(mMap.begin(), mMap.end(), predicate);
    if (it != mMap.end())
    {
        return it->second.component;
    }

    return nullptr;
}

auto AudioComponentManager::findGUI(uint64_t id) const -> GUIComponent* const
{
    auto it = mMap.find(id);
    if (it != mMap.end())
    {
        return it->second.gui;
    }

    return nullptr;
}

auto AudioComponentManager::findGUI(GUIComponent* component) const -> uint64_t
{
    auto predicate = [component](const std::pair<const uint64_t, ComponentData>& entry) { return entry.second.gui == component; };
    auto it = std::find_if(mMap.begin(), mMap.end(), predicate);
    if (it != mMap.end())
    {
        return it->first;
    }

    return 0ULL;
}

auto AudioComponentManager::findGUI(AudioComponent* component) const -> GUIComponent* const
{
    auto predicate = [component](const std::pair<uint64_t, ComponentData>& entry) { return entry.second.component == component; };
    auto it = std::find_if(mMap.begin(), mMap.end(), predicate);
    if (it != mMap.end())
    {
        return it->second.gui;
    }

    return 0;
}

auto AudioComponentManager::getAudioComponents() const -> std::vector<std::pair<uint64_t, AudioComponent*>>
{
    std::vector<std::pair<uint64_t, AudioComponent*>> vec;
    vec.reserve(mMap.size());

    for (auto& it : mMap)
    {
        vec.push_back({ it.first, it.second.component });
    }

    return vec;
}

auto AudioComponentManager::getGuiComponents() const -> std::vector<std::pair<uint64_t, GUIComponent*>>
{
    std::vector<std::pair<uint64_t, GUIComponent*>> vec;
    vec.reserve(mMap.size());

    for (auto& it : mMap)
    {
        vec.push_back({ it.first, it.second.gui });
    }

    return vec;
}

auto AudioComponentManager::createPostProcessingComponent(uint64_t id) -> std::unique_ptr<GUIComponent>
{
    namespace CLID = ComponentIDs;

    auto type = static_cast<PostProcessingComponent::ComponentType>(CLID::getPostProcessingType(id));
    auto newComponent = std::make_unique<PostProcessingComponent>(type);
    auto gui = createGUI(type);
    addComponent(id, newComponent.get(), gui.get());

    uint64_t parentID = CLID::getParentID(id);
    CLAssert(CLID::getSubComponentType(parentID) == CLID::SubComponentType::PostProcessingBlock);

    uint64_t postProcID = CLID::getSubComponentID(parentID);
    auto* postProcessingObj = dynamic_cast<PostProcessingBlock*>(find(postProcID));

    postProcessingObj->addComponent(std::move(newComponent));

    return gui;

}

auto AudioComponentManager::createListener(uint64_t componentID, AudioComponent* component) -> std::unique_ptr<Listener>
{
    return std::make_unique<Listener>(componentID, component, this);
}

auto AudioComponentManager::findInternal(uint64_t id) -> ComponentData*
{
    auto it = mMap.find(id);
    if (it != mMap.end())
    {
        return &(it->second);
    }

    return nullptr;
}

auto AudioComponentManager::findInternal(uint64_t id) const -> const ComponentData*
{
    auto it = mMap.find(id);
    if (it != mMap.end())
    {
        return &(it->second);
    }

    return nullptr;
}

auto AudioComponentManager::createID(uint64_t parentID, ComponentIDs::PostProcessingType componentType) const -> uint64_t
{
    namespace CLID = CamdenLabs::ComponentIDs;

    std::scoped_lock<std::mutex> guard(mMutex);

    const auto idFunc = [componentType, parentID](uint64_t num) { return parentID | CLID::makePostProcessingID(componentType, num); };

    uint64_t num = 0;
    uint64_t newID;

    do
    {
        newID = idFunc(num);
        ++num;
    } while (mMap.find(newID) != mMap.end());

    return newID;
}


} // namespace CamdenLabs