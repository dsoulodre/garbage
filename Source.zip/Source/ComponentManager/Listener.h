/*
  ==============================================================================

    Listener.h
    Created: 2 Mar 2024 9:09:05pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "AudioComponents/AudioComponent.h"
#include "ComponentManager/ComponentID.h"
#include "Helpers/CLAssert.h"

#include <type_traits>


namespace CamdenLabs
{

// Forward declaration to avoid circular dependency
class AudioComponentManager;


class Listener
{
public:

    Listener() = default;

    Listener(uint64_t id, AudioComponent* component, AudioComponentManager* manager);

    void setParameterValue(int index, double value);

    template<typename EnumType>
    auto setParameterValue(EnumType index, double value) -> std::enable_if_t<std::is_enum_v<EnumType>, void>
    {
        setParameterValue(static_cast<int>(index), value);
    }

    void setEnabled(bool shouldBeEnabled);

    auto getParameters() -> std::vector<AudioParameter*>;

    auto component() const -> AudioComponent*;

    auto componentID() const -> uint64_t;

    auto manager() const -> AudioComponentManager* const;

private:
    uint64_t mComponentID{ 0ULL };
    AudioComponent* mComponent{ nullptr };
    AudioComponentManager* mManager{ nullptr };
};

} // namespace CamdenLabs