/*
  ==============================================================================

    Listener.cpp
    Created: 2 Mar 2024 9:09:05pm
    Author:  14372

  ==============================================================================
*/

#include "ComponentManager/Listener.h"
#include "ComponentManager/AudioComponentManager.h"

namespace CamdenLabs
{

Listener::Listener(uint64_t id, AudioComponent* component, AudioComponentManager* manager)
    : mComponentID(id), mComponent(component), mManager(manager)
{

}

void Listener::setParameterValue(int index, double value)
{
    CLAssert(mComponent != nullptr && mManager != nullptr && mComponentID != 0ULL);
    mComponent->setParameterValue(index, value);
}

void Listener::setEnabled(bool shouldBeEnabled)
{
    CLAssert(mComponent != nullptr && mManager != nullptr && mComponentID != 0ULL);
    mComponent->setEnabled(shouldBeEnabled);
}

std::vector<AudioParameter*> Listener::getParameters()
{
    CLAssert(mComponent != nullptr && mManager != nullptr && mComponentID != 0ULL);
    return mComponent->getParameters();
}

auto Listener::component() const -> AudioComponent*
{
    return mComponent;
}

auto Listener::componentID() const -> uint64_t
{
    return mComponentID;
}

auto Listener::manager() const -> AudioComponentManager* const
{
    return mManager;
}

} // namespace CamdenLabs