/*
  ==============================================================================

    Preset.cpp
    Created: 3 Apr 2024 2:49:56pm
    Author:  14372

  ==============================================================================
*/

#include "Preset.h"
#include "ComponentManager/AudioComponentManager.h"
#include <cassert>

using namespace CamdenLabs::XmlHelpers;

namespace CamdenLabs
{
    namespace Tag
    {
        static XmlTag root = "CamdenDSPPreset";
        static XmlTag paramData = "ParameterData";
        static XmlTag param = "Parameter";
        static XmlTag id = "ID";
        static XmlTag value = "Value";
    }

auto Preset::createPreset(const AudioComponentManager& componentManager) -> std::unique_ptr<Preset>
{
    namespace CLID = ComponentIDs;

    // Private constructor
    auto preset = std::unique_ptr<Preset>(new Preset);

    for (auto& [id, component] : componentManager.getAudioComponents())
    {
        for (auto* param : component->getParameters())
        {
            uint64_t parameterID = CLID::makeParameterID(id, param->paramID());
            double value = param->normalizedValue();
            preset->mParamData.push_back({ parameterID, value });
        }
    }

    return preset;
}

auto Preset::loadPreset(juce::File file) -> std::unique_ptr<Preset>
{
    namespace CLID = ComponentIDs;

    auto preset = std::unique_ptr<Preset>(new Preset);

    auto rootNode = juce::XmlDocument::parse(file);
    checkNode(rootNode.get());

    auto parameterData = rootNode->getChildByName(Tag::paramData);
    checkNode(parameterData);
    preset->mParamData.reserve(100);

    const auto getParamData = [](const Node* node) -> Preset::ParamData
    {
        auto paramIDNode = node->getChildByName(Tag::id);
        checkNode(paramIDNode);
        auto paramID = getElementLongInt(paramIDNode);

        auto valueNode = node->getChildByName(Tag::value);
        checkNode(valueNode);
        auto value = getElementDouble(valueNode);

        return { paramID, value };
    };

    for (const auto it : parameterData->getChildIterator())
    {
        checkNode(it);
        if (!it->hasTagName(Tag::param))
        {
            CLAssert(0);
            continue;
        }

        preset->mParamData.push_back(getParamData(it));
    }

    // Find post-processing components
    std::set<uint64_t> postProcComponents;

    for (const auto& it : preset->mParamData)
    {
        using namespace ComponentIDs;
        if (getSubComponentType(it.parameterID) == SubComponentType::PostProcessingBlock)
        {
            postProcComponents.insert(getComponentFromParameter(it.parameterID));
        }
    }
    preset->mPostProcessingComponents.assign(postProcComponents.begin(), postProcComponents.end());

    return preset;
}

void Preset::saveToFile(std::string filePath)
{
    static juce::XmlElement::TextFormat format;
    format.customEncoding = "UTF-8";
    format.customHeader = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    format.lineWrapLength = 120;
    format.newLineChars = "\r\n";

    auto xmlFile = juce::File(filePath);

    Node rootNode(Tag::root);

    // Parameter data
    Node* parameterData = new Node(Tag::paramData);
    rootNode.addChildElement(parameterData);

    for (const auto& it : mParamData)
    {
        Node* paramNode = new Node(Tag::param);
        parameterData->addChildElement(paramNode);

        Node* idNode = new Node(Tag::id);
        paramNode->addChildElement(idNode);
        setElementULL(idNode, it.parameterID);

        Node* valueNode = new Node(Tag::value);
        paramNode->addChildElement(valueNode);
        setElementDouble(valueNode, it.value);
    }

    rootNode.writeTo(xmlFile, format);
}

void Preset::removeComponentData(uint64_t componentID)
{
    namespace CLID = ComponentIDs;
    std::vector<ParamData> processedData;

    for (const auto& it : mParamData)
    {
        if (CLID::getParentID(it.parameterID) == componentID)
        {
            continue;
        }
        processedData.push_back(it);
    }
    mParamData.assign(processedData.begin(), processedData.end());
}

auto Preset::paramData() const -> const std::vector<ParamData>&
{
    return mParamData;
}

auto Preset::postProcessingComponents() const -> const std::vector<uint64_t>&
{
    return mPostProcessingComponents;
}

} // namespace CamdenLabs
