/*
  ================================================================================
  *      File                                         ComponentID.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "Helpers/CLAssert.h"

#include <cstdint>

namespace CamdenLabs
{

    namespace ComponentIDs
    {

        inline constexpr uint64_t componentTypeOffset      = 56;
        inline constexpr uint64_t componentNumOffset       = 48;
        inline constexpr uint64_t subComponentTypeOffset   = 40;
        inline constexpr uint64_t subComponentNumOffset    = 32;
        inline constexpr uint64_t postProcessingTypeOffset = 24;
        inline constexpr uint64_t postProcessingNumOffset  = 16;
        inline constexpr uint64_t paramOffset = 0;

        inline constexpr uint64_t componentTypeMask        = 0b11111111ULL << componentTypeOffset;
        inline constexpr uint64_t componentNumMask         = 0b11111111ULL << componentNumOffset;
        inline constexpr uint64_t subComponentTypeMask     = 0b11111111ULL << subComponentTypeOffset;
        inline constexpr uint64_t subComponentNumMask      = 0b11111111ULL << subComponentNumOffset;
        inline constexpr uint64_t postProcessingTypeMask   = 0b11111111ULL << postProcessingTypeOffset;
        inline constexpr uint64_t postProcessingNumMask    = 0b11111111ULL << postProcessingNumOffset;
        inline constexpr uint64_t paramMask                = 0b11111111ULL << paramOffset;

        enum ComponentType : uint64_t
        {
            StereoProcessing = 1ULL,
            MonoProcessing,
            Crossover,
            FinalProcessing
        };

        enum SubComponentType : uint64_t
        {
            PostProcessingBlock = 1ULL
        };

        enum PostProcessingType : uint64_t
        {
            // Filters
            LowpassID = 1ULL,
            HighpassID,
            PeakID,
            BandpassID,
            NotchID,
            LowShelfID,
            HighShelfID,
            AllPassID,
            CombID,

            // Effects
            PhaserID,
            CompressorID,
            DistortionID,
            BitCrusherID,
            ChopperID,
            ExpanderID,
            ChorusID,
        };

        // Creates top-level component part of ID, with empty subcomponent and parameter data
        inline constexpr uint64_t makeComponentID(ComponentType type, uint64_t num)
        {
            return (type << componentTypeOffset) | (num << componentNumOffset);
        }

        // Creates top-level component part of ID, with empty subcomponent and parameter data
        inline constexpr uint64_t makeComponentID(uint64_t type, uint64_t num)
        {
            return makeComponentID(static_cast<ComponentType>(type), num);
        }

        inline constexpr uint64_t makeSubComponentID(uint64_t parentID, SubComponentType type, uint64_t num)
        {
            return parentID | (type << subComponentTypeOffset) | (num << subComponentNumOffset);
        }

        // Creates subComponent part of ID, with empty top-level component and parameter data
        inline constexpr uint64_t makePostProcessingID(PostProcessingType type, uint64_t num)
        {
            return (type << postProcessingTypeOffset) | (num << postProcessingNumOffset);
        }

        // Creates subComponent part of ID, with empty top-level component and parameter data
        inline constexpr uint64_t makePostProcessingID(uint64_t type, uint64_t num)
        {
            return (type << postProcessingTypeOffset) | (num << postProcessingNumOffset);
        }

        // Creates full ID for subcomponent
        inline constexpr uint64_t makePostProcessingID(ComponentType type, uint64_t num1, PostProcessingType subType, uint64_t num2)
        {
            return (type << componentTypeOffset) | (num1 << componentNumOffset) | (subType << postProcessingTypeOffset) | (num2 << postProcessingNumOffset);
        }

        inline constexpr uint64_t makeParameterID(uint64_t componentID, uint64_t paramID)
        {
            return componentID | (paramID << paramOffset);
        }

        // Extract top-level component type from ID
        inline constexpr uint64_t getComponentType(uint64_t id)
        {
            return (id & componentTypeMask) >> componentTypeOffset;
        }

        inline constexpr uint64_t getComponentNum(uint64_t id)
        {
            return (id & componentNumMask) >> componentNumOffset;
        }

        inline constexpr uint64_t getSubComponentType(uint64_t id)
        {
            return (id & subComponentTypeMask) >> subComponentTypeOffset;
        }

        inline constexpr uint64_t getSubComponentNum(uint64_t id)
        {
            return (id & subComponentNumMask) >> subComponentNumOffset;
        }

        inline constexpr uint64_t getPostProcessingType(uint64_t id)
        {
            return (id & postProcessingTypeMask) >> postProcessingTypeOffset;
        }

        inline constexpr uint64_t getPostProcessingNum(uint64_t id)
        {
            return (id & postProcessingNumMask) >> postProcessingNumOffset;
        }

        // Extract ID of subcomponent this belongs to
        inline constexpr uint64_t getSubComponentID(uint64_t id)
        {
            constexpr uint64_t mask = ~(postProcessingTypeMask | postProcessingNumMask | paramMask);
            return id & mask;
        }

        // Extract ID of top level component this belongs to
        inline constexpr uint64_t getTopLevelComponentID(uint64_t id)
        {
            return id & (componentTypeMask | componentNumMask);
        }

        // Extract parameter number from ID
        inline constexpr uint64_t getParam(uint64_t id)
        {
            return id & paramMask;
        }

        inline constexpr uint64_t getComponentFromParameter(uint64_t parameterID)
        {
            return parameterID & ~paramMask;
        }

        // Returns the ID of the owner of the component passed in, or 0 if it is a top level component. If a parameter ID is passed in,
        // returns the component the parameter belongs to.
        inline constexpr uint64_t getParentID(uint64_t id)
        {

            constexpr uint64_t componentMask      = componentTypeMask
                                                  | componentNumMask;

            constexpr uint64_t subComponentMask   = componentMask 
                                                  | subComponentTypeMask
                                                  | subComponentNumMask;

            constexpr uint64_t postProcessingMask = subComponentMask 
                                                  | postProcessingTypeMask 
                                                  | postProcessingNumMask;

            if((id & paramMask) != 0ULL)
            {
                return id & postProcessingMask;
            }
            else if ((id & postProcessingTypeMask) != 0ULL)
            {
                return id & subComponentMask;
            }
            else if ((id & subComponentTypeMask) != 0ULL)
            {
                return id & componentMask;
            }
            else if ((id & componentTypeMask) != 0ULL)
            {
                return 0ULL;
            }
            else
            {
                CLAssert(0);
                return 0ULL;
            }
        }

        struct ComponentAttributes
        {
            const ComponentType type{};
            const uint64_t componentNum{ 0 };
            const SubComponentType subComponentType{};
            const uint64_t subComponentNum{};
            const PostProcessingType postProcessingType{};
            const uint64_t postProcessingNum{ 0 };
            const uint64_t paramID{ 0 };
        };

        inline constexpr ComponentAttributes getComponentAttributes(uint64_t id)
        {
            return
            {
                static_cast<ComponentType>(getComponentType(id)),
                getComponentNum(id),
                static_cast<SubComponentType>(getSubComponentType(id)),
                getSubComponentNum(id),
                static_cast<PostProcessingType>(getPostProcessingType(id)),
                getPostProcessingNum(id),
                getParam(id)
            };
        }

        inline constexpr uint64_t makeComponentID(const ComponentAttributes& attributes)
        {
            uint64_t id = static_cast<uint64_t>(attributes.type) << componentTypeOffset;
            id |= attributes.componentNum << componentNumOffset;
            id |= static_cast<uint64_t>(attributes.subComponentType) << postProcessingTypeOffset;
            id |= attributes.subComponentNum << postProcessingNumOffset;
            id |= attributes.paramID << paramOffset;
            return id;


            //return (attributes.type               << componentTypeOffset)
            //     | (attributes.componentNum       << componentNumOffset)
            //     | (attributes.subComponentType   << postProcessingTypeOffset)
            //     | (attributes.subComponentNum    << postProcessingNumOffset)
            //     | (attributes.paramID            << paramOffset);
        }

    } // namespace ComponentID
} // namespace CamdenLabs
