/*
  ==============================================================================

    AudioComponentManager.h
    Created: 2 Mar 2024 4:40:39pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "ComponentManager/ComponentID.h"
#include "ComponentManager/Listener.h"

#include <memory>
#include <unordered_map>
#include <mutex>

namespace CamdenLabs
{

// Forward declaration
class GUIComponent;
class AudioComponent;

class AudioComponentManager
{
public:

    void setSampleRate(double sampleRate);

    auto createComponent(uint64_t parentID, ComponentIDs::PostProcessingType componentType) -> std::unique_ptr<GUIComponent>;
   

    // Functions to add or delete components
    //=============================================================================================================================

    void addComponent(uint64_t componentID, AudioComponent* component, GUIComponent* gui);

    void addComponent(uint64_t componentID, AudioComponent& component, GUIComponent& gui);

    void addAudioComponent(uint64_t componentID, AudioComponent* component);

    void addGUIComponent(uint64_t componentID, GUIComponent* component);

    void deleteComponent(uint64_t componentID);

    [[nodiscard]] AudioComponent* deleteAudioComponent(uint64_t componentID);

    [[nodiscard]] uint64_t deleteAudioComponent(AudioComponent* component);

    [[nodiscard]] GUIComponent* deleteGUIComponent(uint64_t componentID);

    [[nodiscard]] uint64_t deleteGUIComponent(GUIComponent* component);



    // Element access
    //=============================================================================================================================


    /** Returns pointer to AudioComponent with ID "id", or nullptr if not found
    */
    auto find(uint64_t id) const -> AudioComponent* const;


    /** Returns ID of component pointed to by "component", or 0 if not found
    */
    auto find(AudioComponent* component) const -> uint64_t;


    /** Returns pointer to the AudioComponent associated with the GUIComponent pointed to by "component", or nullptr if not found
    */
    auto find(GUIComponent* component) const -> AudioComponent* const;


    /** Returns pointer to GUIComponent with ID "id", or nullptr if not found
    */
    auto findGUI(uint64_t id) const -> GUIComponent* const;


    /** Returns ID of component pointed to by "component", or 0 if not found
    */
    auto findGUI(GUIComponent* component) const -> uint64_t;


    /** Returns pointer to GUIComponent associated with the AudioComponent pointed to by "component", or nullptr if not found
    */
    auto findGUI(AudioComponent* component) const -> GUIComponent* const;

    

    // For iterating over all elements
    //=================================================================================================================================

    auto getAudioComponents() const -> std::vector<std::pair<uint64_t, AudioComponent*>>;
    auto getGuiComponents() const -> std::vector<std::pair<uint64_t, GUIComponent*>>;

private:

    struct ComponentData
    {
        GUIComponent* gui;
        AudioComponent* component;
    };

    auto createPostProcessingComponent(uint64_t) -> std::unique_ptr<GUIComponent>;

    auto createListener(uint64_t componentID, AudioComponent* component) -> std::unique_ptr<Listener>;

    auto findInternal(uint64_t id) -> ComponentData*;

    auto findInternal(uint64_t id) const -> const ComponentData*;

    uint64_t createID(uint64_t parentID, ComponentIDs::PostProcessingType componentType) const;

    std::unordered_map<uint64_t, ComponentData> mMap;
    
    mutable std::mutex mMutex;

    double mSampleRate{ Constants::defaultSampleRate };
};
 
} // namespace CamdenLabs 