/*
  ==============================================================================

    CLAssert.cpp
    Created: 17 Mar 2024 1:37:40pm
    Author:  14372

  ==============================================================================
*/

#include "CLAssert.h"

#if CL_DEBUG

// Set for testing on Windows
#define CL_USE_FALLBACK_ASSERT 0


#ifndef CL_USE_FALLBACK_ASSERT
    #if defined(_MSC_VER)
        #define CL_USE_FALLBACK_ASSERT 0
    #else
        #define CL_USE_FALLBACK_ASSERT 1
    #endif // defined(_MSC_VER)
#endif // !defined(CL_USE_FALLBACK_ASSERT)

#if CL_USE_FALLBACK_ASSERT
    #include "JuceHeader.h"
#else
    #include <cassert>
    #include <cstdlib>
    #include <cstring>
    #include <string>
#endif // CL_USE_FALLBACK_ASSERT

#if CL_USE_FALLBACK_ASSERT

static void camdenFallbackAssert(const char* message, const char* file, unsigned line)
{
    using Str = juce::String;
    constexpr int ignoreCode = 0;
    constexpr int abortCode = 1;

    Str fullMessage = Str("File: ") + Str(file) + Str("\n") + Str("Line: ") + Str(line) + Str("\n") + Str("Expression: ") + Str(message);

    auto options = juce::MessageBoxOptions()
        .withIconType(juce::MessageBoxIconType::WarningIcon)
        .withTitle("Assertion Failed")
        .withMessage(fullMessage)
        .withButton("Abort")
        .withButton("Ignore");

    if (juce::AlertWindow::show(options) == abortCode)
    {
        std::terminate();
    }
}

#else

static void camdenWindowsAssert(const char* message, const char* file, unsigned line)
{
    const auto makeWide = [](const char* str)
    {
        const size_t size = std::strlen(str);
        std::wstring wstr;
        if (size > 0) {
            wstr.resize(size);
            std::mbstowcs(&wstr[0], str, size);
        }
        return wstr;
    };

    _wassert(makeWide(message).c_str(), makeWide(file).c_str(), line);
}

#endif // CL_USE_FALLBACK_ASSERT

void camdenLabsAssert(const char* message, const char* file, unsigned line)
{
#if CL_USE_FALLBACK_ASSERT
    camdenFallbackAssert(message, file, line);
#else
    camdenWindowsAssert(message, file, line);
#endif // CL_USE_FALLBACK_ASSERT  
}


#endif // CL_DEBUG