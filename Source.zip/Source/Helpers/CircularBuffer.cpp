/*
  ================================================================================
  *      File                                    CircularBuffer.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "CLHeader.h"
#include "Helpers/CircularBuffer.h"
#include "Helpers/CLAssert.h"

namespace CamdenLabs
{

CircularBuffer::CircularBuffer(unsigned int channels, size_t length)
    :   mNumChannels(channels), bufferSize(length)
{
    data.resize(mNumChannels, std::vector<SampleType>(length, 0.0f));
    static_assert(std::is_nothrow_move_constructible_v<CircularBuffer>);
}

void CircularBuffer::write(const std::vector<std::vector<SampleType>>& source)
{
    write(source, source[0].size());
}

void CircularBuffer::write(const std::vector<std::vector<SampleType>>& source, size_t numSamples, size_t offset)
{
    // std::lock_guard<std::mutex> lock(circBuffMutex);

    CLAssert(numSamples <= source[0].size() && numSamples <= bufferSize);

    size_t dataEnd = (writePtr + numSamples) % bufferSize;

    int maxChannel = std::min(static_cast<int>(source.size()), mNumChannels); // See comment at bottom

    if (writePtr + numSamples < bufferSize) // Doesn't wrap around
    {
        for (int channel = 0; channel < maxChannel; ++channel)
        {
            for (size_t i = writePtr, k = offset; i < dataEnd; ++i, ++k)
            {
                data[channel][i] = source[channel][k];
            }
        }
    }
    else // Write pointer will wrap around on this write
    {
        size_t start = bufferSize - writePtr + offset; // Position in source buffer after wrapping around circBuffer

        for (int channel = 0; channel < maxChannel; ++channel)
        {
            for (size_t i = writePtr, k = offset; i < bufferSize; ++i, ++k)
            {
                data[channel][i] = source[channel][k];
            }
        }
        // Writing wraps to start
        for (int channel = 0; channel < maxChannel; ++channel)
        {
            for (size_t i = 0, k = start; i < dataEnd; ++i, ++k)
            {
                data[channel][i] = source[channel][k];
            }
        }
    }

    //
    // Handling mono files
    //

    if (source.size() < mNumChannels) // Mono file
    {
        // Code above runs, then the duplication to empty channels

        if (writePtr + numSamples < bufferSize) // Doesn't wrap around
        {
            for (int channel = 0; channel < maxChannel; ++channel)
            {
                for (size_t i = writePtr; i < dataEnd; ++i)
                {
                    data[channel + 1][i] = data[channel][i];
                }
            }
        }
        else // Write pointer will wrap around on this write
        {
            for (int channel = 0; channel < maxChannel; ++channel)
            {
                for (size_t i = writePtr; i < bufferSize; ++i)
                {
                    data[channel + 1][i] = data[channel][i];
                }
            }
            // Wrap point
            for (int channel = 0; channel < maxChannel; ++channel)
            {
                for (size_t i = 0; i < dataEnd; ++i)
                {
                    data[channel + 1][i] = data[channel][i];
                }
            }
        }
    }

    writePtr = dataEnd;
}

void CircularBuffer::write(const std::vector<SampleType>& source, int numSamples, int offset, bool writeToAllChannels)
{

    size_t dataEnd = (writePtr + numSamples) % bufferSize;

    int maxChannel = writeToAllChannels ? static_cast<int>(data.size()) : 1;

    if (writePtr + numSamples < bufferSize) // Doesn't wrap around
    {
        for (int channel = 0; channel < maxChannel; ++channel)
        {
            for (size_t i = writePtr, k = offset; i < dataEnd; ++i, ++k)
            {
                data[channel][i] = source[k];
            }
        }
    }
    else // Write pointer will wrap around on this write
    {
        size_t start = bufferSize - writePtr + offset; // Position in source buffer after wrapping around circBuffer

        for (int channel = 0; channel < maxChannel; ++channel)
        {
            for (size_t i = writePtr, k = offset; i < bufferSize; ++i, ++k)
            {
                data[channel][i] = source[k];
            }
        }
        // Writing wraps to start
        for (int channel = 0; channel < maxChannel; ++channel)
        {
            for (size_t i = 0, k = start; i < dataEnd; ++i, ++k)
            {
                data[channel][i] = source[k];
            }
        }
    }

    writePtr = dataEnd;
}

void CircularBuffer::read(SampleType** destination, int numChannels, size_t numSamples)   // Mutex locked
{
    // std::lock_guard<std::mutex> lock(circBuffMutex);

    // Need to be careful since this uses raw pointers
    int maxChannel = std::min<int>(numChannels, this->mNumChannels);

    size_t end = (readPtr + numSamples) % bufferSize;


    if (readPtr + numSamples < bufferSize) // Doesn't wrap around
    {
        for (int channel = 0; channel < maxChannel; ++channel)
        {
            for (size_t i = readPtr, k = 0; i < end; ++i, ++k)
            {
                destination[channel][k] = data[channel][i];
            }
        }
    }
    else
    {
        size_t start = bufferSize - readPtr; // Position in source buffer after wrapping around circBuffer

        for (int channel = 0; channel < maxChannel; ++channel)
        {
            for (size_t i = readPtr, k = 0; i < bufferSize; ++i, ++k)
            {
                destination[channel][k] = data[channel][i];
            }
        }
        // Writing wraps to start
        for (int channel = 0; channel < maxChannel; ++channel)
        {
            for (size_t i = 0, k = start; i < end; ++i, ++k)
            {
                destination[channel][k] = data[channel][i];
            }
        }
    }

    readPtr = end;

}

std::vector<std::vector<SampleType>> CircularBuffer::read(size_t numSamples)
{
    std::vector<std::vector<SampleType>> workBuffer(mNumChannels, std::vector<SampleType>(numSamples));

    size_t end = (readPtr + numSamples) % bufferSize;
    size_t start = bufferSize - readPtr; // Position in source buffer after wrapping around circBuffer

    if (readPtr + numSamples < bufferSize) // Doesn't wrap around
    {
        for (int channel = 0; channel < mNumChannels; ++channel)
        {
            for (size_t i = readPtr, k = 0; i < end; ++i, ++k)
            {
                workBuffer[channel][k] = data[channel][i];
            }
        }
    }
    else
    {
        for (int channel = 0; channel < mNumChannels; ++channel)
        {
            for (size_t i = readPtr, k = 0; i < bufferSize; ++i, ++k)
            {
                workBuffer[channel][k] = data[channel][i];
            }
        }
        // Writing wraps to start
        for (int channel = 0; channel < mNumChannels; ++channel)
        {
            for (size_t i = 0, k = start; i < end; ++i, ++k)
            {
                workBuffer[channel][k] = data[channel][i];
            }
        }
    }

    readPtr = end;

    return workBuffer;
}

void CircularBuffer::reset()
{
    for (auto& it : data)
    {
        std::fill(it.begin(), it.end(), static_cast<SampleType>(0));
    }
    writePtr = 1000;
    readPtr = 0; 
}

int CircularBuffer::readWriteGap() const
{
    return static_cast<int>(((writePtr + bufferSize) - readPtr) % bufferSize);
}

} // namespace CamdenLabs