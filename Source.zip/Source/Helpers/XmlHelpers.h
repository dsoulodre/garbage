/*
  ================================================================================
  *      File                                          XmlHelpers.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "Helpers/CLAssert.h"

#include "JuceHeader.h"
#include <string>
#include <cstdint>
#include <exception>

namespace CamdenLabs
{

namespace XmlHelpers
{

// Exceptions

class XmlReadError final : public std::runtime_error
{
public:
    XmlReadError() noexcept : std::runtime_error("Error reading XML file") {}
};




using Node = juce::XmlElement;

using XmlTag = const juce::String;




// Reading functions
//=======================================================================================================

// Parse as string
inline juce::String getElementText(const Node* node);

// Parse as float
inline float getElementFloat(const Node* node);

// Parse as double
inline double getElementDouble(const Node* node);

// Parse as int
inline int getElementInt(const Node* node);

// Parse as uint64_t
inline uint64_t getElementLongInt(const Node* node);

// Verify that string is floating point number
inline bool isNumber(const juce::String& str);

// Verify that string is floating point number
inline bool isNumber(const std::string& str);

// Verify that string is integer
inline bool isInt(const juce::String& str);

// Verify that string is integer
inline bool isInt(const std::string& str);

// Throw XmlReadError if node == nullptr
inline void checkNode(const Node * node);



// Writing functions
//========================================================================================================

// Write string to node
inline void setElementText(Node* node, juce::String text);

inline void setElementInt(Node* node, int value);

// Write uint64_t to node
inline void setElementULL(Node* node, uint64_t value);

// Write double to node
inline void setElementDouble(Node* node, double value);

// Give attribute attrName with value "true" or "false" 
inline void setBoolAttribute(Node* node, juce::String attrName, bool val);






// Implementations
//===========================================================================================================

inline juce::String getElementText(const Node* node)
{
#if CL_DEBUG
// juce::XML handles an element with value "text" as having a child node with attribute "text".
// Debug mode checks for and handles this quirk being miused, and also trims whitespace.
    if (node->isTextElement())
    {
        return node->getText().trim();
    }
    else if (auto element = node->getFirstChildElement())
    {
        return element->getText().trim();
    }
    else
    {
        throw XmlReadError();
    }
#else
    if (auto element = node->getFirstChildElement())
    {
        return element->getText();
    }
    else
    {
        throw XmlReadError();
    }
#endif
}

inline float getElementFloat(const Node* node)
{
#if CL_DEBUG
// Debug mode verifies the element contains a valid float
    auto text = getElementText(node);
    if (!isNumber(text))
    {
        CLAssert(0);
        throw XmlReadError();
    }
    return text.getFloatValue();
#else
    return getElementText(node).getFloatValue();
#endif
}

inline double getElementDouble(const Node* node)
{
#if CL_DEBUG
// Debug mode verifies the element contains a valid double
    auto text = getElementText(node);
    if (!isNumber(text))
    {
        CLAssert(0);
        throw XmlReadError();
    }
    return text.getDoubleValue();
#else
    return getElementText(node).getDoubleValue();
#endif
}

inline int getElementInt(const Node* node)
{
#if CL_DEBUG
// Debug mode verifies the element contains a valid int
    auto text = getElementText(node);
    if (!isInt(text))
    {
        CLAssert(0);
        throw XmlReadError();
    }
    return text.getIntValue();
#else
    return getElementText(node).getIntValue();
#endif
}

inline uint64_t getElementLongInt(const Node* node)
{
    static_assert(sizeof(unsigned long long) == sizeof(uint64_t), "Unsigned long long must be equivalent to uint64_t");

#if CL_DEBUG
// Debug mode verifies the element contains a valid uint64_t
    auto text = getElementText(node).toStdString();
    if (!isInt(text))
    {
        CLAssert(0);
        throw XmlReadError();
    }
    return std::stoull(text);
#else
    return std::stoull(getElementText(node).toStdString());
#endif
}

inline bool isNumber(const juce::String& str)
{
    return isNumber(str.toStdString());
}

inline bool isNumber(const std::string& str)
{
    if (str.find_first_not_of("0123456789.-") != std::string::npos)
    {
        return false;
    }
    if (str.find('-', 1) != std::string::npos)
    {
        return false;
    }

    int decimalCount = 0;
    for (auto& it : str)
    {
        if (it == '.')
        {
            ++decimalCount;
            if (decimalCount > 1)
            {
                return false;
            }
        }
    }
    return true;
}

inline bool isInt(const juce::String& str)
{
    return isInt(str.toStdString());
}

inline bool isInt(const std::string& str)
{
    return str.find_first_not_of("0123456789") == std::string::npos;
}

inline void checkNode(const Node * node)
{
    if (node == nullptr)
    {
        CLAssert(0);
        throw XmlReadError();
    }
}

inline void setElementText(Node* node, juce::String text)
{
    node->addTextElement(text);
}

inline void setElementInt(Node* node, int value)
{
    node->addTextElement(juce::String(value));
}

inline void setElementULL(Node* node, uint64_t value)
{
    node->addTextElement(juce::String(value));
}

inline void setElementDouble(Node* node, double value)
{
    node->addTextElement(juce::String(value));
}

inline void setBoolAttribute(Node* node, juce::String attrName, bool val)
{
    if (val)
    {
        node->setAttribute(attrName, "true");
    }
    else
    {
        node->setAttribute(attrName, "false");
    }
}


} // namespace XmlHelpers

} // namespace CamdenLabs