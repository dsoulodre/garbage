/*
  ================================================================================
  *      File                                      CircularBuffer.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"

#include <vector>

namespace CamdenLabs
{

class CircularBuffer
{
public:

    using vecIt = std::vector<SampleType>::iterator;

    CircularBuffer(unsigned int channels, size_t length);

    void write(const std::vector<std::vector<SampleType>>& source);

    void write(const std::vector<std::vector<SampleType>>& source, size_t numSamples, size_t offset = 0); // Offset from start of source buffer

    void write(const std::vector<SampleType>& source, int numSamples, int offset = 0, bool writeToAllChannels = true);

    // Writes data directly to destination
    void read(SampleType** destination, int numChannels, size_t numSamples);

    std::vector<std::vector<SampleType>> read(size_t numSamples);

    
    void reset();

    // Returns # of samples write pointer is ahead of read pointer (always positive)
    int readWriteGap() const;
    int readPointer() const { return static_cast<int>(readPtr); }
    int writePointer() const { return static_cast<int>(writePtr); }


private:

    size_t readPtr{ 0 };
    size_t writePtr{ 1000 };

    const int mNumChannels;
    const size_t bufferSize;

    std::vector<std::vector<SampleType>> data;
};



} // namespace CamdenLabs