/*
  ==============================================================================

    CLAssert.h
    Created: 17 Mar 2024 1:37:40pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"

#if CL_DEBUG


void camdenLabsAssert(const char* message, const char* file, unsigned line);


#define CLAssert(cond) ( !(static_cast<bool>(cond)) ? camdenLabsAssert(#cond, __FILE__, static_cast<unsigned>(__LINE__)) : static_cast<void>(0) )

#else

#define CLAssert(cond) (static_cast<void>(0))

#endif