/*
  ================================================================================
  *      File                                          DelayBlock.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"

#include <vector>

namespace CamdenLabs
{

    // NOTE ON THREAD SAFETY:
    // There is a potential race condition when the delay buffer is resized
    // This class has no internal synchronization, so that has to be considered wherever this class is used
class DelayBlock
{
public:

    DelayBlock();

    DelayBlock(size_t maxSize, size_t delayLength = 1);

    SampleType run(SampleType inputSample);

    void setDelayLength(size_t delayLength);

    void setDelayLengthInMilliseconds(size_t milliseconds, double sampleRate);

    void resize(size_t maxSize);

    void reset();

    int delayInSamples() const;

private:

    size_t readPtr{ 0 };
    size_t writePtr{ 0 };
    std::vector<SampleType> delayBuffer;

};

} // namespace CamdenLabs