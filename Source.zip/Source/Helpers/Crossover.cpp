/*
==============================================================================

Crossover.cpp
Created: 7 Mar 2024 3:17:01pm
Author:  14372

==============================================================================
*/

#include "Helpers/Crossover.h"
#include "Helpers/CLAssert.h"

constexpr double root2over2 = 0.7071067811865475244;

namespace CamdenLabs
{

Crossover::Crossover()
    :   mLowPassFilters(1),
        mHighPassFilters(1)
{
    mLowPassFilters.reserve(maxNumStages);
    mHighPassFilters.reserve(maxNumStages);

    mLowPassFilters[0].setFrequency(mFrequency);
    mLowPassFilters[0].setFilterQ(root2over2);

    mHighPassFilters[0].setFrequency(mFrequency);
    mHighPassFilters[0].setFilterQ(root2over2);
}

auto Crossover::processSample(SampleType input) -> std::pair<SampleType, SampleType>
{
    SampleType high = input;
    SampleType low = input;

    for (auto& it : mHighPassFilters)
    {
        high = it.processSample(high);
    }

    for (auto& it : mLowPassFilters)
    {
        low = it.processSample(low);
    }

    return { high, low };
}

auto Crossover::processBlock(const std::vector<SampleType>& input) -> std::pair<std::vector<SampleType>, std::vector<SampleType>>
{
    size_t numSamples = input.size();
        
    std::vector<SampleType> high(numSamples);
    std::vector<SampleType> low(numSamples);

    for (size_t i = 0; i < numSamples; ++i)
    {
        auto [h, l] = processSample(input[i]);
        high[i] = h;
        low[i] = l;
    }

    return { high, low };
}

void Crossover::setFrequency(double value)
{
    mFrequency = value;
    for (auto& it : mHighPassFilters)
    {
        it.setFrequency(mFrequency);
    }
    for (auto& it : mLowPassFilters)
    {
        it.setFrequency(mFrequency);
    }
}

void Crossover::setNumStages(size_t numStages)
{
    mNumStages = numStages;

    CLAssert(mLowPassFilters.size() == mHighPassFilters.size());
    size_t previousNumStages = mLowPassFilters.size();

    mLowPassFilters.resize(numStages);
    mHighPassFilters.resize(numStages);

    for (auto i = 0ull; i < numStages; ++i)
    {
        auto& lpf = mLowPassFilters[i];
        auto& hpf = mHighPassFilters[i];

        lpf.setSampleRate(mSampleRate);
        hpf.setSampleRate(mSampleRate);

        lpf.setFrequency(mFrequency);
        hpf.setFrequency(mFrequency);

        lpf.setFilterQ(root2over2);
        hpf.setFilterQ(root2over2);
    }
}

void Crossover::setSampleRate(double sampleRate)
{
    for (auto& it : mLowPassFilters)
    {
        it.setSampleRate(sampleRate);
    }
    for (auto& it : mHighPassFilters)
    {
        it.setSampleRate(sampleRate);
    }
    mSampleRate = sampleRate;
}

} // namespace CamdenLabs