/*
  ================================================================================
  *      File                                        RandomNumGen.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"

#include <random>
#include <type_traits>
#include <climits>

namespace CamdenLabs
{

template<typename T>
class RandomNum
{
public:

	RandomNum();

	template<typename U>
	RandomNum(U min, U max);

	template<typename U>
	void setRange(T min, T max);

	auto operator()(void) -> T;

	static_assert(std::is_arithmetic_v<T>);

	static constexpr bool is32Bit = (sizeof(T) <= (32 / CHAR_BIT));
	static constexpr bool isReal = std::is_floating_point_v<T>;

	using Engine = std::conditional_t<is32Bit, std::mt19937, std::mt19937_64>;

	template<typename U>
	using DistributionType = std::conditional_t<isReal, std::uniform_real_distribution<U>, std::uniform_int_distribution<U>>;

	using Distribution = DistributionType<T>;

private:

	static std::random_device mSeeder;
	static Engine mEngine;
	Distribution mDistribution;

};

#include "RandomNumGen.tpp"

} // namespace CamdenLabs