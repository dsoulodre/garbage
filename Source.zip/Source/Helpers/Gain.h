/*
  ==============================================================================

    Gain.h
    Created: 9 Mar 2024 12:22:39pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"

#include <vector>
#include <type_traits>

namespace CamdenLabs
{
#if 0
class GainBlock
{
public:

    GainBlock(double gain = 1.f);

    void setGain(double gain);

    auto processBlock(std::vector<SampleType>& input) const -> std::vector<SampleType>&;

    auto processBlock(std::vector<std::vector<SampleType>>& input) const -> std::vector< std::vector<SampleType>>&;

    static auto applyGain(std::vector<SampleType>& input, const double gain) -> std::vector<SampleType>&;

    static auto applyGain(std::vector<std::vector<SampleType>>& input, const double gain) -> std::vector< std::vector<SampleType>>&;


private:
    double mGain{ 1.0 };
};
#endif

template<typename T = SampleType>
class Gain
{
public:

    Gain(T gain );

    void setGain(T gain);

    auto processBlock(std::vector<T>& input) const->std::vector<T>&;

    auto processBlock(std::vector<std::vector<T>>& input) const->std::vector<std::vector<T>>&;

    static auto applyGain(std::vector<T>& input, const T gain) -> std::vector<T>&;

    static auto applyGain(std::vector<std::vector<T>>& input, const T gain) -> std::vector<std::vector<T>>&;

private:
    T mGain{ 1 };

};

} // namespace CamdenLabs