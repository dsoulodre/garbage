/*
  ================================================================================
  *      File                                       SineGenerator.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"

#include <vector>

// Using a fixed table size allows memory optimization by sharing the table
#define SINE_GENERATOR_USE_FIXED_TABLE_SIZE 0

namespace CamdenLabs
{

// Simple sine generator for LFOs and such
class SineGenerator
{
public:
#if SINE_GENERATOR_USE_FIXED_TABLE_SIZE
    SineGenerator();

    SineGenerator(size_t unused);
#else
    SineGenerator(size_t tableSize = 128);
#endif

    SampleType getNextSample();

    void setFrequency(double freq, double sampleRate = Constants::defaultSampleRate);

    void setPhase(double phase);

    double frequency(double sampleRate = Constants::defaultSampleRate) const;

    double phase() const;

protected:

#if SINE_GENERATOR_USE_FIXED_TABLE_SIZE
    const std::vector<SampleType>& sineTable;
#else
    std::vector<SampleType> sineTable;
#endif

    SampleType tableIndex{ 0 };
    SampleType indexDelta{ 0 };
    SampleType mTableSize{ 0 };

};

} // namespace CamdenLabs