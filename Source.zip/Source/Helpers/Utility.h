/*
  ================================================================================
  *      File                                             Utility.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "Helpers/CLAssert.h"

#include <vector>
#include <cmath>
#include <string>
#include <limits>
#include <initializer_list>

#ifdef CL_CHECK_RANGE
    #error "Macro CL_CHECK_RANGE already defined"
#else
    #define CL_CHECK_RANGE(val, min, max) (assert(val >= min && val <= max))
#endif

namespace CamdenLabs
{

enum class ChannelLayout
{
    Stereo,
    ThreePointOne
};

namespace AudioBufferCast
{
    template<typename T = SampleType>
    inline auto toMono(std::vector<std::vector<T>>& multiChannelBuffer) -> std::vector<T>&
    {
        static_assert(std::is_floating_point_v<T>);
        assert(multiChannelBuffer.size() == 1);
        return multiChannelBuffer[0];
    }

    template<typename T = SampleType>
    inline auto toMono(const std::vector<std::vector<T>>& multiChannelBuffer) -> const std::vector<T>&
    {
        static_assert(std::is_floating_point_v<T>);
        assert(multiChannelBuffer.size() == 1);
        return multiChannelBuffer[0];
    }

    template<typename T = SampleType>
    inline auto toMono(std::vector<std::vector<T>>&& multiChannelBuffer) -> std::vector<T>
    {
        static_assert(std::is_floating_point_v<T>);
        assert(multiChannelBuffer.size() == 1);
        return std::vector<T>(std::move(multiChannelBuffer[0]));
    }

    template<typename T = SampleType>
    inline auto toMultiChannel(const std::vector<T>& monoBuffer) -> std::vector<std::vector<T>>
    {
        static_assert(std::is_floating_point_v<T>);
        return std::vector<std::vector<T>>(1, monoBuffer);
    }

    template<typename T = SampleType>
    inline std::vector<std::vector<T>> toMultiChannel(std::vector<T>&& monoBuffer)
    {
        static_assert(std::is_floating_point_v<T>);
        std::vector<std::vector<T>> vec;
        vec.emplace_back(std::move(monoBuffer));
        return vec;
    }

    inline std::vector<std::vector<float>> merge(std::initializer_list<std::vector<float>> monoBuffers)
    {
        return std::vector<std::vector<float>>(monoBuffers);
    }

    inline std::vector<std::vector<float>> merge(std::initializer_list<std::vector<std::vector<float>>> buffers)
    {
        std::vector<std::vector<float>> output;
        for (auto& iBuffer : buffers)
        {
            for (auto& iChan : iBuffer)
            {
                output.push_back(iChan);
            }
        }
        return output;
    }
} // namespace AudioBufferCast

namespace Utility
{
    template<typename T, typename = std::enable_if_t<std::is_arithmetic_v<T>>>
    constexpr bool isSigned()
    {
        return static_cast<T>(-1) < static_cast<T>(0);
    }

    template<typename T1, typename T2>
    constexpr bool signMismatch(T1 num1, T2 num2)
    {
        return (std::is_signed_v<T1> != std::is_unsigned_v<T2>) ;
    }

    template<typename T>
    constexpr int sign(T val)
    {
        static_assert(std::is_arithmetic_v<T>);
        return (val > static_cast<T>(0)) - (val < static_cast<T>(0));
    }

    template<typename T>
    constexpr T abs(T val)
    {
        return val * static_cast<T>(sign(val));
    }

    template<typename T,
             typename = std::enable_if_t<std::is_floating_point_v<T>>>
    constexpr double round(T val)
    {
        return static_cast<double>(static_cast<long long>(val) + 0.5 * sign(val));
    }

    template<typename T,
             typename = std::enable_if_t<std::is_floating_point_v<T>>>
    constexpr long long roundll(T val)
    {
        return static_cast<long long>(val + 0.5 * sign(val));
    }

    template<typename T,
             typename = std::enable_if_t<std::is_integral_v<T>>>
    constexpr bool isPowerOfTwo(T num)
    {
        if constexpr (std::is_signed_v<T>)
        {
            if (num < 0)
            {
                CLAssert(0);
                return false;
            }
        }
        return num && !(num & (num - 1));
    }

    template<typename T>
    constexpr bool almostEqual(T x, T y, T epsilon)
    {
        static_assert(std::is_floating_point_v<T>);
        assert(epsilon >= std::numeric_limits<T>::epsilon());

        return Utility::abs(x - y) < epsilon;
    }

    template<typename T>
    void checkRange(T val, T min = 0, T max = 1)
    {
#if CL_RELEASE_BUILD
        CL_UNUSED(val);
        CL_UNUSED(min);
        CL_UNUSED(max);
        return;
#endif
        if (min > max)
        {
            std::swap(min, max);
        }
        CLAssert(val >= min && val <= max);
    }

    template<typename T1, typename T2, typename T3>
    void checkRange(T1 val, T2 min = 0, T3 max = 1)
    {
        using Type = decltype(val + min + max);
        static_assert(std::is_arithmetic_v<Type>);

#if CL_RELEASE_BUILD
        CL_UNUSED(val);
        CL_UNUSED(min);
        CL_UNUSED(max);
        return;
#endif
        Type realMin = std::min(min, max);
        Type realMax = std::max(min, max);
        assert(val >= realMin && val <= realMax);
    }

    template<typename T>
    T constrainValue(T val, T min, T max)
    {
        if (min > max)
        {
            std::swap(min, max);
        }
        return std::max(std::min(val, max), min);
    }

    template<typename T>
    constexpr T remap(T value, T sourceRangeMin, T sourceRangeMax, T targetRangeMin, T targetRangeMax)
    {
        assert(sourceRangeMax != sourceRangeMin); // divide by 0

        const T sourceSize = sourceRangeMax - sourceRangeMin;
        const T targetSize = targetRangeMax - targetRangeMin;

        if constexpr (std::is_integral_v<T>)
        {
            const double sourcePos = (value - sourceRangeMin) / static_cast<double>(sourceSize);
            const double pos = targetSize * sourcePos;
            
#if CL_DEBUG
            assert((targetRangeMin + pos) > std::numeric_limits<T>::min() && (targetRangeMin + pos) < std::numeric_limits<T>::max());
#endif

            if constexpr (std::is_signed_v<T>)
            {
                return targetRangeMin + static_cast<T>(std::round(pos));
            }
            else // unsigned
            {
                return targetRangeMin + static_cast<T>(pos + 0.5);
            }
        }
        else
        {
            static_assert(std::is_floating_point_v<T>);
            return targetRangeMin + targetSize * (value - sourceRangeMin) / sourceSize;
        }
    }

    template<typename T>
    constexpr double map0to1(T value, T min, T max)
    {
        return (static_cast<double>(value) - min) / (max - min);
    }

    template<typename T>
    constexpr double normalize0to1(T value, T min, T max)
    {
        return (static_cast<double>(value) - min) / (max - min);
    }

    template<typename T>
    constexpr double normalize(double value, T min, T max)
    {
       return static_cast<double>(value - min) / (max - min);
    }

    template<typename T>
    constexpr T denormalize(double value, T min, T max)
    {
        CLAssert(value >= 0.0 && value <= 1.0);
        return min + (max - min) * value;
    }


    // Map (0,1) to some range (min, max) exponentially, with arbitrary skew
    inline float expDenorm(float normalizedValue, float minVal, float maxVal, float skew = 0.2f)
    {
        CLAssert(normalizedValue >= 0.0f && normalizedValue <= 1.0f);
        return minVal + (maxVal - minVal) * std::exp(std::log(normalizedValue) / skew);
    }

    // Special version of expDenorm for frequency, so that evenly spaced intervals of normalized value are evenly spaced in frequency scale
    inline float frequencyDenorm(float normalizedValue, float min = Constants::minFrequency, float max = Constants::maxFrequency)
    {
        CLAssert(normalizedValue >= 0.0f && normalizedValue <= 1.0f);
        return exp2((log2(max) - log2(min)) * normalizedValue + log2(min));
    }

    // Inverse of frequencyDenorm()
    inline float normalizeFreq(float frequency, float min = Constants::minFrequency, float max = Constants::maxFrequency)
    {
        CLAssert(frequency >= min && frequency <= max);
        return ( log2(frequency) - log2(min) ) / ( log2(max) - log2(min) );
    }

    inline float amplitudeTodB(float amplitude)
    {
        //                      20 / log_2(10)
        constexpr float magic = 6.02059991327f; 
        return magic * std::log2(amplitude);
    }

    inline float dBtoAmplitude(float dBgain)
    {
        //                      log_2(10) / 20
        constexpr float magic = 0.16609640474436f;
        return std::exp2(magic * dBgain);
    }

    inline double amplitudeTodB(double amplitude)
    {
        //                       20 / log_2(10)
        constexpr double magic = 6.02059991327962390427;
        return magic * std::log2(amplitude);
    }

    inline double dBtoAmplitude(double dBgain)
    {
        //                       log_2(10) / 20
        constexpr double magic = 0.16609640474436811739;
        return std::exp2(magic * dBgain);
    }

namespace ConstExprMath
{
    template<typename T>
    constexpr T abs(const T x)
    {
        static_assert(std::is_arithmetic_v<T>);
        return x > static_cast<T>(0) ? x : (static_cast<T>(-1) * x);
    }

    constexpr size_t factorial(size_t n)
    {
        if (n > 20)
        {
            return 0; // Overflow
        }
        if (n < 2)
        {
            return 1;
        }

        size_t val = n;
        for (size_t i = n - 1; i > 1; --i)
        {
            val *= i;
        }
        return val;
    }

    constexpr double pow(const double base, const int exponent)
    {
        if (exponent == 0)
        {
            return 1;
        }

        double val = base;
        for (int i = 0; i < abs(exponent); ++i)
        {
            val *= val;
        }

        if (exponent < 0)
        {
            return 1.0 / val;
        }
        return val;
    }

    constexpr double exp(double x)
    {
        constexpr size_t numTerms = 18;

        double sum = 0.0;
        for (size_t i = 0; i < numTerms; ++i)
        {
            sum += pow(x, static_cast<int>(i)) / factorial(i);
        }
        return sum;
    }

    //constexpr double log(double x)
    //{
    //    constexpr auto lessThan1 = [](double x) -> double
    //    {
    //
    //    };
    //
    //    if (x == 0.0)
    //    {
    //        return -std::numeric_limits<double>::infinity();
    //    }
    //    if (x == 1.0)
    //    {
    //        return 0.0;
    //    }
    //    if (x < 0.0)
    //    {
    //        return std::numeric_limits<double>::quiet_NaN();
    //    }
    //    if (x < 1)
    //    {
    //        return lessThan1(x);
    //    }
    //
    //}

    constexpr bool almostEqual(double a, double b)
    {
        return abs(a - b) < 0.000000001;
    }
    constexpr auto e = exp(1);
    static_assert(almostEqual(2.718281828, exp(1)));


} // namespace ConstExprMath

} // namespace Utilty

} // namespace CamdenLabs