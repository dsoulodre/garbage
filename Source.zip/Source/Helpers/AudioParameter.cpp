/*
  ================================================================================
  *      File                                    AudioParameter.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "AudioParameter.h"
#include "Helpers/CLAssert.h"
#include "Helpers/Utility.h"

#include <cmath>

namespace CamdenLabs
{

AudioParameter::AudioParameter()
{

}

void AudioParameter::setValue(double normalizedValue)
{
    CLAssert(normalizedValue >= 0.0 && normalizedValue <= 1.0);
    normalizedValue = std::max(std::min(normalizedValue, 1.0), 0.0);

    mNormalizedValue = normalizedValue;
    mValue = denormalize(mNormalizedValue);
}

void AudioParameter::setValue(bool booleanValue)
{
    booleanValue ? setValue(1.0) : setValue(0.0);
}

void AudioParameter::setValueUnchecked(double rawValue)
{
#if CL_DEBUG
    Utility::checkRange(rawValue, mMinVal, mMaxVal);
    rawValue = Utility::constrainValue(rawValue, mMinVal, mMaxVal);
#endif
    mValue = rawValue;
    mNormalizedValue = normalize(rawValue);
}

void AudioParameter::setRange(double min, double max)
{
    mMinVal = min;
    mMaxVal = max;
    if (mDefaultValue < std::min(min, max) || mDefaultValue > std::max(min, max))
    {
        mDefaultValue = mMinVal;
    }
    CLAssert(denormalize(0.0) == mMinVal && denormalize(1.0) == mMaxVal);
    setValue(mNormalizedValue);
}

void AudioParameter::setMin(double minValue)
{
    setRange(minValue, this->mMaxVal);
}

void AudioParameter::setMax(double maxValue)
{
    setRange(this->mMinVal, maxValue);
}

void AudioParameter::setExponential(double skew)
{
    if (skew <= 0.f)
    {
        CLAssert(0);
        skew = 1.0;
    }
    mSkew = skew;
}

void AudioParameter::setDefaultValue(double value)
{
    CLAssert(value >= std::min(mMinVal, mMaxVal) && value <= std::max(mMinVal, mMaxVal));
    mDefaultValue = value;
    setValueUnchecked(mDefaultValue);
}

void AudioParameter::setToDefault()
{
    setValueUnchecked(mDefaultValue);
}

void AudioParameter::setID(int id)
{
    mParamID = id;
}

double AudioParameter::denormalize(double normVal) const
{
    if (mSkew == 1.0) // Linear
    {
        return mMinVal + (mMaxVal - mMinVal) * normVal;
    }
    else // Exponential
    {
        return mMinVal + (mMaxVal - mMinVal) * std::exp(std::log(normVal) / mSkew);
    }
}

double AudioParameter::normalize(double rawVal) const
{
    if (mSkew == 1.0) // Linear
    {
        return (rawVal - mMinVal) / (mMaxVal - mMinVal);
    }
    else // Exponential
    {
        return std::exp(mSkew * std::log((rawVal - mMinVal) / (mMaxVal - mMinVal)));
    }
}

double AudioParameter::normalizedValue() const
{ 
    return mNormalizedValue;
}

double AudioParameter::defaultValue() const
{
    return mDefaultValue; 
}

double AudioParameter::defaultValueNormalized() const
{
    return normalize(mDefaultValue);
}

int AudioParameter::paramID() const
{ 
    return mParamID; 
}

double AudioParameter::get() const
{
    return mValue;
}

double AudioParameter::round() const
{
    return std::round(mValue);
}

float AudioParameter::toFloat() const
{
    return static_cast<float>(mValue);
}

int AudioParameter::toInt() const
{ 
    return static_cast<int>(mValue + 0.5);
}

unsigned int AudioParameter::toUnsigned() const
{
    return static_cast<unsigned int>(mValue + 0.5);
}

size_t AudioParameter::toSizeT() const
{
    return static_cast<size_t>(mValue + 0.5);
}

bool AudioParameter::toBool() const
{
    return static_cast<bool>(mValue);
}

AudioParameter::operator double() const
{
    return mValue; 
}

double AudioParameter::min() const
{ 
    return mMinVal; 
}

double AudioParameter::max() const
{
    return mMaxVal;
}

} // namespace CamdenLabs