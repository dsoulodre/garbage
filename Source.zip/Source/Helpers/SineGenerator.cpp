/*
  ================================================================================
  *      File                                     SineGenerator.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "Helpers/SineGenerator.h"
#include "Helpers/CLAssert.h"

#include <cmath>

namespace CamdenLabs
{

static constexpr double twoPi = 6.283185307179586477;

#if SINE_GENERATOR_USE_FIXED_TABLE_SIZE
constexpr size_t sineGeneratorTableSize = 128;

static auto getSineTable() -> std::vector<SampleType>&
{

    static bool init = false;
    static std::vector<SampleType> table(sineGeneratorTableSize);

    if (init == false)
    {
        double phase = 0.0;
        double delta = twoPi / (static_cast<double>(sineGeneratorTableSize - 1));

        for (auto& it : table)
        {
            it = static_cast<SampleType>(std::sin(phase));
            phase += delta;
        }
        table.push_back(table[0]);
        init = true;
    }

    return table;
}
#endif

#if SINE_GENERATOR_USE_FIXED_TABLE_SIZE
SineGenerator::SineGenerator()
    :   sineTable(getSineTable())
{
    mTableSize = static_cast<SampleType>(sineGeneratorTableSize);
}

SineGenerator::SineGenerator(size_t unused)
    :   SineGenerator()
{
    CL_UNUSED(unused);
}

#else
    
SineGenerator::SineGenerator(size_t tableSize)
{
    sineTable.resize(tableSize);
    double phase = 0.0;
    double delta = twoPi / (static_cast<double>(tableSize - 1));

    for (auto& it : sineTable)
    {
        it = static_cast<SampleType>(std::sin(phase));
        phase += delta;
    }
    sineTable.push_back(sineTable[0]);
    mTableSize = static_cast<SampleType>(tableSize);
}

#endif // SINE_GENERATOR_USE_FIXED_TABLE_SIZE

SampleType SineGenerator::getNextSample()
{
    CLAssert(tableIndex < mTableSize);
    int n = static_cast<int>(tableIndex);
    SampleType frac = tableIndex - static_cast<SampleType>(n);
    SampleType diff = sineTable[n + 1] - sineTable[n];

    tableIndex += indexDelta;
    if (tableIndex >= mTableSize)
    {
        tableIndex -= mTableSize;
    }

    return sineTable[n] + diff * frac;
}

void SineGenerator::setFrequency(double freq, double sampleRate)
{
    indexDelta = static_cast<float>(freq * mTableSize / sampleRate);
}

void SineGenerator::setPhase(double phase)
{
    CLAssert(phase >= 0.0 && phase <= twoPi);
    float pos = static_cast<float>(phase / twoPi);
    tableIndex = mTableSize * pos;
}

double SineGenerator::frequency(double sampleRate) const
{
    return indexDelta * sampleRate / mTableSize;
}

double SineGenerator::phase() const
{
    return twoPi * tableIndex / mTableSize;
}

} // namespace CamdenLabs
