/*
  ================================================================================
  *      File                                      AudioParameter.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"

#include <type_traits>
#include <functional>

namespace CamdenLabs
{

class AudioParameter
{
public:

    AudioParameter();
    AudioParameter(const AudioParameter&) = default;
    AudioParameter(AudioParameter&& other) noexcept = default;

    void setValue(double normalizedValue);

    void setValue(bool booleanValue);

    void setValueUnchecked(double rawValue);

    template <typename T, typename = std::enable_if_t<std::is_arithmetic_v<T> || std::is_enum_v<T>>>
    void setValueUnchecked(T rawValue)
    {
        setValueUnchecked(static_cast<double>(rawValue));
    }

    void setRange(double min, double max);

    template<typename T1, typename T2>
    void setRange(T1 min, T2 max)
    {
        static_assert(std::is_arithmetic_v<T1> && std::is_arithmetic_v<T2>);
        setRange(static_cast<double>(min), static_cast<double>(max));
    }

    void setMin(double minValue);

    void setMax(double maxValue);

    void setExponential(double skew);

    void setDefaultValue(double value);

    template<typename T, typename = std::enable_if_t<std::is_arithmetic_v<T> || std::is_enum_v<T>>>
    void setDefaultValue(T value)
    {
        setDefaultValue(static_cast<double>(value));
    }

    void setToDefault();

    // The index used in setParameterValue() to modify this parameter
    void setID(int id);

    template<typename enumType, typename = std::enable_if_t<std::is_enum_v<enumType>>>
    void setID(enumType id)
    {
        mParamID = static_cast<int>(id);
    }

    double get() const;

    double round() const;

    float toFloat() const;

    int toInt() const;

    unsigned int toUnsigned() const;

    size_t toSizeT() const;

    bool toBool() const;

    double normalizedValue() const;

    double defaultValue() const;

    double defaultValueNormalized() const;

    double min() const;

    double max() const;

    double denormalize(double normVal) const;

    double normalize(double rawVal) const;

    int paramID() const;

    template<class T>
    typename T::Parameters paramID() const
    {
        return static_cast<typename T::Parameters>(this->paramID());
    }

    operator double() const;

    template<typename T,
             typename = std::enable_if_t<std::is_enum_v<T>>>
    operator T() const
    {
        return static_cast<T>(this->toSizeT());
    }

    template<typename T>
    explicit operator T() const
    {
        static_assert(std::is_arithmetic_v<T>);
        if constexpr (std::is_floating_point_v<T>)
        {
            return static_cast<T>(mValue);
        }
        else if constexpr(std::is_signed_v<T>)
        {
            return static_cast<T>(this->toInt());
        }
        else // Unsigned
        {
            return static_cast<T>(this->toSizeT());
        }
    }

private:

    double mNormalizedValue{ 0.0 };
    double mValue{ 0.0 };

    double mMinVal{ 0.0 };
    double mMaxVal{ 1.0 };

    double mDefaultValue{ 0.0 };

    int mParamID{ 0 };

    double mSkew{ 1.0 };
};


// Function template definitions


} // namespace CamdenLabs