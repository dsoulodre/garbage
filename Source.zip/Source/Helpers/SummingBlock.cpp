/*
  ================================================================================
  *      File                                      SummingBlock.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "Helpers/SummingBlock.h"
#include "Helpers/CLAssert.h"

#include <algorithm>

namespace CamdenLabs
{

#if 0
SummingBlock::SummingBlock(int numChannels, size_t samplesToAllocate)
    :   data(numChannels)
{
    for (auto& it : data)
    {
        it.reserve(samplesToAllocate);
    }
}

void SummingBlock::reset(size_t size)
{
    for (auto& it : data)
    {
        it.resize(size);
        std::fill(it.begin(), it.end(), 0.0f);
    }
}

void SummingBlock::write(const std::vector<std::vector<SampleType>>& input)
{
    assert(input.size() <= data.size());
#if CL_DEBUG
    for (int i = 0; i < input.size(); ++i)
    {
        assert(input[i].size() == data[i].size());
    }
#endif

    for (int i = 0; i < input.size(); ++i)
    {
        std::transform(data[i].begin(), data[i].end(), input[i].begin(), data[i].begin(), std::plus<SampleType>());
    }
}

void SummingBlock::write(const std::vector<SampleType>& input)
{
    assert(input.size() == data[0].size());
    std::transform(input.begin(), input.end(), data[0].begin(), data[0].begin(), std::plus<SampleType>());
}

const std::vector<std::vector<SampleType>>& SummingBlock::read()
{
    return data;
}

const std::vector<SampleType>& SummingBlock::readMono()
{
    return data[0];
}
#endif






template<typename T>
SummingBlock<T>::SummingBlock(int numChannels, size_t samplesToAllocate)
    : data(numChannels)
{
    for (auto& it : data)
    {
        it.reserve(samplesToAllocate);
    }
}

template<typename T>
void SummingBlock<T>::reset(size_t size)
{
    for (auto& it : data)
    {
        it.resize(size);
        std::fill(it.begin(), it.end(), 0.0f);
    }
}

template<typename T>
void SummingBlock<T>::write(const std::vector<std::vector<T>>& input)
{
    CLAssert(input.size() <= data.size());
#if CL_DEBUG
    for (int i = 0; i < input.size(); ++i)
    {
        CLAssert(input[i].size() == data[i].size());
    }
#endif

    for (int i = 0; i < input.size(); ++i)
    {
        std::transform(data[i].begin(), data[i].end(), input[i].begin(), data[i].begin(), std::plus<T>());
    }
}

template<typename T>
void SummingBlock<T>::write(const std::vector<T>& input)
{
    CLAssert(input.size() == data[0].size());
    std::transform(input.begin(), input.end(), data[0].begin(), data[0].begin(), std::plus<T>());
}

template<typename T>
auto SummingBlock<T>::read() -> const std::vector<std::vector<T>>&
{
    return data;
}

template<typename T>
auto SummingBlock<T>::readMono() -> const std::vector<T>&
{
    return data[0];
}

template class SummingBlock<float>;
template class SummingBlock<double>;


} // namespace