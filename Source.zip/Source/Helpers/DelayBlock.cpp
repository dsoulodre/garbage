/*
  ================================================================================
  *      File                                        DelayBlock.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "Helpers/DelayBlock.h"
#include "Helpers/CLAssert.h"

#include <algorithm>

namespace CamdenLabs
{

DelayBlock::DelayBlock()
{
    delayBuffer.resize(1, 0.f);
}

DelayBlock::DelayBlock(size_t maxSize, size_t delayLength)
    :   delayBuffer(delayLength)
{
    CLAssert(delayLength < maxSize);
    delayBuffer.resize(maxSize, 0.f);
    setDelayLength(delayLength);
}

SampleType DelayBlock::run(SampleType inputSample)
{
    // Potential race condition:
    // Message thread resizes delayBuffer
    delayBuffer[writePtr] = inputSample;
    SampleType temp = delayBuffer[readPtr];
    writePtr = (writePtr + 1) % delayBuffer.size();
    readPtr = (readPtr + 1) % delayBuffer.size();
    return temp;
}

void DelayBlock::setDelayLength(size_t delayLength)
{
    if (delayLength >= delayBuffer.size())
    {
        resize(std::max(delayLength, delayBuffer.size() * 2));
    }

    readPtr = (delayBuffer.size() + writePtr - delayLength) % delayBuffer.size();
}

void DelayBlock::setDelayLengthInMilliseconds(size_t milliseconds, double sampleRate)
{
    setDelayLength(static_cast<size_t>(sampleRate * static_cast<double>(milliseconds)));
}

void DelayBlock::resize(size_t maxSize)
{
    CLAssert(maxSize != 0);
    delayBuffer.resize(maxSize, 0.f);
}

void DelayBlock::reset()
{
    readPtr = writePtr = 0;
    std::fill(delayBuffer.begin(), delayBuffer.end(), static_cast<SampleType>(0));
}

int DelayBlock::delayInSamples() const
{
    return static_cast<int>((writePtr - readPtr + delayBuffer.size()) % delayBuffer.size());
}

} // namespace CamdenLabs