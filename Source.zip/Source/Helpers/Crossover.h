/*
  ==============================================================================

    Crossover.h
    Created: 7 Mar 2024 3:17:01pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "Helpers/AudioParameter.h"
#include "AudioComponents/FilterIMPL.h"

namespace CamdenLabs
{

class Crossover
{
public:

    Crossover();

    void setFrequency(double value);

    void setNumStages(size_t numStages);

    // Returns samples as [high, low] 
    auto processSample(SampleType input) -> std::pair<SampleType, SampleType>;

    // Returns buffers as [high, low]
    auto processBlock(const std::vector<SampleType>& input) -> std::pair<std::vector<SampleType>, std::vector<SampleType>>;

    void setSampleRate(double sampleRate);

    static constexpr size_t maxNumStages = 6;

private:
    double mSampleRate{ Constants::defaultSampleRate };
    double mFrequency{ 50.0 };
    size_t mNumStages{ 1ULL };
       
    std::vector<HighPassFilter> mHighPassFilters;
    std::vector<LowPassFilter> mLowPassFilters;
};


} // namespace CamdenLabs