/*
  ================================================================================
  *      File                                        SummingBlock.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"

#include <vector>

namespace CamdenLabs
{
#if 0
class SummingBlock
{
public:

    SummingBlock(int numChannels = 1, size_t samplesToAllocate = 480);

    /* Needs to be called between reads to zero out buffer
    * @param numChannels        This cannot be changed once the object is created
    * @param size               All buffers being summed need to have the same size, set here before writing
    */
    void reset(size_t size);

    void write(const std::vector<std::vector<SampleType>>& input);

    // Overload for mono audio
    void write(const std::vector<SampleType>& input);

    const std::vector<std::vector<SampleType>>& read();

    const std::vector<SampleType>& readMono();

private:
    std::vector<std::vector<SampleType>> data;

};
#endif

template<typename T = SampleType>
class SummingBlock
{
public:

    SummingBlock(int numChannels = 1, size_t samplesToAllocate = Constants::defaultBufferSize);

    /* Needs to be called between reads to zero out buffer
    * @param numChannels        This cannot be changed once the object is created
    * @param size               All buffers being summed need to have the same size, set here before writing
    */
    void reset(size_t size);

    void write(const std::vector<std::vector<T>>& input);

    // Overload for mono audio
    void write(const std::vector<T>& input);

    auto read() -> const std::vector<std::vector<T>>&;

    auto readMono() -> const std::vector<T>&;

private:
    std::vector<std::vector<T>> data;
};

} // namespace