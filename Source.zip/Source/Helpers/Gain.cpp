/*
  ==============================================================================

    Gain.cpp
    Created: 9 Mar 2024 12:22:39pm
    Author:  14372

  ==============================================================================
*/

#include "Gain.h"

#define CL_PARALLELIZE 0

#include <algorithm>
#if CL_PARALLELIZE
#include <functional>
#include <execution>
#endif

namespace CamdenLabs
{

#if 0
GainBlock::GainBlock(double gain)
    :   mGain(gain)
{

}

void GainBlock::setGain(double gain)
{
    mGain = gain;
}

auto GainBlock::processBlock(std::vector<SampleType>& input) const -> std::vector<SampleType>&
{
    return applyGain(input, mGain);
}

auto GainBlock::processBlock(std::vector<std::vector<SampleType>>& input) const -> std::vector< std::vector<SampleType>>&
{
    return applyGain(input, mGain);
}

auto GainBlock::applyGain(std::vector<SampleType>& input, const double gain) -> std::vector<SampleType>&
{
    if (gain == 1.f)
    {
        return input;
    }
    if (gain == 0.f)
    {
        std::fill(input.begin(), input.end(), 0.f);
        return input;
    }
#if CL_PARALLELIZE
    const auto operation = [gain](SampleType x) { return x * gain; };
    std::transform(std::execution::par_unseq, input.begin(), input.end(), input.begin(), operation);
#else
    for (auto& sample : input)
    {
        sample *= gain;
    }
#endif
    return input;
}

auto GainBlock::applyGain(std::vector<std::vector<SampleType>>& input, const double gain) -> std::vector< std::vector<SampleType>>&
{
#if CL_PARALLELIZE

    const auto operation = [gain](SampleType x) { return x * gain; };

    for (auto& buffer : input)
    {
        std::transform(std::execution::par_unseq, buffer.begin(), buffer.end(), buffer.begin(), operation);
    }

#else
    for (auto& chan : input)
    {
        applyGain(chan, gain);
    }
#endif
    return input;
}

#endif

template<typename T>
Gain<T>::Gain(T gain)
    : mGain(gain)
{
    static_assert(std::is_floating_point_v<T>);
}

template<typename T>
void Gain<T>::setGain(T gain)
{
    mGain = gain;
}

template<typename T>
auto Gain<T>::processBlock(std::vector<T>& input) const -> std::vector<T>&
{
    return applyGain(input, mGain);
}

template<typename T>
auto Gain<T>::processBlock(std::vector<std::vector<T>>& input) const -> std::vector<std::vector<T>>&
{
    return applyGain(input, mGain);
}

template<typename T>
auto Gain<T>::applyGain(std::vector<T>& input, const T gain) -> std::vector<T>&
{
    if (gain == static_cast<T>(1))
    {
        /* noop */
    }
    else if (gain == static_cast<T>(0))
    {
        std::fill(input.begin(), input.end(), static_cast<T>(0));
    }
    else
    {
        for (auto& sample : input)
        {
            sample *= gain;
        }
    }

    return input;
}

template<typename T>
auto Gain<T>::applyGain(std::vector<std::vector<T>>& input, const T gain) -> std::vector<std::vector<T>>&
{
    for (auto& chan : input)
    {
        applyGain(chan, gain);
    }

    return input;
}

template class Gain<float>;
template class Gain<double>;



} // namespace CamdenLabs