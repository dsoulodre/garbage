/*
  ==============================================================================

    CamdenDSPApp.h
    Created: 5 Mar 2024 10:02:23am
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "AudioProcessor/AudioProcessor.h"
#include "ComponentManager/AudioComponentManager.h"
#include "ComponentManager/Preset.h"
#include "Helpers/Utility.h"


#include <vector>
#include <mutex>
#include <string>

// Forward declarations (global namespace)
class CamdenDSPAudioProcessor;
class CamdenDSPMainWindow;

namespace CamdenLabs
{

class CamdenDSP final
{
public:

    enum class NoiseMode
    {
        None,
        Tone,
        Noise
    };

    CamdenDSP();

    auto processBlock(std::vector<std::vector<SampleType>>& buffer) -> std::vector<std::vector<SampleType>>&;

    void setGuiObject(CamdenDSPMainWindow* guiWindow);

    void setDim(bool shouldBeDimmed);

    void setSampleRate(double sampleRate);

    void setBufferSize(size_t bufferSize);

    void setNoiseMode(NoiseMode mode, bool sendDirectlyToOutput);
    
    // Load a built-in preset. Returns true on success, else false
    bool loadPreset(size_t index);

    void loadPreset(std::string filePath);
    void savePreset(std::string filePath) const;

    static auto resourceDirectory() -> juce::File;

    auto availablePresets() const -> std::vector<std::string>;

    double sampleRate() const;

private:

    void loadPresetInternal(Preset& preset);

    void removeAllComponenets();

    mutable std::mutex mMutex;

    AudioProcessor mAudioProcessor;
    AudioComponentManager mComponentManager;
    CamdenDSPMainWindow* mGuiWindow{ nullptr };

    static constexpr SampleType dimGain = 0.1; // -20dB
    bool isDimmed{ false };

    struct PresetData
    {
        std::unique_ptr<Preset> data{ nullptr };
        std::string name;
    };

    std::vector<PresetData> mPresets;

    NoiseMode mNoiseMode{ NoiseMode::None };
    bool mNoiseDirectToOutput{ false };

    double mSampleRate{ Constants::defaultSampleRate };

};

} // namespace CamdenLabs
