/*
  ==============================================================================

    StereoProcessingBlock.cpp
    Created: 8 Mar 2024 2:44:14pm
    Author:  14372

  ==============================================================================
*/

#include "StereoProcessingBlock.h"
#include "Helpers/CLAssert.h"

#include <algorithm>

namespace CamdenLabs
{

StereoProcessingBlock::StereoProcessingBlock()
{
    mGain.setID(Parameters::Gain);
    mGain.setRange(minGain, maxGain);
    mGain.setDefaultValue(1.0);

    mPostProcessingBlock.setNumChannels(2);
}

void StereoProcessingBlock::setParameterValue(int index, double value)
{
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Gain:
        setGain(mGain.denormalize(value));
        return; 
    }
}

void StereoProcessingBlock::setEnabled(bool shouldBeEnabled)
{
    mEnabled = shouldBeEnabled;
}

auto StereoProcessingBlock::getParameters() -> std::vector<AudioParameter*>
{
    return { &mGain };
}

void StereoProcessingBlock::setSampleRate(double newSampleRate)
{
    mPostProcessingBlock.setSampleRate(newSampleRate);
}

auto StereoProcessingBlock::processBlock(std::vector<std::vector<SampleType>>& input) -> std::vector<std::vector<SampleType>>&
{
    CLAssert(input.size() >= Constants::numInputs);

    mPostProcessingBlock.processBlock(input);

    const SampleType gain = mEnabled ? static_cast<SampleType>(mGain) : 0.0;
    for (auto& chan : input)
    {
        for (auto& sample : chan)
        {
            sample *= gain;
        }
    }

    return input;
}

int StereoProcessingBlock::numInputChannels() const
{
    return 2;
}

int StereoProcessingBlock::numOutputChannels() const
{
    return 2;
}

void StereoProcessingBlock::setGain(double value)
{
    mGain.setValueUnchecked(value);
}

auto StereoProcessingBlock::processBlock(std::vector<SampleType>& input) -> std::vector<SampleType>&
{
    // No mono
    CLAssert(0);
    return input;
}


} // namespace CamdenLabs