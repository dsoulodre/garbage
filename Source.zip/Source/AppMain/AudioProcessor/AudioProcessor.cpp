/*
  ==============================================================================

    AudioProcessor.cpp
    Created: 2 Mar 2024 4:42:20pm
    Author:  14372

  ==============================================================================
*/

#include "AudioProcessor.h"
#include "Helpers/CLAssert.h"

namespace CamdenLabs
{

AudioProcessor::AudioProcessor()
{

}

auto AudioProcessor::processBlock(std::vector<std::vector<SampleType>>& buffer) -> std::vector<std::vector<SampleType>>&
{
    mStereoProcessing.processBlock(buffer);

    for (size_t chan = 0; chan < Constants::numInputs; ++chan)
    {
        mMonoProcessing[chan].processBlock(buffer[chan]);
    }

    mCrossover.processBlock(buffer);

    for (size_t chan = 0; chan < Constants::numOutputs; ++chan)
    {
        mFinalProcessing[chan].processBlock(buffer[chan]);
    }

    return buffer;
}

void AudioProcessor::setSampleRate(double sampleRate)
{
    if (sampleRate == mSampleRate)
    {
        return;
    }

    mStereoProcessing.setSampleRate(sampleRate);

    for (auto& it : mMonoProcessing)
    {
        it.setSampleRate(sampleRate);
    }

    mCrossover.setSampleRate(sampleRate);

    for (auto& it : mFinalProcessing)
    {
        it.setSampleRate(sampleRate);
    }

    mSampleRate = sampleRate;
}

void AudioProcessor::setBufferSize(size_t bufferSize)
{
    mBufferSize = bufferSize;
}

} // namespace CamdenLabs