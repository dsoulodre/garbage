/*
  ==============================================================================

    MonoProcessingBlock.h
    Created: 9 Mar 2024 12:20:34pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "AudioComponents/AudioComponent.h"
#include "AudioComponents/PostProcessingBlock.h"

/*
Gain (dB) [0.1dB resolution]
- EQ (filters)
- Phase switch (polarity)
*/

namespace CamdenLabs
{

class MonoProcessingBlock : public AudioProcessorComponent
{
public:

    enum class Parameters
    {
        Gain = 1,
        Phase
    };

    MonoProcessingBlock();

    void setParameterValue(int index, double value) override;

    void setEnabled(bool shouldBeEnabled) override;

    auto getParameters() -> std::vector<AudioParameter*> override;

    void setSampleRate(double newSampleRate) override;

    int numInputChannels() const override;
    int numOutputChannels() const override;

    auto processBlock(std::vector<SampleType>& input) -> std::vector<SampleType>& override;

    auto processBlock(std::vector<std::vector<SampleType>>& input) -> std::vector<std::vector<SampleType>>& override;

    void setGain(double gain);

    void setPhaseInverted(bool shouldBeInverted);

    bool phaseIsInverted() const;

    PostProcessingBlock mProcessingBlock;

    static constexpr double minGain = 0.0;
    static constexpr double maxGain = 2.0;

private:

    AudioParameter mGain;
    AudioParameter mPhase;

    bool mEnabled{ true };
};


} // namespace CamdenLabs
