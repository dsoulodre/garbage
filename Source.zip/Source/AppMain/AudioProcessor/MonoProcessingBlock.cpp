/*
  ==============================================================================

    MonoProcessingBlock.cpp
    Created: 9 Mar 2024 12:20:34pm
    Author:  14372

  ==============================================================================
*/

#include "MonoProcessingBlock.h"
#include "Helpers/CLAssert.h"


namespace CamdenLabs
{

MonoProcessingBlock::MonoProcessingBlock()
{
    mGain.setID(Parameters::Gain);
    mGain.setRange(minGain, maxGain);
    mGain.setDefaultValue(1.0);

    mPhase.setID(Parameters::Phase);

    mProcessingBlock.setNumChannels(1);
}

void MonoProcessingBlock::setParameterValue(int index, double value)
{
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Gain:
        setGain(mGain.denormalize(value));
        return;

    case Parameters::Phase:
        mPhase.setValue(value);
        setPhaseInverted(mPhase.toBool());
        return;

    default:
        return;
    }
}

void MonoProcessingBlock::setEnabled(bool shouldBeEnabled)
{
    mEnabled = shouldBeEnabled;
}

auto MonoProcessingBlock::getParameters() -> std::vector<AudioParameter*>
{
    return { &mGain, &mPhase };
}

void MonoProcessingBlock::setSampleRate(double newSampleRate)
{
    mProcessingBlock.setSampleRate(newSampleRate);
}

int MonoProcessingBlock::numInputChannels() const
{
    return 1;
}

int MonoProcessingBlock::numOutputChannels() const
{
    return 1;
}

auto MonoProcessingBlock::processBlock(std::vector<SampleType>& input) -> std::vector<SampleType>&
{
    const double sign = phaseIsInverted() ? -1.0 : 1.0;
    const SampleType gain = mEnabled ? (static_cast<SampleType>(mGain) * sign) : (SampleType)0;

    for (auto& sample : input)
    {
        sample *= gain;
    }

    return mProcessingBlock.processBlock(input);
}

auto MonoProcessingBlock::processBlock(std::vector<std::vector<SampleType>>& input) -> std::vector<std::vector<SampleType>>&
{
    CLAssert(input.size() == 1);
    processBlock(input[0]);
    return input;
}

void MonoProcessingBlock::setGain(double gain)
{
    mGain.setValueUnchecked(gain);
}

void MonoProcessingBlock::setPhaseInverted(bool shouldBeInverted)
{
    mPhase.setValueUnchecked(shouldBeInverted);
}

bool MonoProcessingBlock::phaseIsInverted() const
{
    return mPhase.toBool();
}

} // namespace CamdenLabs