/*
  ==============================================================================

    AudioProcessor.h
    Created: 2 Mar 2024 4:42:20pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "AudioComponents/AudioComponent.h"

#include "StereoProcessingBlock.h"
#include "MonoProcessingBlock.h"
#include "CrossoverBlock.h"
#include "FinalProcessingBlock.h"
#include "Helpers/CLAssert.h"

#include <vector>
#include <array>

namespace CamdenLabs
{

class AudioProcessor final
{
public:
    AudioProcessor();

    auto processBlock(std::vector<std::vector<SampleType>>& buffer) -> std::vector<std::vector<SampleType>>&;

    void setSampleRate(double sampleRate);

    void setBufferSize(size_t bufferSize);

    StereoProcessingBlock mStereoProcessing;
    std::array<MonoProcessingBlock, Constants::numInputs> mMonoProcessing;
    CrossoverBlock mCrossover;
    std::array<FinalProcessingBlock, Constants::numOutputs> mFinalProcessing;

private:

    friend class Preset;
    double mSampleRate{ Constants::defaultSampleRate };
    size_t mBufferSize{ Constants::defaultBufferSize };

};

} // namespace CamdenLabs