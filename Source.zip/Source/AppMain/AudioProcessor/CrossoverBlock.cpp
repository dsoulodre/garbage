/*
  ==============================================================================

    Crossover.cpp
    Created: 7 Mar 2024 10:15:48am
    Author:  14372

  ==============================================================================
*/

#include "CrossoverBlock.h"
#include "Helpers/CLAssert.h"

constexpr double root2over2 = 0.7071067811865475244;

namespace CamdenLabs
{

CrossoverBlock::CrossoverBlock()
{
    mFrequency.setID(Parameters::Frequency);
    mFrequency.setRange(50.0, 5000.0);
    mFrequency.setExponential(0.2);

    mNumStages.setID(Parameters::NumStages);
    mNumStages.setRange(1, Crossover::maxNumStages);
}

void CrossoverBlock::setParameterValue(int index, double value)
{
    CLAssert(value >= 0.0 && value <= 1.0);
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Frequency:
        setFrequency(mFrequency.denormalize(value));
        return;

    case Parameters::NumStages:
        mNumStages.setValue(value);
        setNumStages(mNumStages.toSizeT());
        return;

    default:
        CLAssert(0);
        return;
    }
}

void CrossoverBlock::setEnabled(bool shouldBeEnabled)
{
    CL_UNUSED(shouldBeEnabled);
}

std::vector<AudioParameter*> CrossoverBlock::getParameters()
{
    return { &mFrequency, &mNumStages };
}

void CrossoverBlock::setSampleRate(double newSampleRate)
{
    mLeft.setSampleRate(newSampleRate);
    mRight.setSampleRate(newSampleRate);
}

std::vector<SampleType>& CrossoverBlock::processBlock(std::vector<SampleType>& input)
{
    CLAssert(0); // No mono
    return input;
}

std::vector<std::vector<SampleType>>& CrossoverBlock::processBlock(std::vector<std::vector<SampleType>>& input)
{
    std::scoped_lock<std::mutex> guard(mMutex);

    if (input.size() < numOutputChannels())
    {
        input.resize(numOutputChannels());
    }
    static_assert(Constants::numOutputs == 4);

    auto [leftHigh, leftLow] = mLeft.processBlock(input[0]);
    auto [rightHigh, rightLow] = mRight.processBlock(input[1]);

    input[0] = std::move(leftHigh);
    input[1] = std::move(rightHigh);
    input[2] = std::move(leftLow);
    input[3] = std::move(rightLow);

    return input;
}

void CrossoverBlock::setFrequency(double value)
{
    std::scoped_lock<std::mutex> guard(mMutex);
    mFrequency.setValueUnchecked(value);

    mLeft.setFrequency(mFrequency);
    mRight.setFrequency(mFrequency);
}

void CrossoverBlock::setNumStages(size_t numStages)
{
    std::scoped_lock<std::mutex> guard(mMutex);
    mNumStages.setValueUnchecked(numStages);

    mLeft.setNumStages(numStages);
    mRight.setNumStages(numStages);
}

int CrossoverBlock::numInputChannels() const
{
    return Constants::numInputs;
}

int CrossoverBlock::numOutputChannels() const
{
    return Constants::numOutputs;
}

} // namespace CamdenLabs