/*
  ==============================================================================

    Crossover.h
    Created: 7 Mar 2024 10:15:48am
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "AudioComponents/AudioComponent.h"
#include "Helpers/AudioParameter.h"
#include "Helpers/Crossover.h"

#include <mutex>

namespace CamdenLabs
{

class CrossoverBlock : public AudioProcessorComponent
{
public:

    enum class Parameters
    {
        Frequency = 1,
        NumStages
    };

    CrossoverBlock();

    void setParameterValue(int index, double value) override;

    void setEnabled(bool shouldBeEnabled) override;

    std::vector<AudioParameter*> getParameters() override;

    void setSampleRate(double newSampleRate) override;

    std::vector<SampleType>& processBlock(std::vector<SampleType>& input) override;
    std::vector<std::vector<SampleType>>& processBlock(std::vector<std::vector<SampleType>>& input) override;

    void setFrequency(double value);

    void setNumStages(size_t numStages);

    int numInputChannels() const override;
    int numOutputChannels() const override;

private:

    mutable std::mutex mMutex;

    AudioParameter mFrequency;
    AudioParameter mNumStages;

    Crossover mLeft;
    Crossover mRight;
};

} // namespace CamdenLabs