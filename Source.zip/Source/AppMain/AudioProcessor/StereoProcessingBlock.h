/*
  ==============================================================================

    StereoProcessingBlock.h
    Created: 8 Mar 2024 2:44:14pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "AudioComponents/AudioComponent.h"
#include "AudioComponents/PostProcessingBlock.h"

/*
Stereo gain (dB) [0.1dB resolution]
(one control for both chans)
- Stereo EQ (filters)
(controls linked to both L & R chans)
- Expander processor (imaging)
*/

namespace CamdenLabs
{

class StereoProcessingBlock : public AudioProcessorComponent
{
public:

    enum class Parameters
    {
        Gain = 1
    };

    StereoProcessingBlock();

    void setParameterValue(int index, double value) override;

    void setEnabled(bool shouldBeEnabled) override;

    auto getParameters() -> std::vector<AudioParameter*> override;

    void setSampleRate(double newSampleRate) override;

    auto processBlock(std::vector<std::vector<SampleType>>& input) -> std::vector<std::vector<SampleType>>& override;

    int numInputChannels() const override;
    int numOutputChannels() const override;

    void setGain(double value);

    PostProcessingBlock mPostProcessingBlock;

    static constexpr double minGain = 0.0;
    static constexpr double maxGain = 2.0;
    
private:

    auto processBlock(std::vector<SampleType>& input) -> std::vector<SampleType> & override;

    AudioParameter mGain;
    bool mEnabled{ true };

};


} // namespace CamdenLabs