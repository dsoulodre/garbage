/*
  ==============================================================================

    FinalProcessingBlock.h
    Created: 9 Mar 2024 12:20:41pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "AudioComponents/AudioComponent.h"
#include "AudioComponents/PostProcessingBlock.h"
#include "Helpers/DelayBlock.h"


/*
- Gain (dB) [0.1dB resolution]
- delay (in samples, max delay =10ms)
- EQ (filters)
- Phase switch (polarity)
*/


namespace CamdenLabs
{


class FinalProcessingBlock : public AudioProcessorComponent
{
public:

    enum class Parameters
    {
        Gain = 1,
        Delay,
        Polarity
    };

    static constexpr size_t maxDelay = 480;

    FinalProcessingBlock();

    void setParameterValue(int index, double value) override;

    void setEnabled(bool shouldBeEnabled) override;

    auto getParameters() -> std::vector<AudioParameter*> override;

    void setSampleRate(double newSampleRate) override;

    auto processBlock(std::vector<SampleType>& input) -> std::vector<SampleType> & override;

    auto processBlock(std::vector<std::vector<SampleType>>& input) -> std::vector<std::vector<SampleType>> & override;

    int numInputChannels() const override;
    int numOutputChannels() const override;

    void setGain(double gain);

    void setDelay(size_t numSamples);

    void setPhaseInverted(bool shouldBeInverted);

    bool phaseIsInverted() const;

    PostProcessingBlock mPostProcessing;

    static constexpr double minGain = 0.0;
    static constexpr double maxGain = 2.0;

private:

    AudioParameter mGain;
    AudioParameter mDelay;
    AudioParameter mPolarity;

    DelayBlock mDelayBlock;

    bool mEnabled{ true };
};

} // namespace CamdenLabs