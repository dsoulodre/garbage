/*
  ==============================================================================

    FinalProcessingBlock.cpp
    Created: 9 Mar 2024 12:20:41pm
    Author:  14372

  ==============================================================================
*/

#include "FinalProcessingBlock.h"
#include "Helpers/CLAssert.h"

namespace CamdenLabs
{

FinalProcessingBlock::FinalProcessingBlock()
{
    mGain.setID(Parameters::Gain);
    mGain.setRange(minGain, maxGain);
    mGain.setDefaultValue(1.0);

    mDelay.setID(Parameters::Delay);
    mDelay.setRange(0ULL, maxDelay);

    mPolarity.setID(Parameters::Polarity);

    mDelayBlock.resize(maxDelay);
    mDelayBlock.setDelayLength(mDelay.toInt());

    mPostProcessing.setNumChannels(1);
}

void FinalProcessingBlock::setParameterValue(int index, double value)
{
    switch (static_cast<Parameters>(index))
    {
    case Parameters::Gain:
        setGain(mGain.denormalize(value));
        return;

    case Parameters::Delay:
        mDelay.setValue(value);
        setDelay(mDelay.toSizeT());
        return;

    case Parameters::Polarity:
        mPolarity.setValue(value);
        setPhaseInverted(mPolarity.toBool());
        return;
    }
}

void FinalProcessingBlock::setEnabled(bool shouldBeEnabled)
{
    mEnabled = shouldBeEnabled;
}

auto FinalProcessingBlock::processBlock(std::vector<SampleType>& input) -> std::vector<SampleType>&
{
    const double sign = phaseIsInverted() ? -1.0 : 1.0;
    const SampleType gain = mEnabled ? (static_cast<SampleType>(mGain) * sign) : (SampleType)0;

    for (auto& sample : input)
    {
        sample = mDelayBlock.run(sample) * gain;
    }

    return mPostProcessing.processBlock(input);
}

auto FinalProcessingBlock::processBlock(std::vector<std::vector<SampleType>>& input) -> std::vector<std::vector<SampleType>>&
{
    CLAssert(input.size() == 1);
    processBlock(input[0]);
    return input;
}

int FinalProcessingBlock::numInputChannels() const
{
    return 1;
}

int FinalProcessingBlock::numOutputChannels() const
{
    return 1;
}

auto FinalProcessingBlock::getParameters() -> std::vector<AudioParameter*>
{
    return { &mGain, &mDelay, &mPolarity };
}

void FinalProcessingBlock::setSampleRate(double newSampleRate)
{
    mPostProcessing.setSampleRate(newSampleRate);
}

void FinalProcessingBlock::setGain(double gain)
{
    mGain.setValueUnchecked(gain);
}

void FinalProcessingBlock::setDelay(size_t numSamples)
{
    mDelay.setValueUnchecked(numSamples);
    mDelayBlock.setDelayLength(numSamples);
}

void FinalProcessingBlock::setPhaseInverted(bool shouldBeInverted)
{
    mPolarity.setValueUnchecked(shouldBeInverted);
}

bool FinalProcessingBlock::phaseIsInverted() const
{
    return mPolarity.toBool();
}

} // namespace CamdenLabs