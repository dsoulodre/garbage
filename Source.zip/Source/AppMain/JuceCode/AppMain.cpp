/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "AppMain/JuceCode/AppMain.h"
#include "GUI/MainWindow.h"

#include "juce_audio_plugin_client/Standalone/juce_StandaloneFilterWindow.h"

// Helper functions to convert between juce::AudioSampleBuffer and vector of floats
//==============================================================================
static auto convertBuffer(const juce::AudioBuffer<float>& buffer) -> std::vector<std::vector<CamdenLabs::SampleType>>
{
    size_t numChannels = buffer.getNumChannels();
    size_t numSamples = buffer.getNumSamples();

    std::vector<std::vector<CamdenLabs::SampleType>> dest(numChannels, std::vector<CamdenLabs::SampleType>(numSamples));

    for (size_t chan = 0; chan < numChannels; ++chan)
    {
        const float* from = buffer.getReadPointer((int)chan);
        auto& to = dest[chan];
        std::copy(from, from + numSamples, to.begin());
    }
    return dest;
}

#if 0
static auto convertBuffer(const std::vector<std::vector<CamdenLabs::SampleType>>& buffer) -> juce::AudioBuffer<float>
{
    size_t numChannels = buffer.size();
    size_t numSamples = buffer[0].size();

    juce::AudioBuffer<float> juceBuffer((int)numChannels, (int)numSamples);

    for (size_t chan = 0; chan < numChannels; ++chan)
    {
        auto& from = buffer[chan];
        float* to = juceBuffer.getWritePointer((int)chan);

        std::copy(from.begin(), from.end(), to);
    }
    return juceBuffer;
}
#endif

static void copyBuffer(const std::vector<std::vector<CamdenLabs::SampleType>>& src, juce::AudioBuffer<float>& dest)
{
    size_t numChannels = std::min<size_t>(src.size(), dest.getNumChannels());
    //size_t numSamples = std::min<size_t>(src[0].size(), dest.getNumSamples());

    //dest.setSize(numChannels, numSamples);

    for (size_t chan = 0; chan < numChannels; ++chan)
    {
        const auto& from = src[chan];
        float* to = dest.getWritePointer((int)chan);
        std::copy(from.begin(), from.end(), to);
    }
}

#if 0
static void copyBuffer(const juce::AudioBuffer<float>& src, std::vector<std::vector<CamdenLabs::SampleType>>&  dest)
{
    size_t numChannels = std::min<size_t>(src.getNumChannels(), dest.size());
    size_t numSamples = std::min<size_t>(src.getNumSamples(), dest[0].size());

   //dest.resize(numChannels);
   //for (auto& it : dest)
   //{
   //    it.resize(numSamples);
   //}
    
    for (size_t chan = 0; chan < numChannels; ++chan)
    {
        const float* from = src.getReadPointer((int)chan);
        auto& to = dest[chan];
        std::copy(from, from + numSamples, to.begin());
    }
}
#endif

//==============================================================================
CamdenDSPAudioProcessor::CamdenDSPAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                       )
#endif
{

}

CamdenDSPAudioProcessor::~CamdenDSPAudioProcessor()
{
}

//==============================================================================
const juce::String CamdenDSPAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool CamdenDSPAudioProcessor::acceptsMidi() const
{
    return false;
}

bool CamdenDSPAudioProcessor::producesMidi() const
{
    return false;
}

bool CamdenDSPAudioProcessor::isMidiEffect() const
{
    return false;
}

double CamdenDSPAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int CamdenDSPAudioProcessor::getNumPrograms()
{
    return 1;     
}

int CamdenDSPAudioProcessor::getCurrentProgram()
{
    return 0;
}

void CamdenDSPAudioProcessor::setCurrentProgram (int index)
{
    CL_UNUSED(index);
}

const juce::String CamdenDSPAudioProcessor::getProgramName (int index)
{
    CL_UNUSED(index);
    return {};
}

void CamdenDSPAudioProcessor::changeProgramName (int index, const juce::String& newName)
{
    CL_UNUSED(index);
    CL_UNUSED(newName);
}

//==============================================================================
void CamdenDSPAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    camdenDSP.setSampleRate(sampleRate);
    if (mainWindow != nullptr)
    {
        mainWindow->setSampleRate(sampleRate);
    }
    if (recordingIsEnabled.load())
    {
        CLAssert(0);
        stopRecording();
        mainWindow && (mainWindow->showErrorMessage("Audio settings were modified while recording. Recording has been stopped."), true);
    }
}

void CamdenDSPAudioProcessor::releaseResources()
{
    
}

// Juce's "Preffered channel configuration should handle this
bool CamdenDSPAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    int numIns = layouts.getNumChannels(true, 0);
    int numOuts = layouts.getNumChannels(false, 0);
    
    bool inputsValid = (numIns == 0) || (numIns == 1) || (numIns == 2);
    bool outputsValid = (numOuts == 0) || (numOuts == 2) || (numOuts == 4);

    return inputsValid && outputsValid;
}

void CamdenDSPAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;

    auto audioSamples = convertBuffer(buffer);
    audioSamples = camdenDSP.processBlock(audioSamples);
    copyBuffer(audioSamples, buffer);

    if (recordingIsEnabled.load())
    {
        std::scoped_lock<std::mutex> recordLock(fileRecordingMutex);
        writer->writeFromAudioSampleBuffer(buffer, 0, buffer.getNumSamples());
    }

    if (midiMessages.isEmpty())
    {
        return;
    }

    for (const auto& it : midiMessages)
    {
        auto message = it.getMessage();
        if (!message.isController())
        {
            continue;
        }
        
        if (message.getControllerNumber() == 0)
        {
            camdenDSP.loadPreset(message.getControllerValue());
        }
        else if(message.getControllerNumber() == 1)
        {
            int val = message.getControllerValue();
            CLAssert(val == 0 || val == 127);
            camdenDSP.setDim(val == 127);
        }

        // DEBUG
        juce::AlertWindow::showMessageBox(juce::MessageBoxIconType::InfoIcon, "Received MIDI messge", message.getDescription(), "OK");
    }
}

bool CamdenDSPAudioProcessor::startRecording(juce::File& fileToRecordTo)
{
    constexpr int recordingBitDepth = 16;
    if (this->getTotalNumOutputChannels() < 1)
    {
        return false;
    }

    std::scoped_lock<std::mutex> recordLock(fileRecordingMutex);
    juce::WavAudioFormat wavFormat;
    auto stream = std::make_unique<juce::FileOutputStream>(fileToRecordTo);
    auto* temp = wavFormat.createWriterFor(stream.release(), camdenDSP.sampleRate(), this->getTotalNumOutputChannels(), recordingBitDepth, {}, 0);
    writer.reset(temp);

    //writer.reset(wavFormat.createWriterFor(new juce::FileOutputStream(fileToRecordTo), camdenDSP.sampleRate(), this->getTotalNumOutputChannels(), recordingBitDepth, {}, 0));

    //writer.reset(juce::WavAudioFormat().createWriterFor(
    //                                                    new juce::FileOutputStream(fileToRecordTo),
    //                                                    camdenDSP.sampleRate(),
    //                                                    this->getTotalNumOutputChannels(),
    //                                                    bitDepth,
    //                                                    {},
    //                                                    0
    //                                                   )             
    //            );

    if (writer == nullptr)
    {
        CLAssert(0);
        return false;
    }

    recordingIsEnabled.store(true);
    return true;
}

void CamdenDSPAudioProcessor::stopRecording()
{
    std::scoped_lock<std::mutex> recordLock(fileRecordingMutex);
    recordingIsEnabled.store(false);
    writer.reset(nullptr);
}

//==============================================================================
bool CamdenDSPAudioProcessor::hasEditor() const
{
    return true; 
}

juce::AudioProcessorEditor* CamdenDSPAudioProcessor::createEditor()
{
    auto window = new CamdenDSPMainWindow (*this);
    camdenDSP.setGuiObject(window);
    this->mainWindow = window;
    return window;
}

//==============================================================================
void CamdenDSPAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    CL_UNUSED(destData);
}

void CamdenDSPAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    CL_UNUSED(data);
    CL_UNUSED(sizeInBytes);
}

//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new CamdenDSPAudioProcessor();
}
