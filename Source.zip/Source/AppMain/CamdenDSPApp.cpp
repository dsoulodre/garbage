/*
  ==============================================================================

    CamdenDSPApp.cpp
    Created: 5 Mar 2024 10:02:23am
    Author:  14372

  ==============================================================================
*/

#include "CamdenDSPApp.h"
#include "GUI/MainWindow.h"
#include "GUI/AudioComponentGUIs/ProcessorComponentGUI.h"
#include "ComponentManager/ComponentID.h"
#include "ComponentManager/Preset.h"

#include "GUI/GUIFactory.h"

#include "JuceHeader.h"


#include "Helpers/RandomNumGen.h"
#include "Helpers/SineGenerator.h"
CamdenLabs::RandomNum<CamdenLabs::SampleType> clRand(-1, 1);
constexpr size_t numSineWaves = 1;
std::vector<CamdenLabs::SineGenerator> sineGens;



namespace CamdenLabs
{

CamdenDSP::CamdenDSP()
{
    double freq = 500.0;
    for (size_t i = 0; i < numSineWaves; ++i)
    {
        sineGens.emplace_back(4096);
        sineGens[i].setFrequency(freq);
        freq += 500.0;
    }

    const auto presetDir = []()
    {
        auto appExePath = juce::File::getSpecialLocation(juce::File::currentApplicationFile).getParentDirectory();
        juce::File resourceDir;

#if CL_RELEASE
        // Release build assumes the application is in a folder with a "Resources" subdirectory
        resourceDir = appExePath.getChildFile("Resources");
#else // CL_RELEASE
        resourceDir = appExePath.getChildFile("../../../../../Resources");
#endif // CL_RELEASE

        return resourceDir.getChildFile("Presets/BuiltIn");
    }(); // immediately invoked

    if (!presetDir.isDirectory())
    {
        return;
    }

    for (auto& file : presetDir.findChildFiles(juce::File::TypesOfFileToFind::findFiles, false, "*.xml"))
    {
        if (!file.existsAsFile())
        {
            CLAssert(0);
            continue;
        }

        std::unique_ptr<Preset> preset(nullptr);
        try
        {
            preset = Preset::loadPreset(file);
        }
        catch (...)
        {
            CLAssert(0);
            continue;
        }

        auto name = file.getFileNameWithoutExtension().toStdString();
        mPresets.push_back({ std::move(preset), name });
    }

}

auto CamdenDSP::processBlock(std::vector<std::vector<SampleType>>& buffer) -> std::vector<std::vector<SampleType>>&
{
    std::scoped_lock<std::mutex> guard(mMutex);

    std::vector<SampleType> noiseBuffer(buffer[0].size());
    if (mNoiseMode == NoiseMode::Tone)
    {
        for (auto& sample : noiseBuffer)
        {
            sample = 0.0;
            for (auto& generator : sineGens)
            {
                sample += generator.getNextSample();
            }
        }
    }
    else if (mNoiseMode == NoiseMode::Noise)
    {
        constexpr double noiseGain = 0.5;
        for (auto& sample : noiseBuffer)
        {
            sample = clRand() * noiseGain;
        }
    }

    

    if (mNoiseMode != NoiseMode::None)
    {
        size_t end = mNoiseDirectToOutput ? (buffer.size() - 1ULL) : 1ULL;
        for (size_t chan = 0; chan <= end; ++chan)
        {
            buffer[chan] = noiseBuffer;
        }

        if (mNoiseDirectToOutput)
        {
            return buffer;
        }
    }

    mAudioProcessor.processBlock(buffer);
    if (this->isDimmed)
    {
        for (auto& chan : buffer)
        {
            for (auto& sample : chan)
            {
                sample *= dimGain;
            }
        }
    }

    return buffer;
}

void CamdenDSP::setGuiObject(CamdenDSPMainWindow* guiWindow)
{
    namespace CLID = ComponentIDs;
    using Attributes = CLID::ComponentAttributes;

    std::scoped_lock<std::mutex> guard(mMutex);
    mGuiWindow = guiWindow;

    {
        auto& audioComponent = mAudioProcessor.mStereoProcessing;
        auto& gui = guiWindow->mStereoProcessing;
        Attributes attributes{ CLID::StereoProcessing, 0 };
        uint64_t id = CLID::makeComponentID(attributes);
        mComponentManager.addComponent(id, &audioComponent, &gui);

        auto& postProc = audioComponent.mPostProcessingBlock;
        auto& postProcGui = gui.mProcessingBlock;
        uint64_t postProcID = CLID::makeSubComponentID(id, CLID::PostProcessingBlock, 0);
        mComponentManager.addComponent(postProcID, &postProc, &postProcGui);
    }

    for (size_t i = 0; i < Constants::numInputs; ++i)
    {
        auto& audioComponent = mAudioProcessor.mMonoProcessing[i];
        auto& gui = guiWindow->mMonoProcessing.channels[i];
        Attributes attributes{ CLID::MonoProcessing, i };
        uint64_t id = CLID::makeComponentID(attributes);
        mComponentManager.addComponent(id, &audioComponent, &gui);

        auto& postProc = audioComponent.mProcessingBlock;
        auto& postProcGui = gui.mProcessingBlock;
        uint64_t postProcID = CLID::makeSubComponentID(id, CLID::PostProcessingBlock, 0);
        mComponentManager.addComponent(postProcID, &postProc, &postProcGui);
    }

    {
        auto& audioComponent = mAudioProcessor.mCrossover;
        auto& gui = guiWindow->mCrossover;
        Attributes attributes{ CLID::Crossover, 0 };
        uint64_t id = CLID::makeComponentID(attributes);
        mComponentManager.addComponent(id, &audioComponent, &gui);
    }

    for (size_t i = 0; i < Constants::numOutputs; ++i)
    {
        auto& audioComponent = mAudioProcessor.mFinalProcessing[i];
        auto& gui = guiWindow->mPerChannel.channels[i];
        Attributes attributes{ CLID::FinalProcessing, i };
        uint64_t id = CLID::makeComponentID(attributes);
        mComponentManager.addComponent(id, &audioComponent, &gui);

        auto& postProc = audioComponent.mPostProcessing;
        auto& postProcGui = gui.postProcessingPopup;
        uint64_t postProcID = CLID::makeSubComponentID(id, CLID::PostProcessingBlock, 0);
        mComponentManager.addComponent(postProcID, &postProc, &postProcGui);
    }
}

void CamdenDSP::setDim(bool shouldBeDimmed)
{
    std::scoped_lock<std::mutex> guard(mMutex);
    isDimmed = shouldBeDimmed;
}

void CamdenDSP::setSampleRate(double sampleRate)
{
    std::scoped_lock guard(mMutex);
    mAudioProcessor.setSampleRate(sampleRate);
    mComponentManager.setSampleRate(sampleRate);
    sineGens[0].setFrequency(500.0, sampleRate);
    mSampleRate = sampleRate;
}

void CamdenDSP::setBufferSize(size_t bufferSize)
{
    CL_UNUSED(bufferSize);
}

void CamdenDSP::setNoiseMode(NoiseMode mode, bool sendDirectlyToOutput)
{
    std::scoped_lock guard(mMutex);
    mNoiseMode = mode;
    mNoiseDirectToOutput = sendDirectlyToOutput;
}

bool CamdenDSP::loadPreset(size_t index)
{
    if (index >= mPresets.size())
    {
        CLAssert(0);
        return false;
    }

    auto& preset = mPresets[index].data;
    if (preset == nullptr)
    {
        CLAssert(0);
        return false;
    }

    loadPresetInternal(*preset);
    return true;
}

void CamdenDSP::loadPreset(std::string filePath)
{
    namespace CLID = ComponentIDs;

    juce::File file(filePath);
    std::unique_ptr<Preset> preset(nullptr);

    try
    {
        preset = Preset::loadPreset(file);
    }
    catch(...)
    {
        CLAssert(0);
        return;
    }

    loadPresetInternal(*preset);
}

void CamdenDSP::savePreset(std::string filePath) const
{
    std::scoped_lock<std::mutex> guard(mMutex);
    auto preset = Preset::createPreset(this->mComponentManager);
    preset->saveToFile(filePath);
}

auto CamdenDSP::resourceDirectory() -> juce::File 
{
    auto exePath = juce::File::getSpecialLocation(juce::File::currentApplicationFile);

#if CL_RELEASE

    // Release build assumes the application is in a folder with a "Resources" subdirectory
    return exePath.getParentDirectory().getChildFile("Resources");

#else // CL_RELEASE

    #if CL_LINUX_BUILD
    auto debugDir = exePath.getParentDirectory();
    auto binDir = debugDir.getParentDirectory();
    auto codeBlocksDir = binDir.getParentDirectory();
    auto buildDir = codeBlocksDir.getParentDirectory();
    auto projDir = buildDir.getParentDirectory();
    CLAssert(debugDir.isDirectory());
    CLAssert(binDir.isDirectory());
    CLAssert(codeBlocksDir.isDirectory());
    CLAssert(buildDir.isDirectory());
    CLAssert(projDir.isDirectory());
    return projDir.getChildFile("Resources");
    #endif // CL_LINUX_BUILD

    #if CL_WINDOWS_BUILD
    auto standaloneDir = exePath.getParentDirectory();
    auto debugDir = standaloneDir.getParentDirectory();
    auto x64Dir = debugDir.getParentDirectory();
    auto vsDir = x64Dir.getParentDirectory();
    auto buildDir = vsDir.getParentDirectory();
    auto projDir = buildDir.getParentDirectory();
    CLAssert(standaloneDir.isDirectory());
    CLAssert(debugDir.isDirectory());
    CLAssert(x64Dir.isDirectory());
    CLAssert(vsDir.isDirectory());
    CLAssert(buildDir.isDirectory());
    CLAssert(projDir.isDirectory());
    return projDir.getChildFile("Resources");
    #endif // CL_WINDOWS_BUILD

#endif // CL_RELEASE
}

auto CamdenDSP::availablePresets() const -> std::vector<std::string>
{
    std::vector<std::string> ret;
    ret.reserve(mPresets.size());

    for (auto& it : mPresets)
    {
        ret.push_back(it.name);
    }
    return ret;
}

double CamdenDSP::sampleRate() const
{
    return mSampleRate;
}

void CamdenDSP::loadPresetInternal(Preset& preset)
{
    namespace CLID = ComponentIDs;

    std::scoped_lock<std::mutex> guard(mMutex);

    // Reset application state before loading preset
    removeAllComponenets();

    // Create post processing components
    for (auto& compID : preset.postProcessingComponents())
    {
        auto postProcID = CLID::getSubComponentID(compID);
        auto postProcObj = dynamic_cast<PostProcessingBlock*>(mComponentManager.find(postProcID));
        auto postProcGUI = dynamic_cast<PostProcessingGUI*>(mComponentManager.findGUI(postProcID));

        // This condition will fail if postProcID does not represent a valid post-processing block
        if (postProcObj == nullptr || postProcGUI == nullptr)
        {
            CLAssert(0);
            continue;
        }

        auto type = static_cast<PostProcessingComponent::ComponentType>(CLID::getPostProcessingType(compID));
        auto newComponent = std::make_unique<PostProcessingComponent>(type);
        auto gui = createGUI(type);

        mComponentManager.addComponent(compID, newComponent.get(), gui.get());

        postProcObj->addComponent(std::move(newComponent));
        postProcGUI->addComponent(std::move(gui));
    }

    // Set paramter values and automation
    for (auto& it : preset.paramData())
    {
        auto componentID = CLID::getParentID(it.parameterID);
        auto paramIndex = static_cast<int>(CLID::getParam(it.parameterID));
        auto component = mComponentManager.find(componentID);
        if (component == nullptr)
        {
            CLAssert(0);
            preset.removeComponentData(componentID);
            continue;
        }

        component->setParameterValue(paramIndex, it.value);
    }

    // Update GUIs to reflect parameter values, automation, etc.
    for (auto& it : mComponentManager.getGuiComponents())
    {
        it.second->updateState();
    }
}

void CamdenDSP::removeAllComponenets()
{
    const auto clearAll = [this](PostProcessingBlock& postProc)
    {
        for (auto it : postProc.getComponents())
        {
            uint64_t deletedID = mComponentManager.deleteAudioComponent(it);
            (void)mComponentManager.deleteGUIComponent(deletedID);
            postProc.removeComponent(it);
        }
    };

    // Remove GUIs first to avoid GUIs trying to control non-existant objects
    mGuiWindow->mStereoProcessing.mProcessingBlock.deleteAllComponents();
    for (auto& it : mGuiWindow->mMonoProcessing.channels)
    {
        it.mProcessingBlock.deleteAllComponents();
    }
    for (auto& it : mGuiWindow->mPerChannel.channels)
    {
        it.postProcessingPopup.deleteAllComponents();
    }

    // Remove audio components
    clearAll(mAudioProcessor.mStereoProcessing.mPostProcessingBlock);
    for (auto& it : mAudioProcessor.mMonoProcessing)
    {
        clearAll(it.mProcessingBlock);
    }
    for (auto& it : mAudioProcessor.mFinalProcessing)
    {
        clearAll(it.mPostProcessing);
    }

}

} // namespace CamdenLabs
