/*
  ==============================================================================

    PerChannelProcessingGUI.h
    Created: 3 Mar 2024 6:11:14pm
    Author:  14372

  ==============================================================================
*/

/*
- Gain (dB) [0.1dB resolution]
- delay (in samples, max delay =10ms)
- EQ (filters)
- Phase switch (polarity)
*/

#pragma once
#include "CLHeader.h"
#include "GUI/GUIComponent.h"
#include "GUI/AudioComponentGUIs/ProcessorComponentGUI.h"
#include "GUI/Widgets/KnobsAndSliders/Slider.h"
#include "GUI/Widgets/KnobsAndSliders/GainKnob.h"

#include <array>

namespace CamdenLabs
{

class PerChannelProcessingGUI : public GUIComponent
{
public:

    PerChannelProcessingGUI();

    void resized() override;

    void attachListener() override;

    void updateState() override;

    void setSampleRate(double sampleRate);

    void setName(const juce::String& name)
    {
        setTitle(name);
        postProcessingPopup.setWindowTitle("Final Processing - " + name + " - EQ");
    }

    PostProcessingPopup postProcessingPopup;

private:

    void phaseButtonClicked();

    void eqButtonClicked();

    Slider delaySlider;
    juce::Label delayLabel;

    GainKnob gainKnob;
    juce::Label gainLabel;

    juce::TextButton phaseButton;
    bool isInverted{ false };

    juce::TextButton eqButton;

    double mSampleRate{ Constants::defaultSampleRate };

};

class FinalProcessingGUI : public GUIComponent
{
public:
    FinalProcessingGUI()
    {
        for (auto& it : channels)
        {
            addAndMakeVisible(it);
        }
        channels[0].setName("Left");
        channels[1].setName("Right");
        channels[2].setName("Left Woofer");
        channels[3].setName("Right Woofer");
    }

    void resized() override
    {
        constexpr float spacing = 0.05f;
        constexpr float totalSpacing = spacing * (Constants::numOutputs - 1);
        constexpr float paddingY = 0.05f;
        constexpr float paddingX = 0.05f;

        constexpr float height = (1.f - (2.f * paddingY + totalSpacing)) / Constants::numOutputs;
        constexpr float width = 1.f - (2.f * paddingX);

        float y = paddingY;
        for (auto& it : channels)
        {
            it.setBoundsRelative(paddingX, y, width, height);
            y += spacing + height;
        }
    }

    void attachListener() override {}

    std::array<PerChannelProcessingGUI, Constants::numOutputs> channels;
};

} // namespace CamdenLabs