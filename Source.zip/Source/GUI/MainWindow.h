/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "AppMain/JuceCode/AppMain.h"
#include "GUI/AudioComponentGUIs/ProcessorComponentGUI.h"
#include "GUI/StereoProcessingGUI.h"
#include "GUI/MonoProcessingGUI.h"
#include "GUI/CrossoverGUI.h"
#include "GUI/PerChannelProcessingGUI.h"

//==============================================================================
class CamdenDSPMainWindow  : public juce::AudioProcessorEditor
{
public:
    CamdenDSPMainWindow (CamdenDSPAudioProcessor&);
    ~CamdenDSPMainWindow() override;

    //==============================================================================
    void paint (juce::Graphics&) override;
    void resized() override;

    void setSampleRate(double sampleRate);

    void updateSpectrumTest();

    void showErrorMessage(const std::string& message) const;

    static auto resourceDirectory() -> juce::File;

private:

    void presetInit(juce::File presetDir);

    void presetSelected();

    void loadPresetButtonClicked();
    void savePresetButtonClicked();

    void dimButtonClicked();

    void noiseModeSelected();

    void recordButtonClicked();

    CamdenDSPAudioProcessor& audioProcessor;

    juce::TabbedComponent tabbedComponent;

    CamdenLabs::StereoProcessingGUI mStereoProcessing;
    CamdenLabs::MonoBlockGUI mMonoProcessing;
    CamdenLabs::CrossoverGUI mCrossover;
    CamdenLabs::FinalProcessingGUI mPerChannel;

    juce::TextButton recordButton;

    juce::TextButton dimButton;
    bool isDimmed{ false };

    juce::TextButton savePresetButton;
    juce::TextButton loadPresetButton;

    juce::ComboBox presetDropdown;
    int currentPresetIndex{ -1 };

    juce::TooltipWindow mTooltipWindow;

    friend class CamdenLabs::CamdenDSP;

    juce::ComboBox noiseDropdown;
    juce::ToggleButton noiseOutputButton;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (CamdenDSPMainWindow)
};
