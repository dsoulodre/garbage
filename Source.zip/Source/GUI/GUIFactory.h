/*
  ================================================================================
  *      File                                          GUIFactory.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "GUI/GUIComponent.h"
#include "AudioComponents/PostProcessingComponent.h"

#include "JuceHeader.h"
#include <memory>

namespace CamdenLabs
{

	std::unique_ptr<GUIComponent> createGUI(PostProcessingComponent::ComponentType type);

} // namespace CamdenLabs