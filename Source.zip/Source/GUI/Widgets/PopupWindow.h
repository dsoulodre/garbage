/*
  ================================================================================
  *      File                                         PopupWindow.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"

#include "JuceHeader.h"
#include <functional>

namespace CamdenLabs
{

class PopupWindow : public juce::DocumentWindow
{
public:

    PopupWindow(juce::Component* contentComponent);

    void showWindow();
    void showWindow(int screenX, int screenY);
    void closeWindow();

    void setMinimumSize(int widthInPixels, int heightInPixels);

    void setMaximumSize(int widthInPixels, int heightInPixels);

    void setFixedAspectRatio(double widthToHeightRatio);

    // Stops constraining aspect ratio, if one was set
    void unfixAspectRatio();

    void setTitleBarText(std::string text);


    std::function<void()> closeWindowFunction{ nullptr };

private:
    void closeButtonPressed() override;
};

} // namespace CamdenLabs