/*
  ==============================================================================

    GainKnob.cpp
    Created: 5 Mar 2024 1:49:23pm
    Author:  14372

  ==============================================================================
*/

#include "GainKnob.h"
#include "GUI/ColourScheme.h"

namespace CamdenLabs
{ 

juce::Colour GainKnob::defaultColour = juce::Colour(juce::Colour::fromRGBA(66, 162, 200, 255));
juce::Colour GainKnob::defaultMutedColour = juce::Colour(juce::Colour::fromRGBA(150, 185, 200, 150));

GainKnob::GainKnob(juce::Colour mutedColour, juce::Colour unmutedColour)
    : muteButton("Mute", unmutedColour, unmutedColour.brighter(0.2f), unmutedColour.darker(0.2f))
{
    mMutedColour = mutedColour;
    mUnmutedColour = unmutedColour;

    juce::Path circle;
    circle.addEllipse(0.0, 0.0, 1.0, 1.0);

    addAndMakeVisible(muteButton);
    muteButton.setShape(circle, true, true, false);
    muteButton.setAlwaysOnTop(true);
    muteButton.setTooltip("Mute");
    muteButton.onClick = [&]() { muteButtonClicked(); };
}

void GainKnob::resized()
{
    CamdenLabs::Knob::resized();
    muteButton.setBoundsRelative(0.35f, 0.35f, 0.3f, 0.3f);
}

void GainKnob::setEnabled(bool shouldBeEnabled)
{
    if (shouldBeEnabled)
    {
        if (mLabel != nullptr)
        {
            mLabel->setColour(juce::Label::ColourIds::textColourId, Colours::white);
        }
        setMuted(mMuted); // Reset colours 
    }
    else
    {
        muteButton.setColours(mMutedColour, mMutedColour.brighter(0.2f), mMutedColour.darker(0.2f));
        mSlider.setColour(juce::Slider::ColourIds::thumbColourId, juce::Colours::grey);
        mSlider.setColour(juce::Slider::ColourIds::rotarySliderFillColourId, CamdenLabs::Colours::transparent);

        if (mLabel != nullptr)
        {
            mLabel->setColour(juce::Label::ColourIds::textColourId, Colours::grey);
        }
    }
    mSlider.setEnabled(shouldBeEnabled);
    muteButton.setEnabled(shouldBeEnabled);
    mEnabled = shouldBeEnabled;
}

void GainKnob::muteButtonClicked()
{
    mMuted = !mMuted;
    setMuted(mMuted);
}

void GainKnob::setMuted(bool shouldBeMuted)
{
    mMuted = shouldBeMuted;
    if (shouldBeMuted)
    {
        muteButton.setColours(mMutedColour, mMutedColour.brighter(0.2f), mMutedColour.darker(0.2f));
        mSlider.setColour(juce::Slider::ColourIds::thumbColourId, juce::Colours::grey);
        mSlider.setColour(juce::Slider::ColourIds::rotarySliderFillColourId, CamdenLabs::Colours::transparent);
    }
    else
    {
        muteButton.setColours(mUnmutedColour, mUnmutedColour.brighter(0.2f), mUnmutedColour.darker(0.2f));
        mSlider.setColour(juce::Slider::ColourIds::thumbColourId, CamdenLabs::Colours::sliderThumbColour);
        mSlider.setColour(juce::Slider::ColourIds::rotarySliderFillColourId, CamdenLabs::Colours::sliderTrackFill);
    }

    if (buttonClickedFunction != nullptr)
    {
        buttonClickedFunction(shouldBeMuted);
    }
}


} // namespace CamdenLabs