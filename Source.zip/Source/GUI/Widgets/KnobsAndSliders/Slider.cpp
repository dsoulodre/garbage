/*
  ==============================================================================

    Slider.cpp
    Created: 4 Mar 2024 3:14:59pm
    Author:  14372

  ==============================================================================
*/

#include "Slider.h"
#include "GUI/ColourScheme.h"

namespace CamdenLabs
{

Knob::Knob()
{
    addAndMakeVisible(mSlider);
    mSlider.setInterceptsMouseClicks(false, false);
    mSlider.addMouseListener(this, false);
    rightClickMenu.addItem("Set Value", [this]() { showSetValue(); });
}

void Knob::resized()
{
    mSlider.setBoundsRelative(0.0, 0.0, 1.0, 1.0);
}

void Knob::setEnabled(bool shouldBeEnabled)
{
    namespace Clr = CamdenLabs::Colours;
    // const juce::Colour& sliderColour = shouldBeEnabled ? Clr::sliderThumbColour : Clr::grey;
    // const juce::Colour& textColour   = shouldBeEnabled ? Clr::textColour        : Clr::textDisabledColour;

    if (shouldBeEnabled)
    {
        mSlider.setColour(juce::Slider::thumbColourId, Colours::sliderThumbColour);
        if (mLabel != nullptr)
        {
            mLabel->setColour(juce::Label::ColourIds::textColourId, Colours::white);
        }
    }
    else
    {
        mSlider.setColour(juce::Slider::thumbColourId, Colours::grey);
        if (mLabel != nullptr)
        {
            mLabel->setColour(juce::Label::ColourIds::textColourId, Colours::grey);
        }
    }
    mSlider.setEnabled(shouldBeEnabled);
    mEnabled = shouldBeEnabled;
}

void Knob::enableTextBox(bool shouldShowTextBox)
{
    using T = juce::Slider::TextEntryBoxPosition;
    auto position = shouldShowTextBox ? T::TextBoxRight : T::NoTextBox;
    mSlider.setTextBoxStyle(position, false, 50, 25);
}

void Knob::setValue(double value)
{
    mSlider.setValue(value);
    if (valueDisplay != nullptr)
    {
        valueDisplay->updateText();
    }
}

double Knob::getValue() const
{
    return mSlider.getValue();
}

void Knob::setToDefaultValue()
{
    if (mParameter == nullptr)
    {
        CLAssert(0);
        setValue(0.0);
        return;
    }
    double normVal = mParameter->normalize(mParameter->defaultValue());
    CLAssert(normVal >= 0.0 && normVal <= 1.0);
    setValue(normVal);
}

void Knob::setCallbacks(Listener* listener, int paramIndex)
{
    mSlider.setCallbacks(listener, paramIndex);
}

void Knob::setSnapValueFunction(std::function<double(double)> func)
{
    mSlider.snapValueFunction = func;
}

void Knob::setAudioParameter(AudioParameter& parameter)
{
    mParameter = &parameter;
}

void Knob::setAudioParameter(AudioParameter* parameter)
{
    mParameter = parameter;
    if (this->isEnabled())
    {
        setToDefaultValue();
    }
}

void Knob::setLabel(juce::Label& label)
{
    mLabel = &label;

    label.setJustificationType(juce::Justification::Flags::centred);
    label.setMinimumHorizontalScale(0.1f);

    if (mParameterName.isEmpty())
    {
        mParameterName = mLabel->getText();
    }
    else if (label.getText().isEmpty())
    {
        label.setText(mParameterName, juce::dontSendNotification);
    }

    if (auto parent = this->getParentComponent())
    {
        parent->addAndMakeVisible(label);
    }
}

void Knob::setLabel(juce::Label& label, const juce::String& text)
{
    label.setText(text, juce::dontSendNotification);
    setLabel(label);
}

void Knob::setParameterName(const juce::String& name)
{
    mParameterName = name;
}

void Knob::setParameterUnits(const juce::String& unitSuffix, bool showInTextBox)
{
    mUnitSuffix = unitSuffix;
    if (showInTextBox)
    {
        mSlider.setTextValueSuffix(unitSuffix);
        mSlider.updateText();
    }
}

void Knob::setTextFromValueFunction(std::function<juce::String(double)> callback)
{
    mSlider.textFromValueFunction = callback;
    mSlider.updateText();
}

void Knob::setValueFromTextFunction(std::function<double(juce::String)> callback)
{
    mSlider.valueFromTextFunction = callback;
}

void Knob::updateText()
{
    mSlider.updateText();
}

auto Knob::textFromValue(double value) const -> juce::String
{
    if (mSlider.textFromValueFunction != nullptr)
    {
        return mSlider.textFromValueFunction(value);
    }
    else if (decimalPlacePrecision == 0)
    {
        return juce::String(static_cast<int>(mParameter->denormalize(value)));
    }
    else
    {
        return juce::String(mParameter->denormalize(value), decimalPlacePrecision, false);
    }
}

auto Knob::valueFromText(const juce::String& text) const -> double
{
    if (mSlider.valueFromTextFunction != nullptr)
    {
        return mSlider.valueFromTextFunction(text);
    }

    double rawValue = text.getDoubleValue();
    return mParameter->normalize(rawValue);
}

auto Knob::parameterRangeString(bool withUnits) const -> juce::String 
{
    auto minValString = textFromValue(0.0);
    auto maxValString = textFromValue(1.0);

    if (!withUnits)
    {
        return minValString + " " + " to " + maxValString;
    }
    else
    {
        return minValString + " " + mUnitSuffix + " to " + maxValString + " " + mUnitSuffix;
    }
}

auto Knob::valueAsText() const -> juce::String
{
    return textFromValue(getValue());
}

void Knob::showValueDisplay()
{
    if (valueDisplay == nullptr)
    {
        valueDisplay = std::make_unique<ValueDisplay>(*this);
    }
    auto parent = getParentComponent();
    if (parent == nullptr)
    {
        CLAssert(0);
        return;
    }
    parent->addAndMakeVisible(*valueDisplay);
    

    int width = std::min(this->getWidth(), this->getHeight());
    int height = width / 4;
    int x = this->getX() + (this->getWidth() - width) / 2;
    int y = this->getY() + (this->getHeight() * 11) / 10;

    if (y + height > parent->getHeight())
    {
        y = parent->getHeight() - height;
    }
    valueDisplay->setBounds(juce::Rectangle<int>(x, y, width, height));

    parent->repaint();
}

void Knob::hideValueDisplay()
{
    valueDisplay.reset(nullptr);
}

void Knob::showSetValue()
{
    if (setValuePopup == nullptr)
    {
        setValuePopup = std::make_unique<SetValuePopup>(*this);
    }
    setValuePopup->launch();
}

void Knob::hideSetValue()
{
    setValuePopup.reset(nullptr);
}

void Knob::mouseEnter(const juce::MouseEvent& e) 
{
    showValueDisplay();
    mSlider.mouseEnter(e);
}

void Knob::mouseExit(const juce::MouseEvent& e) 
{
    hideValueDisplay();
    mSlider.mouseExit(e);
}

void Knob::mouseDown(const juce::MouseEvent& e)
{
    if (e.mods.isRightButtonDown())
    {
        rightClickMenu.show();
        return;
    }

    mSlider.mouseDown(e);
    if (valueDisplay != nullptr)
    {
        valueDisplay->updateText();
    }
}

void Knob::mouseUp(const juce::MouseEvent& e)
{
    mSlider.mouseUp(e);
}

void Knob::mouseDrag(const juce::MouseEvent& e)
{
    mSlider.mouseDrag(e);
    if (valueDisplay != nullptr)
    {
        valueDisplay->updateText();
    }
}

void Knob::rightClicked()
{
    if (this->isEnabled())
    {
        rightClickMenu.show();
    }
}

// Value display
//======================================================================================================================



Knob::ValueDisplay::ValueDisplay(Knob& parentComponent)
    :   mParent(parentComponent)
{
    setAlwaysOnTop(true);
    updateText();
}

void Knob::ValueDisplay::paint(juce::Graphics& g)
{
    g.setColour(Colours::popupMenuColour.withAlpha(0.8f).brighter(0.2f));
    g.fillAll();

    constexpr float padding = 0.05f;
    int paddingX = static_cast<int>(this->getWidth() * padding);
    int paddingY = static_cast<int>(this->getHeight() * padding);
    int w = this->getWidth() - 2 * paddingX;
    int h = this->getHeight() - 2 * paddingY;

    g.setFont(16.f);
    g.setColour(CamdenLabs::Colours::textColour);

    g.drawFittedText(mValueString,
        paddingX,
        paddingY,
        w,
        h,
        juce::Justification::Flags::centred,
        1,
        0.1f);
}

void Knob::ValueDisplay::setValue(double value)
{
    mValueString = mParent.textFromValue(value) + " " + mParent.mUnitSuffix;
    repaint();
}

void Knob::ValueDisplay::updateText()
{
    setValue(mParent.mSlider.getValue());
}



// Set value popup
//======================================================================================================================


// Helper function for text entry
static bool isValidNumber(const std::string& str)
{
    if (str.find_first_not_of("0123456789.-") != std::string::npos)
    {
        return (str == "-inf" || str == "inf");
    }
    if (str.find('-', 1) != std::string::npos)
    {
        return false;
    }
    int decimalCount = 0;

    for (auto& it : str)
    {
        if (it == '.')
        {
            ++decimalCount;
        }
    }
    if (decimalCount > 1)
    {
        return false;
    }
    return true;
}


Knob::SetValuePopup::SetValuePopup(Knob& parentComponent)
    : parent(parentComponent)
{
    setLookAndFeel(&ColourScheme::getInstance());

    addAndMakeVisible(paramNameLabel);
    paramNameLabel.setJustificationType(juce::Justification::centred);
    paramNameLabel.setText(parent.mParameterName, juce::dontSendNotification);

    addAndMakeVisible(rangeLabel);
    rangeLabel.setJustificationType(juce::Justification::Flags::centredLeft);
    rangeLabel.setText("Range", juce::dontSendNotification);

    addAndMakeVisible(rangeValueLabel);
    rangeValueLabel.setJustificationType(juce::Justification::Flags::centredRight);
    rangeValueLabel.setText(parent.parameterRangeString(false), juce::dontSendNotification);

    addAndMakeVisible(suffixLabel1);
    suffixLabel1.setText(parent.mUnitSuffix, juce::dontSendNotification);
    suffixLabel1.setJustificationType(juce::Justification::Flags::centredLeft);
    suffixLabel1.setMinimumHorizontalScale(0.1f);

    addAndMakeVisible(valueLabel);
    valueLabel.setJustificationType(juce::Justification::Flags::centredLeft);
    valueLabel.setText("Value", juce::dontSendNotification);

    addAndMakeVisible(valueEntryBox);
    valueEntryBox.onReturnKey = [&]() { valueEntered(); };
    valueEntryBox.setSelectAllWhenFocused(true);

    addAndMakeVisible(suffixLabel2);
    suffixLabel2.setText(parent.mUnitSuffix, juce::dontSendNotification);
    suffixLabel2.setJustificationType(juce::Justification::Flags::centredLeft);
    suffixLabel2.setMinimumHorizontalScale(0.1f);

    addAndMakeVisible(okButton);
    okButton.setButtonText("OK");
    okButton.onClick = [&]() { valueEntered(); };
    okButton.setColour(juce::TextButton::ColourIds::buttonColourId, CamdenLabs::Colours::darkButtonColour);

    addAndMakeVisible(resetButton);
    resetButton.setButtonText("Reset");
    resetButton.onClick = [&]() { resetButtonClicked(); };

    addAndMakeVisible(cancelButton);
    cancelButton.setButtonText("Cancel");
    cancelButton.onClick = [&]() { closeWindow(); };
    cancelButton.setColour(juce::TextButton::ColourIds::buttonColourId, CamdenLabs::Colours::lightButtonColour);

    CLAssert(parent.mParameter != nullptr);
}

void Knob::SetValuePopup::resized()
{
    paramNameLabel.setBoundsRelative(0.3f, 0.0f, 0.4f, 0.3f);

    rangeLabel.setBoundsRelative(0.1f, 0.2f, 0.3f, 0.3f);
    rangeValueLabel.setBoundsRelative(0.6f, 0.2f, 0.25f, 0.3f);
    suffixLabel1.setBoundsRelative(0.85f, 0.2f, 0.1f, 0.3f);

    valueLabel.setBoundsRelative(0.1f, 0.5f, 0.25f, 0.1f);
    valueEntryBox.setBoundsRelative(0.6f, 0.5f, 0.245f, 0.1f);

    suffixLabel2.setBoundsRelative(0.85f, 0.5f, 0.1f, 0.1f);

    okButton.setBoundsRelative(0.1f, 0.8f, 0.2f, 0.1f);
    resetButton.setBoundsRelative(0.4f, 0.8f, 0.2f, 0.1f);
    cancelButton.setBoundsRelative(0.7f, 0.8f, 0.2f, 0.1f);
}

void Knob::SetValuePopup::launch()
{
    if (window == nullptr)
    {
        window = std::make_unique<PopupWindow>(this);
        window->setTitleBarText("Set Value");
        window->setResizeLimits(350, 180, 500, 250);
        window->setSize(350, 180);
        window->closeWindowFunction = [&]() { closeWindow(); };
    }
    else if (window->isOnDesktop())
    {
        window->showWindow();
        valueEntryBox.grabKeyboardFocus();
        return;
    }

    valueEntryBox.setText(parent.valueAsText(), false);


    //window->showWindow(parent.mousePosition.x, parent.mousePosition.y);
    window->showWindow();
    valueEntryBox.grabKeyboardFocus();
}

void Knob::SetValuePopup::resetButtonClicked()
{
    parent.setToDefaultValue();
    valueEntryBox.setText(parent.valueAsText());
}

void Knob::SetValuePopup::valueEntered()
{
    const auto isWithinRange = [&](double val)
    {
        CLAssert(parent.mParameter != nullptr);
        const auto& param = *parent.mParameter;
        return val >= std::min(param.min(), param.max()) && val <= std::max(param.min(), param.max());
    };


    auto text = valueEntryBox.getText();
    if (text.isEmpty())
    {
        return;
    }
    if (!isValidNumber(text.toStdString()))
    {
        return invalidEntry();
    }

    double value = parent.valueFromText(text);
    if(parent.mSlider.valueFromTextFunction )
    if (value < 0.0 || value > 1.0)
    {
        return invalidEntry();
    }

    parent.setValue(value);
    valueEntryBox.setColour(juce::TextEditor::ColourIds::backgroundColourId, CamdenLabs::Colours::textBoxColour);
    closeWindow();
}

void Knob::SetValuePopup::invalidEntry()
{
    valueEntryBox.setColour(juce::TextEditor::ColourIds::backgroundColourId, Colours::textBoxInvalidColour);
    valueEntryBox.grabKeyboardFocus();
    valueEntryBox.selectAll();
    repaint();
}

void Knob::SetValuePopup::closeWindow()
{
    // Reset in case window was closed after invalid entry
    valueEntryBox.setColour(juce::TextEditor::ColourIds::backgroundColourId, Colours::textBoxColour);
    window.reset(nullptr);
    parent.hideSetValue();
}


} // namespace CamdenLabs