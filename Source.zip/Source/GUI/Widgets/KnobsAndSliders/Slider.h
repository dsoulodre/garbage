/*
  ================================================================================
  *      File                                            CLSlider.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/
#pragma once
#include "CLHeader.h"
#include "Helpers/AudioParameter.h"
#include "ComponentManager/Listener.h"
#include "GUI/Widgets/PopupWindow.h"
#include "GUI/ColourScheme.h"

#include "JuceHeader.h"
#include <functional>

namespace CamdenLabs
{

class SliderBase : public juce::Slider
{
public:

    SliderBase()
    {
        setRange(0.0, 1.0);
        setSliderStyle(juce::Slider::SliderStyle::Rotary);
        setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    }

    virtual void setCallbacks(CamdenLabs::Listener* listener, int paramIndex)
    {
        this->onValueChange = [this, listener, paramIndex]() { listener->setParameterValue(paramIndex, this->getValue()); };
    }

    double snapValue(double attemptedValue, juce::Slider::DragMode dragMode) override
    {
        CL_UNUSED(dragMode);
        if (snapValueFunction == nullptr)
        {
            return attemptedValue;
        }
        return snapValueFunction(attemptedValue);
    }

    std::function<double(double)> snapValueFunction; 

};



class Knob : public juce::Component
{
public:

    Knob();

    virtual ~Knob() = default;

    void resized() override;

    void setValue(double value);

    double getValue() const;

    void setToDefaultValue();

    virtual void setEnabled(bool shouldBeEnabled);

    void enableTextBox(bool shouldShowTextBox);

    void setCallbacks(CamdenLabs::Listener* listener, int paramIndex);

    template<typename EnumType>
    void setCallbacks(CamdenLabs::Listener* listener, EnumType paramIndex)
    {
        setCallbacks(listener, static_cast<int>(paramIndex));
    }

    void setSnapValueFunction(std::function<double(double)> func);

    void setAudioParameter(AudioParameter& parameter);

    void setAudioParameter(AudioParameter* parameter);

    void setLabel(juce::Label& label);

    void setLabel(juce::Label& label, const juce::String& text);

    void setParameterName(const juce::String& name);

    void setParameterUnits(const juce::String& unitSuffix, bool showInTextBox = false);

    void setTextFromValueFunction(std::function<juce::String(double)> callback);

    void setValueFromTextFunction(std::function<double(juce::String)> callback);

    void updateText();

    auto textFromValue(double value) const -> juce::String;

    auto valueFromText(const juce::String& text) const -> double;

    auto parameterRangeString(bool withUnits = true) const -> juce::String;

    auto valueAsText() const -> juce::String;

protected:

    class ValueDisplay : public juce::Component
    {
    public:

        static constexpr int width = 100;
        static constexpr int height = 25;

        ValueDisplay(Knob& parentComponent);


        void paint(juce::Graphics& g) override;

        void setValue(double value);

        void updateText();

        juce::String unitSuffix;

    private:
        Knob& mParent;
        juce::String mValueString;
    }; // class ValueDisplay

    class SetValuePopup : public juce::Component
    {
    public:

        SetValuePopup(Knob& parentComponent);

        void resized() override;

        void launch();

    private:

        void resetButtonClicked();

        void valueEntered();

        void invalidEntry();

        void closeWindow();

        static constexpr int defaultWidth = 350;
        static constexpr int defaultHeight = 180;

        Knob& parent;

        juce::Label paramNameLabel;
        juce::Label rangeLabel;
        juce::Label rangeValueLabel;
        juce::Label suffixLabel1;

        juce::Label valueLabel;
        juce::TextEditor valueEntryBox;
        juce::Label suffixLabel2;

        juce::TextButton okButton;
        juce::TextButton resetButton;
        juce::TextButton cancelButton;

        bool invalidEntryFlag{ false };

        std::unique_ptr<PopupWindow> window{ nullptr };
    }; // SetValuePopup


    void showValueDisplay();
    void hideValueDisplay();

    void showSetValue();
    void hideSetValue();

    void mouseEnter(const juce::MouseEvent& e) override;
    void mouseExit(const juce::MouseEvent& e) override;

    void mouseDown(const juce::MouseEvent& e) override;
    void mouseUp(const juce::MouseEvent& e) override;

    void mouseDrag(const juce::MouseEvent& e) override;

    void rightClicked();

    SliderBase mSlider;
    juce::Label* mLabel{ nullptr };

    juce::String mParameterName;
    juce::String mUnitSuffix;

    std::unique_ptr<ValueDisplay> valueDisplay{ nullptr };
    std::unique_ptr<SetValuePopup> setValuePopup{ nullptr };

    juce::PopupMenu rightClickMenu;

    AudioParameter* mParameter{ nullptr };

    int decimalPlacePrecision{ 2 };
    bool mEnabled{ true };
};

class Slider : public Knob
{
public:
    Slider()
    {
        mSlider.setSliderStyle(juce::Slider::LinearHorizontal);
        mSlider.setTextBoxStyle(juce::Slider::TextBoxRight, false, 50, 25);
    }
};

} // namespace CamdenLabs

