/*
  ==============================================================================

    GainKnob.h
    Created: 5 Mar 2024 1:49:23pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "Slider.h"

#include <JuceHeader.h>

namespace CamdenLabs
{



class GainKnob : public CamdenLabs::Knob
{
public:
    GainKnob(juce::Colour mutedColour = defaultMutedColour, juce::Colour unmutedColour = defaultColour);

    void resized() override;

    void setEnabled(bool shouldBeEnabled) override;

    void setMuted(bool shouldBeMuted);

    static juce::Colour defaultColour;
    static juce::Colour defaultMutedColour;


    std::function<void(bool)> buttonClickedFunction{ nullptr };

private:

    void muteButtonClicked();

    juce::ShapeButton muteButton;

    juce::Colour mMutedColour;
    juce::Colour mUnmutedColour;

    bool mMuted{ false };
};

} // namespace CamdenLabs