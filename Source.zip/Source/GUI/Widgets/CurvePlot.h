/*
  ==============================================================================

    CurvePlot.h
    Created: 13 Mar 2024 10:59:52am
    Author:  14372

  ==============================================================================
*/
#if 0
#pragma once
#include "CLHeader.h"

#include "JuceHeader.h"

namespace CamdenLabs
{

class Biquad;

class Curve : public juce::Component
{
public:

    Curve();

    void resized() override;

    void paint(juce::Graphics& g) override;

    void setFilter(const Biquad& biquad);

    void setMapping(std::function<double(double)> mappingFunction);

    void setRange(double min, double max);

    void setResolution(double resolution);

    void setData(const std::vector<double>& xData, const std::vector<double> yData);

    void showSpectrum(const std::vector<float>& audioSamples);

private:

    double getMinY() const;
    double getMaxY() const;

    double valueToPixelX(double value) const;
    double valueToPixelY(double value) const;

    void plotInternal();

    void recalculate();

    std::mutex mMutex;

    std::vector<double> xValues;
    std::vector<double> yValues;

    double yMin{ 0.0 };
    double yMax{ 0.0 };

    double mDomainStart;
    double mDomainEnd;
    double mDomainSize;

    double mResolution;

    std::function<double(double)> mMapping{ nullptr };
    juce::Path mPath;

    bool needsRedrawing{ false };
    bool needsRecalculating{ false };
};


} // namespace CamdenLabs

#endif