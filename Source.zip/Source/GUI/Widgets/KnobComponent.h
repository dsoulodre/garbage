/*
  ================================================================================
  *      File                                       KnobComponent.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "GUI/GUIComponent.h"
#include "GUI/Widgets/KnobsAndSliders/Slider.h"

#include "JuceHeader.h"
#include <vector>
#include <memory>
#include <string>
#include <initializer_list>

namespace CamdenLabs
{

template <int numSlider>
class KnobComponent : public CamdenLabs::GUIComponent  
{

public:

    KnobComponent();

    virtual ~KnobComponent() = default;

    void resized() override;

    void attachListener() override;

protected:

    void setLabels(std::initializer_list<std::string> labelText);
    std::vector<std::unique_ptr<CamdenLabs::Knob>> knobs;
    std::vector<std::unique_ptr<juce::Label>> labels;
};

} // namespace CamdenLabs

#include "KnobComponent.tpp"