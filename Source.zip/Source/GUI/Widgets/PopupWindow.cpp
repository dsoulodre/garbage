/*
  ================================================================================
  *      File                                       PopupWindow.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "PopupWindow.h"
#include "GUI/ColourScheme.h"
#include "Helpers/CLAssert.h"

namespace CamdenLabs
{

PopupWindow::PopupWindow(juce::Component* contentComponent)
    :   juce::DocumentWindow("", CamdenLabs::Colours::backgroundColour, 5, false)
{
    setContentNonOwned(contentComponent, false);
    setResizable(true, true);
}

void PopupWindow::showWindow()
{
    this->addToDesktop();
    this->setVisible(true);
    juce::Timer::callAfterDelay(10, [this]() { this->toFront(true); });
}

void PopupWindow::showWindow(int screenX, int screenY)
{
    CLAssert(screenX >= 0 && screenY >= 0);
    setCentrePosition(screenX, screenY);
    showWindow();
}

void PopupWindow::closeWindow()
{

    if (closeWindowFunction != nullptr)
    {
        std::invoke(closeWindowFunction);
    }
    else
    {
        this->removeFromDesktop();
    }
}

void PopupWindow::setTitleBarText(std::string text)
{
    this->setName(text);
}

void PopupWindow::setMinimumSize(int widthInPixels, int heightInPixels)
{
    auto winConstrainer = this->getConstrainer();
    if (winConstrainer->getFixedAspectRatio())
    {
        unfixAspectRatio();
    }
    setResizeLimits(widthInPixels, heightInPixels, winConstrainer->getMaximumWidth(), winConstrainer->getMaximumHeight());
}

void PopupWindow::setMaximumSize(int widthInPixels, int heightInPixels)
{
    auto winConstrainer = this->getConstrainer();
    if (winConstrainer->getFixedAspectRatio())
    {
        unfixAspectRatio();
    }
    setResizeLimits(winConstrainer->getMinimumWidth(), winConstrainer->getMinimumHeight(), widthInPixels, heightInPixels);
}

void PopupWindow::setFixedAspectRatio(double widthToHeightRatio)
{
    this->getConstrainer()->setFixedAspectRatio(widthToHeightRatio);
}


void PopupWindow::unfixAspectRatio()
{
    this->getConstrainer()->setFixedAspectRatio(0);
}

void PopupWindow::closeButtonPressed()
{
    closeWindow();
}

} // namespace CamdenLabs