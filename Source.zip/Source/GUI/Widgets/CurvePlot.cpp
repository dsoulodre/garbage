/*
  ==============================================================================

    CurvePlot.cpp
    Created: 13 Mar 2024 10:59:52am
    Author:  14372

  ==============================================================================
*/

#if 0
#include "CurvePlot.h"
#include "GUI/ColourScheme.h"

#include "AudioComponents/FilterIMPL.h"
#include "Helpers/CLAssert.h"
#include "Helpers/Utility.h"

#include <algorithm>




namespace CamdenLabs
{

static double biquadTransferFunction(const Biquad& biquad, double frequency)
{
    constexpr double pi = 3.141592653589;
    constexpr double omega = 2.0 * pi / 48000.0;

    //const double frequency = biquad.getFrequency();
    const double w0 = frequency * omega;

    const double piw0 = w0 * pi;
    const double cosw = std::cos(piw0);
    const double sinw = std::sin(piw0);

    const auto [aCoeffs, bCoeffs] = biquad.getCoefficients();
    
    const auto [a0, a1, a2] = aCoeffs;
    const auto [b0, b1, b2] = bCoeffs;
    
    const auto square = [](auto z) { return z * z; };

#if 0
    
    const double numerator = sqrt(square(a0 * square(cosw) - a0 * square(sinw) + a1 * cosw + a2) + square(2 * a0 * cosw * sinw + a1 * (sinw)));
    const double denominator = sqrt(square(square(cosw) - square(sinw) + b1 * cosw + b2) + square(2 * cosw * sinw + b1 * (sinw)));
    
    /*auto const w = std::sin(cpl::simd::consts<T>::pi * w / 2);
    auto const phi = w * w;
    auto const phi2 = phi * phi;
    
    // black magic. supposedly gives better precision than direct evaluation of H(z)
    auto const numerator = 10 * std::log10((b0 + b1 + b2) * (b0 + b1 + b2) - 4 * (b0 * b1 + 4 * b0 * b2 + b1 * b2) * phi + 16 * b0 * b2 * phi2);
    auto const denominator = -10 * std::log10((a0 + a1 + a2) * (a0 + a1 + a2) - 4 * (a0 * a1 + 4 * a0 * a2 + a1 * a2) * phi + 16 * a0 * a2 * phi2);
    return numerator + denominator; */
    
    return 20 * std::log10(numerator / denominator);
#else

    double numerator = square(a0) + square(a1) + square(a2) + 2.0 * (a0 * a1 + a1 * a2) * cosw + 2.0 * a0 * a2 * std::cos(2.0 * w0);
    double denominator = 1.0 + square(b1) + square(b2) + 2.0 * (b1 + b1 * b2) * cosw + 2.0 * b2 * std::cos(2.0 * w0);

    return std::sqrt(numerator / denominator); 
#endif
}

Curve::Curve()
{

}

void Curve::resized()
{
    needsRedrawing = true;
}

void Curve::paint(juce::Graphics& g)
{
    std::scoped_lock lock(mMutex);
    g.setColour(Colours::lightGrey);
    g.fillAll();

    if (needsRecalculating)
    {
        recalculate();
        plotInternal();
    }
    else if (needsRedrawing)
    {
        plotInternal();
    }

    g.setColour(juce::Colours::yellow);
    g.strokePath(mPath, juce::PathStrokeType(3.0));
}

void Curve::setFilter(const Biquad& biquad)
{
    setMapping([&](double x) { return biquadTransferFunction(biquad, x); });
    setRange(10.0, 1000.0);
    setResolution(0.1);
    needsRecalculating = true;
}

void Curve::setMapping(std::function<double(double)> mappingFunction)
{
    mMapping = mappingFunction;
    needsRecalculating = true;
}

void Curve::setRange(double min, double max)
{
    mDomainStart = min;
    mDomainEnd = max;
    mDomainSize = mDomainEnd - mDomainStart;
    needsRecalculating = true;
}

void Curve::setResolution(double resolution)
{
    mResolution = resolution;
    needsRecalculating = true;
}

void Curve::setData(const std::vector<double>& xData, const std::vector<double> yData)
{
    std::scoped_lock lock(mMutex);
    xValues = xData;
    yValues = yData;

    needsRecalculating = false;
    needsRedrawing = true;

    repaint();

}

void Curve::showSpectrum(const std::vector<float>& audioSamples)
{
    constexpr size_t numPoints = 1024;

#if 1
    int order = static_cast<int>(std::ceil(std::log2((float)audioSamples.size())));
    order = std::max(order, 12);
    size_t fftSize = 1 << order;

    juce::dsp::FFT fft(order);
    juce::dsp::WindowingFunction<float> window(audioSamples.size(), juce::dsp::WindowingFunction<float>::hann);

    std::vector<float> fftBuffer(fftSize * 2, 0.f);
    std::copy(audioSamples.begin(), audioSamples.end(), fftBuffer.begin());
    window.multiplyWithWindowingTable(fftBuffer.data(), audioSamples.size());
    fft.performFrequencyOnlyForwardTransform(fftBuffer.data(), true);

    /*
    The width of each frequency bin is determines solely by the rate the signal was sampled at and the length of the FFT.
    The width of each bin is the sampling frequency divided by the number of samples in your FFT.

    df = fs / N

    Frequency bins start from -fs/2 and go up to fs/2. That means if sampled at 100Hz for 100 samples, your frequency bins will be width 1 Hz.
    If you take 200 samples, you will now have 2x as many frequency bins and their width will be 1/2Hz each.
    */
    size_t outputSize = (fftSize / 2) + 1;
    double binWidth = 48000.0 / fftSize;
    std::vector<double> freqValues(numPoints);
    const double delta = 24000.0 / numPoints;
    double tempFreq = 0.0;
    for (auto& it : freqValues)
    {
        it = tempFreq;
        tempFreq += delta;
    }

    std::vector<double> yValues(numPoints);
    //std::copy(fftBuffer.begin(), fftBuffer.begin() + outputSize, yValues.begin());

    for (size_t i = 0; i < numPoints; ++i)
    {
    
        float skewedX = 1.f - std::exp(0.2f * std::log(1.f - (float)i / numPoints));
        auto index = std::clamp<size_t>(skewedX * fftSize * 0.5f, 0, fftSize / 2);
    
        constexpr float minDB = -100.f;
        constexpr float maxDB = 0.f;
    
        float decibels = Utility::amplitudeTodB(fftBuffer[index]) - Utility::amplitudeTodB(static_cast<float>(fftSize));
        decibels = std::clamp(decibels, minDB, maxDB);
    
        
        float level = Utility::normalize(decibels, minDB, maxDB);
    
        yValues[i] = static_cast<double>(level);
    }
#else
    std::vector<double> freqValues(numPoints);
    std::vector<double> yValues(numPoints);

    double x = 0.0;
    constexpr double delta = 2.0 * 3.14159265358979 / numPoints;
    for (size_t i = 0; i < numPoints; ++i)
    {
        freqValues[i] = (double)i;
        yValues[i] = std::sin(x);
        x += delta;
    }
    mDomainStart = 0.0;
    mDomainEnd = numPoints;
    mDomainSize = mDomainEnd;
#endif
    setData(freqValues, yValues);
    mDomainStart = 0.0;
    mDomainEnd = 24000.0;

}

double Curve::getMinY() const
{
    auto it = std::min_element(yValues.begin(), yValues.end());
    if (it == yValues.end())
    {
        CLAssert(0);
        return 0.0;
    }
    return *it;
}

double Curve::getMaxY() const
{
    auto it = std::max_element(yValues.begin(), yValues.end());
    if (it == yValues.end())
    {
        CLAssert(0);
        return 0.0;
    }
    return *it;
}

double Curve::valueToPixelX(double value) const
{
    double normalized = (value - mDomainStart) / (mDomainEnd - mDomainStart);
    if (!(normalized >= 0.0 && normalized <= 1.0))
    {
        CLAssert(0);
    }
    return normalized * this->getWidth();
}

double Curve::valueToPixelY(double value) const
{
    if (yMax == yMin)
    {
        return 0.0;
    }
    
    double normalized = 1.0 - (value - yMin) / (yMax - yMin);
    if(!(normalized >= 0.0 && normalized <= 1.0))
    {
        CLAssert(0);
    }
    return normalized * this->getHeight();
}

void Curve::plotInternal()
{ 
    if (xValues.empty() || yValues.empty())
    {
        mPath.clear();
        needsRecalculating = false;
        needsRedrawing = false;
        return;
    }
    yMin = getMinY();
    yMax = getMaxY();
    mPath.clear();
    mPath.startNewSubPath(valueToPixelX(xValues[0]), valueToPixelY(yValues[0]));
    for (size_t i = 1; i < xValues.size(); ++i)
    {
        double screenX = valueToPixelX(xValues[i]);
        double screenY = valueToPixelY(yValues[i]);
        mPath.lineTo(screenX, screenY);
    }
}

void Curve::recalculate()
{
    if (mMapping == nullptr)
    {
        CLAssert(0);
        return;
    }

    size_t numPoints = static_cast<size_t>((mDomainEnd - mDomainStart) / mResolution + 0.5);
    xValues.resize(numPoints);
    yValues.resize(numPoints);

    double x = mDomainStart;
    for (size_t i = 0; i < numPoints; ++i)
    {
        xValues[i] = x;
        yValues[i] = mMapping(x);
        x += mResolution;
    }
}

} // namespace CamdenLabs

#endif