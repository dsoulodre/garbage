/*
  ================================================================================
  *      File                                        GUIComponent.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "ComponentManager/Listener.h"

#include "JuceHeader.h" 
#include <memory>

namespace CamdenLabs
{

class GUIComponent : public juce::Component
{
public:

    GUIComponent() = default;
    virtual ~GUIComponent() = default;

    GUIComponent(GUIComponent&&) = default;

    void addListener(std::unique_ptr<Listener>&& listener);

    virtual void attachListener() = 0;

    // When changes are made internally, such as loading presets, this function updates the GUI to reflect the changes in the back end, i.e. slider position, enablement, etc.
    virtual void updateState() {}
    
    void setID(uint64_t id);

    uint64_t componentID() const;

    void parentSizeChanged() override;

    void showOutline(bool shouldBeVisible);

    void setTitle(const juce::String& text, juce::Justification::Flags position = juce::Justification::topLeft);

    auto listener() const -> Listener* const;

protected:

    juce::GroupComponent outline;
    uint64_t mID{ 0 };
    std::unique_ptr<Listener> mListener{ nullptr };
};



} // namespace CamdenLabs