/*
  ================================================================================
  *      File                                        ColourScheme.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"

#include "JuceHeader.h"
#include <memory>

namespace CamdenLabs
{

namespace Colours
{
    inline const juce::Colour transparent                                 (juce::PixelARGB(  0,   0,   0,   0));
    inline const juce::Colour white                                       (juce::PixelARGB(255, 255, 255, 255));
    inline const juce::Colour lightGrey                                   (juce::PixelARGB(255, 164, 164, 164));
    inline const juce::Colour grey                                        (juce::PixelARGB(255, 128, 128, 128));
    inline const juce::Colour darkGrey                                    (juce::PixelARGB(255,  85,  85,  85));
    inline const juce::Colour dimGrey                                     (juce::PixelARGB(255, 105, 105, 105));


    inline const juce::Colour backgroundColour                            (juce::PixelARGB(255,  32,  33,  34));
    inline const juce::Colour outerEdgeColour                             (juce::PixelARGB(240,  32,  33,  34));
          
    inline const juce::Colour textColour                          =       (juce::PixelARGB(255, 255, 255, 255)); // white
    inline const juce::Colour textDisabledColour                  =       (juce::PixelARGB(255, 128, 128, 128)); // grey
    inline const juce::Colour textHighlightColour                         (juce::PixelARGB(102,  66, 162, 200));
          
    inline const juce::Colour darkButtonColour                            (juce::PixelARGB(255,  22,  23,  24));
    inline const juce::Colour lightButtonColour                           (juce::PixelARGB(255,  42,  43,  44));
    inline const juce::Colour navyBlueButton                              (juce::PixelARGB(255,  22,  29,  40));
    inline const juce::Colour buttonHoverColour                           (juce::PixelARGB(255,  68,  69,  70));
        
    inline const juce::Colour buttonColour                        =       (juce::PixelARGB(255,  22,  23,  24)); // darkButtonColour
    inline const juce::Colour buttonDisabledColour                =       (juce::PixelARGB(255,  85,  85,  85)); // darkGrey
    inline const juce::Colour buttonDisabledTextColour            =       (juce::PixelARGB(255, 128, 128, 128)); // grey
           
           
    inline const juce::Colour popupMenuColour                             (juce::PixelARGB(255,  22,  23,  24));
    inline const juce::Colour textBoxColour                               (juce::PixelARGB(255,  61,  61,  62));
    inline const juce::Colour textBoxInvalidColour                        (juce::PixelARGB(255, 239,   0,   0));
                                                                                       
    inline const juce::Colour sliderThumbColour                           (juce::PixelARGB(255,  66, 162, 200));
    inline const juce::Colour sliderTrackFill                             (juce::PixelARGB(255,  24,  31,  34));

} // namespace Colours

class ColourScheme : public juce::LookAndFeel_V4
{
public:

    static ColourScheme& getInstance();

    juce::AlertWindow* createAlertWindow(const juce::String& title, 
                                         const juce::String& message, 
                                         const juce::String& button1, 
                                         const juce::String& button2, 
                                         const juce::String& button3, 
                                         juce::MessageBoxIconType iconType,
                                         int numButtons, 
                                         juce::Component* associatedComponent) override
    {
        auto window = juce::LookAndFeel_V4::createAlertWindow(title,
                                                              message,
                                                              button1,
                                                              button2,
                                                              button3,
                                                              iconType,
                                                              numButtons,
                                                              associatedComponent);

        window->setLookAndFeel(this);
        return window;
    }

private:

    ColourScheme();
    ~ColourScheme();
    ColourScheme(const ColourScheme& other) = delete;
    ColourScheme(ColourScheme&& other) = delete;
    void operator=(const ColourScheme& other) = delete;
    void operator=(ColourScheme&& other) = delete;

    static std::mutex colourMutex;
};

} // namespace CamdenLabs