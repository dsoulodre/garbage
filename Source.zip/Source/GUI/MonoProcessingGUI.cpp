/*
  ==============================================================================

    MonoProcessingGUI.cpp
    Created: 3 Mar 2024 6:10:49pm
    Author:  14372

  ==============================================================================
*/

#include "MonoProcessingGUI.h"
#include "AppMain/AudioProcessor/MonoProcessingBlock.h"
#include "GUI/ColourScheme.h"
#include "Helpers/Utility.h"


#include <type_traits>

namespace CamdenLabs
{

MonoProcessingGUI::MonoProcessingGUI()
{
    addAndMakeVisible(mProcessingBlock);

    addAndMakeVisible(mGainKnob);
    mGainKnob.setTextFromValueFunction([](double val) { return juce::String(Utility::amplitudeTodB(val * MonoProcessingBlock::maxGain), 2); });
    mGainKnob.setValueFromTextFunction([](juce::String text) { return Utility::dBtoAmplitude(text.getDoubleValue()) / MonoProcessingBlock::maxGain; });
    mGainKnob.setParameterUnits("dB");

    addAndMakeVisible(mPhaseButton);
    mPhaseButton.setButtonText("Invert Phase");
    mPhaseButton.onClick = [&]() { phaseButtonClicked(); };
}

void MonoProcessingGUI::resized()
{
    constexpr float padding = 0.025f;
              
    constexpr float knobWidth = 0.3f;
    constexpr float knobHeight = knobWidth * 2.f;
             
    constexpr float knobW = knobWidth - (2.f * padding);
    constexpr float knobH = knobHeight - (2.f * padding);
    constexpr float knobX = padding;
    constexpr float knobY = (1.f - knobHeight) / 2.f;
            
    constexpr float buttonWidth = 0.1f;
    constexpr float buttonHeight = 0.3f;
            
    constexpr float buttonW = buttonWidth - (2.f * padding);
    constexpr float buttonH = buttonHeight - (2.f * padding);
    constexpr float buttonX = knobWidth;
    constexpr float buttonY = (1.f - buttonHeight) / 2.f;
       
    constexpr float procWidth = 1.f - (knobWidth + buttonWidth);
    constexpr float procHeight = 1.f;
           
    constexpr float procX = knobWidth + buttonWidth;
    constexpr float procY = padding;
    constexpr float procW = procWidth - (2.f * padding);
    constexpr float procH = procHeight - (2.f * padding);

    // Left channel 
    mGainKnob.setBoundsRelative(knobX, knobY, knobW, knobH);
    mPhaseButton.setBoundsRelative(buttonX, buttonY, buttonW, buttonH);
    mProcessingBlock.setBoundsRelative(procX, procY, procW, procH);

}

void MonoProcessingGUI::attachListener()
{
    using T = MonoProcessingBlock::Parameters;
    for (auto it : listener()->getParameters())
    {
        switch (it->paramID<MonoProcessingBlock>())
        {
        case T::Gain:
            mGainKnob.setAudioParameter(it);
            mGainKnob.setCallbacks(listener(), it->paramID());
            mGainKnob.buttonClickedFunction = [&](bool shoudBeMuted) { listener()->component()->setEnabled(!shoudBeMuted); };
            break;

        case T::Phase:
            break;

        default:
            CLAssert(0);
        }
    }
}

void MonoProcessingGUI::updateState()
{
    using T = MonoProcessingBlock::Parameters;
    for (auto it : listener()->getParameters())
    {
        switch (it->paramID<MonoProcessingBlock>())
        {
        case T::Gain:
            mGainKnob.setValue(it->normalizedValue());
            break;

        case T::Phase:
            if (mPhaseIsInverted != it->toBool())
            {
                phaseButtonClicked();
            }
            break;

        default:
            CLAssert(0);
        }
    }
}

void MonoProcessingGUI::phaseButtonClicked()
{
    mPhaseIsInverted = !mPhaseIsInverted;

    double normalizedVal = mPhaseIsInverted ? 1.0 : 0.0;

    listener()->setParameterValue(MonoProcessingBlock::Parameters::Phase, normalizedVal);

    if (mPhaseIsInverted)
    {
        mPhaseButton.setColour(juce::TextButton::ColourIds::buttonColourId, Colours::buttonDisabledColour);
        mPhaseButton.setColour(juce::TextButton::ColourIds::textColourOffId, Colours::textDisabledColour);
        mPhaseButton.setButtonText("Reset phase");
        mPhaseButton.setTooltip("Phase is currently inverted");

    }
    else
    {
        mPhaseButton.setColour(juce::TextButton::ColourIds::buttonColourId, Colours::darkButtonColour);
        mPhaseButton.setColour(juce::TextButton::ColourIds::textColourOffId, Colours::textColour);
        mPhaseButton.setButtonText("Invert phase");
        mPhaseButton.setTooltip("");
    }
    repaint();

}

} // namespace CamdenLabs