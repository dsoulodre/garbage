/*
  ==============================================================================

    CrossoverGUI.h
    Created: 3 Mar 2024 6:10:56pm
    Author:  14372

  ==============================================================================
*/
/*
- HPF & LPF combo with same Fc
- selectable Fc [50-500Hz, 1Hz resolution]
- selectable number of filter stages

Biquad has rolloff of 12dB/oct
*/
#pragma once
#include "CLHeader.h"
#include "GUI/GUIComponent.h"
#include "GUI/Widgets/KnobsAndSliders/Slider.h"

namespace CamdenLabs
{

class CrossoverGUI : public GUIComponent
{
public:

    CrossoverGUI();

    void resized() override;

    void attachListener() override;

    void updateState() override;

private:

    Slider frequencySlider;
    Slider rollOffSlider;

    juce::Label frequencyLabel;
    juce::Label rollOffLabel;


};


} // namespace CamdenLabs