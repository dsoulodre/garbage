/*
  ==============================================================================

    CrossoverGUI.cpp
    Created: 3 Mar 2024 6:10:56pm
    Author:  14372

  ==============================================================================
*/

#include "CrossoverGUI.h"
#include "AppMain/AudioProcessor/CrossoverBlock.h"

namespace CamdenLabs
{

CrossoverGUI::CrossoverGUI()
{
    addAndMakeVisible(frequencySlider);
    frequencySlider.setLabel(frequencyLabel, "Frequency");
    frequencySlider.enableTextBox(false);
    frequencySlider.setParameterUnits("Hz");

    addAndMakeVisible(rollOffSlider);
    rollOffSlider.setLabel(rollOffLabel, "Roll Off");
    rollOffSlider.enableTextBox(false);

}

void CrossoverGUI::resized()
{
    constexpr float spacing = 0.2f;
    constexpr float paddingX = 0.05f;
    constexpr float totalWidth = 1.f - (2.f * paddingX);

    constexpr float labelHeight = 0.3f;
    constexpr float paddingY = (1.f - (2.f * labelHeight + spacing)) / 2.f;

    constexpr float labelWidth = 0.1f;
    constexpr float labelX = paddingX;
    constexpr float labelY = paddingY;
    constexpr float bottomLabelY = labelY + labelHeight + spacing;

    constexpr float sliderWidth = totalWidth - labelWidth;
    constexpr float sliderHeight = labelHeight;

    constexpr float sliderX = labelX + labelWidth;
    constexpr float sliderY = labelY;
    constexpr float bottomSliderY = bottomLabelY;

    frequencySlider.setBoundsRelative(sliderX, sliderY, sliderWidth, sliderHeight);
    rollOffSlider.setBoundsRelative(sliderX, bottomSliderY, sliderWidth, sliderHeight);

    frequencyLabel.setBoundsRelative(labelX, labelY, labelWidth, labelHeight);
    rollOffLabel.setBoundsRelative(labelX, bottomLabelY, labelWidth, labelHeight);

}

void CrossoverGUI::attachListener()
{
    using T = CrossoverBlock::Parameters;
    for (auto& it : mListener->getParameters())
    {
        switch (it->paramID<CrossoverBlock>())
        {
        case T::Frequency:
            frequencySlider.setAudioParameter(it);
            frequencySlider.setCallbacks(this->listener(), it->paramID());
            break;

        case T::NumStages:
            rollOffSlider.setAudioParameter(it);
            rollOffSlider.setCallbacks(this->listener(), it->paramID());
            rollOffSlider.setSnapValueFunction([it](double val) { return it->normalize(std::floor(it->denormalize(val) + 0.5)); });


            rollOffSlider.setTextFromValueFunction([it](double val)
                {
                    using Str = juce::String;
                    int numStages = static_cast<int>(std::floor(it->denormalize(val)));
                    int dbPerOct = numStages * 12;
                    return Str(numStages) + Str(" stages (") + Str(dbPerOct) + Str(" dB/oct)");
                });

//            rollOffSlider.setValueFromTextFunction([it](juce::String text) { return it->normalize(std::floor(text.getDoubleValue() + 0.5)); });
        }
    }
}

void CrossoverGUI::updateState()
{
    for (const auto it : mListener->getParameters())
    {
        using T = CrossoverBlock::Parameters;
        switch (it->paramID<CrossoverBlock>())
        {
        case T::Frequency:
            frequencySlider.setValue(it->normalizedValue());
            break;

        case T::NumStages:
            rollOffSlider.setValue(it->normalizedValue());
            break;

        default:
            CLAssert(0);
            continue;
        }
    }
}

} // namespace CamdenLabs