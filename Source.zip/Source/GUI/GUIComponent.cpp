/*
  ================================================================================
  *      File                                      GUIComponent.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "GUIComponent.h"

namespace CamdenLabs
{

void GUIComponent::addListener(std::unique_ptr<Listener>&& listener)
{
    mListener = std::move(listener);

    if (componentID() == 0)
    {
        this->mID = mListener->componentID();
    }
    attachListener();
}

void GUIComponent::setID(uint64_t id)
{
    mID = id;
}

uint64_t GUIComponent::componentID() const
{
    return mID;
}

void GUIComponent::parentSizeChanged()
{
    outline.setBoundsRelative(0.0, 0.0, 1.0, 1.0);
}

void GUIComponent::showOutline(bool shouldBeVisible)
{
    if (shouldBeVisible)
    {
        addAndMakeVisible(outline);
    }
    else
    {
        removeChildComponent(&outline);
    }
}

void GUIComponent::setTitle(const juce::String& text, juce::Justification::Flags position)
{
    outline.setText(text);
    outline.setTextLabelPosition(position);
    showOutline(true);
}

auto GUIComponent::listener() const -> Listener* const
{
    return mListener.get();
}



} // namespace CamdenLabs