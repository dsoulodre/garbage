/*
  ==============================================================================

    StereoProcessingGUI.h
    Created: 3 Mar 2024 6:10:30pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "GUI/GUIComponent.h"
#include "GUI/AudioComponentGUIs/ProcessorComponentGUI.h"
#include "GUI/Widgets/KnobsAndSliders/GainKnob.h"

/*
Stereo gain (dB) [0.1dB resolution]
(one control for both chans)
- Stereo EQ (filters)
(controls linked to both L & R chans)
- Expander processor (imaging)
*/

namespace CamdenLabs
{

class StereoProcessingGUI : public GUIComponent
{
public:

    StereoProcessingGUI();

    void resized() override;

    void attachListener() override;

    void updateState() override;

    PostProcessingGUI mProcessingBlock;

private:

    
    GainKnob mGainKnob;

};

} // namespace CamdenLabs