/*
  ================================================================================
  *      File                                      ColourScheme.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "ColourScheme.h"

namespace CamdenLabs
{
    std::mutex ColourScheme::colourMutex;

ColourScheme& ColourScheme::getInstance()
{
    std::lock_guard<std::mutex> lock(colourMutex);
    static ColourScheme instance;
    return instance;
}

ColourScheme::ColourScheme()
{
    setColour(juce::ComboBox::ColourIds::backgroundColourId, juce::Colours::dimgrey);
    setColour(juce::ComboBox::ColourIds::textColourId, Colours::white);

    setColour(juce::PopupMenu::ColourIds::backgroundColourId, Colours::popupMenuColour);
    setColour(juce::PopupMenu::ColourIds::highlightedBackgroundColourId, Colours::popupMenuColour.brighter(0.05f));

    setColour(juce::TextButton::ColourIds::buttonColourId, Colours::darkButtonColour);

    setColour(juce::TextButton::ColourIds::textColourOnId, Colours::white);
    setColour(juce::TextButton::ColourIds::textColourOffId, Colours::white);

    setColour(juce::TextEditor::ColourIds::backgroundColourId, Colours::textBoxColour);
    setColour(juce::TextEditor::ColourIds::textColourId, Colours::white);

    setColour(juce::AlertWindow::ColourIds::backgroundColourId, Colours::backgroundColour);
    setColour(juce::AlertWindow::ColourIds::textColourId, Colours::textColour);

    setColour(juce::ResizableWindow::ColourIds::backgroundColourId, Colours::backgroundColour);

    setColour(juce::ListBox::ColourIds::backgroundColourId, Colours::backgroundColour.brighter(0.125f));
}

ColourScheme::~ColourScheme()
{

}


} // namespace CamdenLabs