/*
  ==============================================================================

    StereoProcessingGUI.cpp
    Created: 3 Mar 2024 6:10:30pm
    Author:  14372

  ==============================================================================
*/

#include "StereoProcessingGUI.h"
#include "AppMain/AudioProcessor/StereoProcessingBlock.h"
#include "Helpers/Utility.h"

namespace CamdenLabs
{

StereoProcessingGUI::StereoProcessingGUI()
{
    addAndMakeVisible(mProcessingBlock);

    addAndMakeVisible(mGainKnob);

    mGainKnob.setTextFromValueFunction([](double val) { return juce::String(Utility::amplitudeTodB(val * StereoProcessingBlock::maxGain), 2); });
    mGainKnob.setValueFromTextFunction([](juce::String text) { return Utility::dBtoAmplitude(text.getDoubleValue()) / StereoProcessingBlock::maxGain; });
    mGainKnob.setParameterUnits("dB");

}

void StereoProcessingGUI::resized()
{
    constexpr float knobPadding = 0.01f;
    constexpr float knobWidth = 0.3f;
    constexpr float knobHeight = knobWidth;
          
    constexpr float knobW = knobWidth - (2.f * knobPadding);
    constexpr float knobH = knobHeight - (2.f * knobPadding);
    constexpr float knobX = knobPadding + (1.f - knobWidth) / 2.f;
    constexpr float knobY = knobPadding;
           
    constexpr float postPadding = 0.01f;
    constexpr float postWidth = 1.f;
    constexpr float postHeight = 1.f - knobHeight;

    constexpr float postW = postWidth - (2.f * postPadding);
    constexpr float postH = postHeight - (2.f * postPadding);
    constexpr float postX = postPadding;
    constexpr float postY = knobHeight + postPadding;

    mGainKnob.setBoundsRelative(knobX, knobY, knobW, knobH);

    mProcessingBlock.setBoundsRelative(postX, postY, postW, postH);
}

void StereoProcessingGUI::attachListener() 
{
    using T = StereoProcessingBlock::Parameters;
    for (auto it : listener()->getParameters())
    {
        switch (it->paramID<StereoProcessingBlock>())
        {
        case T::Gain:
            mGainKnob.setAudioParameter(it);
            mGainKnob.setCallbacks(listener(), it->paramID());
            mGainKnob.buttonClickedFunction = [&](bool shouldBeMuted) { listener()->component()->setEnabled(!shouldBeMuted); };
            break;

        default:
            CLAssert(0);
            break;
        }
    }
}

void StereoProcessingGUI::updateState()
{
    using T = StereoProcessingBlock::Parameters;
    for (auto it : listener()->getParameters())
    {
        switch (it->paramID<StereoProcessingBlock>())
        {
        case T::Gain:
            mGainKnob.setValue(it->normalizedValue());
            break;

        default:
            CLAssert(0);
            break;
        }
    }
}

} // namespace CamdenLabs