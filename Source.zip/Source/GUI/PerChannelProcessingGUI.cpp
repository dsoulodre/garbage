/*
  ==============================================================================

    PerChannelProcessingGUI.cpp
    Created: 3 Mar 2024 6:11:14pm
    Author:  14372

  ==============================================================================
*/

#include "PerChannelProcessingGUI.h"
#include "AppMain/AudioProcessor/FinalProcessingBlock.h"
#include "Helpers/Utility.h"
#include "GUI/ColourScheme.h"



namespace CamdenLabs
{

PerChannelProcessingGUI::PerChannelProcessingGUI()
{

    addAndMakeVisible(gainKnob);
    gainKnob.setLabel(gainLabel, "Gain");

    gainKnob.setTextFromValueFunction([](double val) { return juce::String(Utility::amplitudeTodB(val * FinalProcessingBlock::maxGain), 2); });
    gainKnob.setValueFromTextFunction([](juce::String text) { return Utility::dBtoAmplitude(text.getDoubleValue()) / FinalProcessingBlock::maxGain; });
    gainKnob.setParameterUnits("dB");

    addAndMakeVisible(delaySlider);
    delaySlider.setLabel(delayLabel, "Delay");
    delaySlider.enableTextBox(false);

    addAndMakeVisible(phaseButton);
    phaseButton.setButtonText("Invert phase");
    phaseButton.onClick = [&]() { phaseButtonClicked(); };

    addAndMakeVisible(eqButton);
    eqButton.setButtonText("EQ");
    eqButton.onClick = [&]() { eqButtonClicked(); };

    showOutline(true);
}

void PerChannelProcessingGUI::resized()
{
    constexpr float spacing = 0.05f;

    constexpr float paddingX = 0.0f;
    constexpr float paddingY = 0.05f;

    constexpr float height = 1.f - (2.f * paddingY);

    constexpr float labelX = paddingX;
    constexpr float labelY = paddingY;
    constexpr float labelWidth = 0.1f;

    constexpr float sliderX = labelX + labelWidth;
    constexpr float sliderY = labelY;
    constexpr float sliderTotalWidth = 0.5f;
    constexpr float sliderWidth = sliderTotalWidth - (labelWidth + paddingX);

    constexpr float knobWidth = 0.2f;

    constexpr float buttonWidth = 1.f - (sliderTotalWidth + 2.f * knobWidth + paddingX);
    constexpr float buttonHeight = height / 2.f;
    constexpr float buttonY = paddingY + buttonHeight / 2.f;

    constexpr float eqX = paddingX + sliderTotalWidth + spacing;
    constexpr float phaseX = eqX + buttonWidth + spacing;

    constexpr float knobX = phaseX + buttonWidth + spacing;
    constexpr float knobY = paddingY;

    delayLabel.setBoundsRelative(labelX, labelY, labelWidth, height);
    delaySlider.setBoundsRelative(sliderX, sliderY, sliderWidth, height);

    eqButton.setBoundsRelative(eqX, buttonY, buttonWidth, buttonHeight);
    phaseButton.setBoundsRelative(phaseX, buttonY, buttonWidth, buttonHeight);
    gainKnob.setBoundsRelative(knobX, knobY, knobWidth, height);

}

void PerChannelProcessingGUI::attachListener()
{
    using T = FinalProcessingBlock::Parameters;
    for (auto it : listener()->getParameters())
    {
        switch (it->paramID<FinalProcessingBlock>())
        {
        case T::Gain:
            gainKnob.setAudioParameter(it);
            gainKnob.setCallbacks(listener(), it->paramID());
            gainKnob.buttonClickedFunction = [&](bool shouldBeMuted) { listener()->component()->setEnabled(!shouldBeMuted); };
            break;

        case T::Polarity:
            break;

        case T::Delay:
            delaySlider.setAudioParameter(it);
            delaySlider.setCallbacks(listener(), it->paramID());
            delaySlider.setSnapValueFunction([it](double val) { return it->normalize(std::floor(it->denormalize(val) + 0.5)); });
            delaySlider.setValueFromTextFunction([it](juce::String text) { return it->normalize(text.getDoubleValue()); });
            delaySlider.setTextFromValueFunction([this, it](double val) 
                                                  { 
                                                        int numSamples = static_cast<int>(it->denormalize(val) + 0.5);
                                                        double milliseconds = 1000.0 * numSamples / mSampleRate;
                                                        auto sampleStr = juce::String(numSamples) + juce::String(" samples");
                                                        auto milliStr = juce::String(milliseconds, 1, false) + juce::String(" ms");
                                                        return sampleStr + " (" + milliStr + ")";
                                                  });
            break;

        default:
            CLAssert(0);
        }
    }
}

void PerChannelProcessingGUI::updateState()
{
    using T = FinalProcessingBlock::Parameters;
    for (auto it : listener()->getParameters())
    {
        switch (it->paramID<FinalProcessingBlock>())
        {
        case T::Gain:
            gainKnob.setValue(it->normalizedValue());
            break;

        case T::Polarity:
            if (isInverted != it->toBool())
            {
                phaseButtonClicked();
            }
            break;

        case T::Delay:
            delaySlider.setValue(it->normalizedValue());
            break;

        default:
            CLAssert(0);
        }
    }
}

void PerChannelProcessingGUI::setSampleRate(double sampleRate)
{
    mSampleRate = sampleRate;
    delaySlider.updateText();
}

void PerChannelProcessingGUI::phaseButtonClicked()
{
    isInverted = !isInverted;

    double normalizedValue = isInverted ? 1.0 : 0.0;
    listener()->setParameterValue(FinalProcessingBlock::Parameters::Polarity, normalizedValue);

    if (isInverted)
    {
        phaseButton.setColour(juce::TextButton::ColourIds::buttonColourId, Colours::buttonDisabledColour);
        phaseButton.setColour(juce::TextButton::ColourIds::textColourOffId, Colours::textDisabledColour);
        phaseButton.setButtonText("Reset phase");
        phaseButton.setTooltip("Phase is currently inverted");

    }
    else
    {
        phaseButton.setColour(juce::TextButton::ColourIds::buttonColourId, Colours::darkButtonColour);
        phaseButton.setColour(juce::TextButton::ColourIds::textColourOffId, Colours::textColour);
        phaseButton.setButtonText("Invert phase");
        phaseButton.setTooltip("");
    }
    repaint();
}

void PerChannelProcessingGUI::eqButtonClicked()
{
    auto centerX = getScreenX() + getWidth() / 2;
    auto centerY = getScreenY() + getHeight() / 2;

    postProcessingPopup.launch(centerX, centerY);
}

} // namespace CamdenLabs