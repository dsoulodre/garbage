/*
  ================================================================================
  *      File                                        GUIFactory.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/
#include "GUIFactory.h"
#include "GUI/GUIComponent.h"
#include "ComponentManager/ComponentID.h"
#include "GUI/AudioComponentGUIs/ProcessorComponentGUI.h"
#include "GUI/AudioComponentGUIs/FilterGUIs.h"
#include "GUI/AudioComponentGUIs/EffectGUIs.h"
#include "Helpers/CLAssert.h"

namespace CamdenLabs
{

std::unique_ptr<GUIComponent> createGUI(PostProcessingComponent::ComponentType type)
{
    using Type = PostProcessingComponent::ComponentType;
    switch (type)
    {
    case Type::LowpassFilter:
        return std::make_unique<LowPassGUI>();

    case Type::HighpassFilter:
        return std::make_unique<HighPassGUI>();

    case Type::PeakFilter:
        return std::make_unique<PeakGUI>();

    case Type::BandpassFilter:
        return std::make_unique<BandPassGUI>();

    case Type::NotchFilter:
        return std::make_unique<NotchGUI>();

    case Type::LowShelfFilter:
        return std::make_unique<LowShelfGUI>();

    case Type::HighShelfFilter:
        return std::make_unique<HighShelfGUI>();

    case Type::AllPassFilter:
        return std::make_unique<AllPassGUI>();

    case Type::CombFilter:
        return std::make_unique<CombFilterGUI>();

    case Type::Phaser:
        return std::make_unique<PhaserGUI>();

    case Type::Compressor:
        return std::make_unique<CompressorGUI>();

    case Type::Distortion:
        return std::make_unique<DistortionGUI>();

    case Type::BitCrusher:
        return std::make_unique<BitCrusherGUI>();

    case Type::Chopper:
        return std::make_unique<ChopperGUI>();

    case Type::Expander:
        return std::make_unique<ExpanderGUI>();

    case Type::Chorus:
        return std::make_unique<ChorusGUI>();

    default:
        CLAssert(0);
        return nullptr;
    }
}

} // namespace CamdenLabs