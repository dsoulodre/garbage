/*
  ==============================================================================

    MonoProcessingGUI.h
    Created: 3 Mar 2024 6:10:49pm
    Author:  14372

  ==============================================================================
*/

#pragma once
#include "CLHeader.h"
#include "GUI/GUIComponent.h"
#include "GUI/AudioComponentGUIs/ProcessorComponentGUI.h"
#include "GUI/Widgets/KnobsAndSliders/GainKnob.h"

/*
Gain (dB) [0.1dB resolution]
- EQ (filters)
- Phase switch (polarity)
*/

namespace CamdenLabs
{

class MonoProcessingGUI : public GUIComponent
{
public:

    MonoProcessingGUI();

    void resized() override;

    void attachListener() override;

    void updateState() override;

    PostProcessingGUI mProcessingBlock;

private:

    void phaseButtonClicked();


    GainKnob mGainKnob;
    juce::TextButton mPhaseButton;
    bool mPhaseIsInverted{ false };
};

// Holds 2 MonoProcessingGUIs
struct MonoBlockGUI : public juce::Component
{
    MonoBlockGUI()
    {
        addAndMakeVisible(channels[0]);
        addAndMakeVisible(channels[1]);
        resized();
    }

    void resized() override
    {
        channels[0].setBoundsRelative(0.f, 0.f, 1.f, 0.5f);
        channels[1].setBoundsRelative(0.f, 0.5f, 1.f, 0.5f);
    }

    std::array<MonoProcessingGUI, Constants::numInputs> channels;
};

} // namespace CamdenLabs