/*
  ================================================================================
  *      File                            ProcessorComponentGUIs.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "ProcessorComponentGUI.h"
#include "GUI/ColourScheme.h"
#include "AudioComponents/PostProcessingComponent.h"
#include "ComponentManager/AudioComponentManager.h"
#include "Helpers/CLAssert.h"

#include <algorithm>

constexpr int addComponentMenuOffset = 1000;


namespace CamdenLabs
{

static constexpr int ID(PostProcessingComponent::ComponentType type)
{
    return static_cast<int>(type);
}


PostProcessingGUI::PostProcessingGUI()
{
    this->setTitle("Post-Processing");

    addAndMakeVisible(componentDropdown);
    componentDropdown.setColour(juce::ComboBox::ColourIds::backgroundColourId, juce::Colours::dimgrey);
    componentDropdown.setColour(juce::ComboBox::ColourIds::textColourId, juce::Colours::white);
    componentDropdown.setTextWhenNothingSelected("Add component");
    componentDropdown.onChange = [&]() { componentSelected(); };

    namespace CLID = CamdenLabs::ComponentIDs;
    using Type = PostProcessingComponent::ComponentType;

    juce::PopupMenu filterPopup;
    filterPopup.addItem(CLID::PostProcessingType::LowpassID   + addComponentMenuOffset, "Low Pass Filter");
    filterPopup.addItem(CLID::PostProcessingType::HighpassID  + addComponentMenuOffset, "High Pass Filter");
    filterPopup.addItem(CLID::PostProcessingType::PeakID      + addComponentMenuOffset, "Peak Filter");
    filterPopup.addItem(CLID::PostProcessingType::BandpassID  + addComponentMenuOffset, "Band Pass Filter");
    filterPopup.addItem(CLID::PostProcessingType::NotchID     + addComponentMenuOffset, "Notch Filter");
    filterPopup.addItem(CLID::PostProcessingType::LowShelfID  + addComponentMenuOffset, "Low Shelf Filter");
    filterPopup.addItem(CLID::PostProcessingType::HighShelfID + addComponentMenuOffset, "High Shelf Filter");
    filterPopup.addItem(CLID::PostProcessingType::AllPassID   + addComponentMenuOffset, "All Pass Filter");
    filterPopup.addItem(CLID::PostProcessingType::CombID      + addComponentMenuOffset, "Comb Filter");

    newComponentPopup.addSubMenu("Filters", filterPopup);

    juce::PopupMenu effectPopup;
    effectPopup.addItem(CLID::PostProcessingType::PhaserID + addComponentMenuOffset, "Phaser");
    effectPopup.addItem(CLID::PostProcessingType::CompressorID + addComponentMenuOffset, "Compressor");
    effectPopup.addItem(CLID::PostProcessingType::DistortionID + addComponentMenuOffset, "Distortion");
    effectPopup.addItem(CLID::PostProcessingType::BitCrusherID + addComponentMenuOffset, "Bit Crusher");
    effectPopup.addItem(CLID::PostProcessingType::ChopperID + addComponentMenuOffset, "Chopper");
    effectPopup.addItem(CLID::PostProcessingType::ExpanderID + addComponentMenuOffset, "Expander");
    effectPopup.addItem(CLID::PostProcessingType::ChorusID + addComponentMenuOffset, "Chorus");

    newComponentPopup.addSubMenu("Effects", effectPopup);

    componentDropdown.setLookAndFeel(&ColourScheme::getInstance());

    componentDropdownPopup = componentDropdown.getRootMenu();
    componentDropdownPopup->addSubMenu("Add New Component", newComponentPopup);

    numMenuItems = componentDropdown.getNumItems();


    addAndMakeVisible(deleteButton);
    deleteButton.setButtonText("Delete");
    deleteButton.setTooltip("Delete this component");
    deleteButton.setVisible(false);
    deleteButton.onClick = [&]() { deleteButtonClicked(); };


    addAndMakeVisible(bypassButton);
    bypassButton.setButtonText("Bypass");
    bypassButton.setTooltip("Bypass this component");
    bypassButton.setVisible(false);
    bypassButton.onClick = [&]() { bypassButtonClicked(); };

    setLookAndFeel(&ColourScheme::getInstance());
}

PostProcessingGUI::~PostProcessingGUI()
{
    componentDropdown.setLookAndFeel(nullptr);
}

void PostProcessingGUI::attachListener()
{

}

void PostProcessingGUI::resized()
{
    componentDropdown.setBoundsRelative(0.1f, 0.1f, 0.6f, 0.1f);
    deleteButton.setBoundsRelative(0.7f, 0.1f, 0.1f, 0.1f);
    bypassButton.setBoundsRelative(0.8f, 0.1f, 0.1f, 0.1f);

    if (activeComponent != nullptr)
    {
        activeComponent->setBoundsRelative(0.025f, 0.25f, 0.95f, 0.7f);
    }
}

void PostProcessingGUI::componentSelected()
{
    auto id = componentDropdown.getSelectedId();
    if (id == 0)
    {
        activeComponent = nullptr;
        resized();
        return;
    }

    if (id >= addComponentMenuOffset) // Simple separation of existing components vs new components
    {
        createNewComponent(id - addComponentMenuOffset);
        return;
    }
    if (activeComponent != nullptr)
    {
        activeComponent->setVisible(false);
    }
    auto temp = findComponent(id);
    
    activeComponent = temp->component;
    activeComponent->setVisible(true);
    updateBypassButton();
    resized();
}

void PostProcessingGUI::addComponent(std::unique_ptr<GUIComponent>&& newComponent)
{
    namespace CLID = CamdenLabs::ComponentIDs;

    ++componentIndex;
    auto textIndex = componentDropdown.indexOfItemId(addComponentMenuOffset + static_cast<int>(CLID::getPostProcessingType(newComponent->componentID())));

    mComponents.push_back({ std::move(newComponent), componentIndex , false});
    addChildComponent(*mComponents.back().component);

    auto text = componentDropdown.getItemText(textIndex);
    componentDropdown.addItem(text, componentIndex);

    deleteButton.setVisible(true);
    bypassButton.setVisible(true);

    componentDropdown.setSelectedId(componentIndex);

}

void PostProcessingGUI::updateState()
{
    for (auto& it : mComponents)
    {
        it.component->updateState();
    }
}

void PostProcessingGUI::createNewComponent(unsigned int componentID)
{
    CLAssert(componentDropdown.getNumItems() - numMenuItems == mComponents.size());

    namespace CLID = CamdenLabs::ComponentIDs;
    using Type = CLID::PostProcessingType;
    auto componentType = static_cast<Type>(componentID);

    ++componentIndex;

    auto newGUI = listener()->manager()->createComponent(this->mID, componentType);

    mComponents.push_back({ std::move(newGUI), componentIndex, false });
    addChildComponent(*mComponents.back().component);

    auto text = componentDropdown.getItemText(componentDropdown.indexOfItemId(componentID + addComponentMenuOffset));

    componentDropdown.addItem(text, componentIndex);
    deleteButton.setVisible(true);
    bypassButton.setVisible(true);
    
    componentDropdown.setSelectedId(componentIndex);
}

void PostProcessingGUI::deleteButtonClicked()
{
    auto componentID = componentDropdown.getSelectedId();
    if (componentID == 0)
    {
        CLAssert(0);
        return;
    }
#if CL_DEBUG
    auto ptr = findComponent(componentID)->component.get();
    CLAssert(ptr == activeComponent.get());
#endif

    deleteComponent(componentID);
}

void PostProcessingGUI::deleteAllComponents()
{
    mComponents.clear();

    activeComponent = nullptr;

    std::vector<std::pair<juce::String, int>> itemList;

    regenerateList(itemList);

    componentIndex = 0;

    deleteButton.setVisible(false);
    bypassButton.setVisible(false);
    repaint();

    return;
}

void PostProcessingGUI::deleteComponent(unsigned int componentID)
{
    CLAssert(componentDropdown.getNumItems() - numMenuItems == mComponents.size());

    auto compIt = findComponent(componentID);
    auto idToDelete = compIt->component->componentID();

    this->listener()->manager()->deleteComponent(idToDelete);

    mComponents.erase(compIt);
    
    std::vector<std::pair<juce::String, int>> itemList;
    auto deletedIndex = componentDropdown.indexOfItemId(componentID);

    for (int i = 0; i < componentDropdown.getNumItems(); ++i)
    {
        auto dropdownID = componentDropdown.getItemId(i);
        if (i == deletedIndex || dropdownID >= addComponentMenuOffset)
        {
            continue;
        }
        auto text = componentDropdown.getItemText(i);
        itemList.push_back({text, dropdownID});
    }

    // Display whatever now occupies the slot of the deleted item
    int nextIndex = deletedIndex;

    // If the component deleted was the last item on the list, display the previous (instead of next) component. 
    // Note that if the deleted component was the only item on the list, this is not a problem due to the early return below
    if (deletedIndex == componentDropdown.getNumItems() - 1)
    {
        nextIndex = deletedIndex - 1;
    }

    regenerateList(itemList);
    
    if (mComponents.empty())
    {
        activeComponent = nullptr;
        deleteButton.setVisible(false);
        bypassButton.setVisible(false);
        resized();
        return;
    }

    // Display next component on list after deleted one
    int nextID = componentDropdown.getItemId(nextIndex);
    componentDropdown.setSelectedId(nextID);
}

void PostProcessingGUI::bypassButtonClicked()
{
    auto activeID = componentDropdown.getSelectedId();

    auto& isBypassed = findComponent(activeID)->isBypassed;
    isBypassed = !isBypassed;
    activeComponent->listener()->setEnabled(!isBypassed);
    updateBypassButton();
}

void PostProcessingGUI::updateBypassButton()
{
    auto activeID = componentDropdown.getSelectedId();
   
    if (findComponent(activeID)->isBypassed)
    {
        bypassButton.setButtonText("Enable");
        bypassButton.setTooltip("Enable this component");
    }
    else
    {
        bypassButton.setButtonText("Bypass");
        bypassButton.setTooltip("Bypass this component");
    }
}

void PostProcessingGUI::regenerateList(std::vector<std::pair<juce::String, int>> itemList)
{
    componentDropdown.clear();
    componentDropdownPopup->addSubMenu("Add New Component", newComponentPopup);
    for (auto& it : itemList)
    {
        componentDropdown.addItem(it.first, it.second);
    }
    
}

auto PostProcessingGUI::findComponent(int componentID) -> std::vector<ComponentData>::iterator
{
    auto predicate = [componentID](const ComponentData& it) { return (int)it.index == componentID; };
    return std::find_if(mComponents.begin(), mComponents.end(), predicate);
}

auto PostProcessingGUI::findComponent2(int dropdownIndex) -> std::optional<ComponentData>
{
    auto predicate = [dropdownIndex](const ComponentData& it) { return (int)it.index == dropdownIndex; };
    auto it = std::find_if(mComponents.begin(), mComponents.end(), predicate);

    if (it == mComponents.end())
    {
        return std::nullopt;
    }

    return *it;
}


// Popup Window Version
//====================================================================================================================

PostProcessingPopup::PostProcessingPopup()
{
    //window->closeWindowFunction = [&]() { this->closeWindow(); };
}

void PostProcessingPopup::setWindowTitle(const juce::String& title)
{
    windowTitle = title;
    if (window != nullptr)
    {
        window->setTitleBarText(windowTitle.toStdString());
    }
}

void PostProcessingPopup::launch()
{
    if (window == nullptr)
    {
        window = std::make_unique<PopupWindow>(this);
        if (windowTitle.isNotEmpty())
        {
            window->setTitleBarText(windowTitle.toStdString());
        }
    }
    else if (window->isOnDesktop())
    {
        window->showWindow();
        return;
    }

    window->setResizeLimits(350, 180, 500, 250);
    window->setSize(350, 180);
    window->showWindow();
}

void PostProcessingPopup::launch(int screenX, int screenY)
{
    if (window == nullptr)
    {
        window = std::make_unique<PopupWindow>(this);
        if (windowTitle.isNotEmpty())
        {
            window->setTitleBarText(windowTitle.toStdString());
        }
    }
    else if (window->isOnDesktop())
    {
        window->showWindow();
        return;
    }

    window->setResizeLimits(450, 240, 800, 450);
    window->setSize(defaultWidth, defaultHeight);
    window->showWindow(screenX, screenY);
}

void PostProcessingPopup::closeWindow()
{
    window.reset(nullptr);
}


} // namespace CamdenLabs
