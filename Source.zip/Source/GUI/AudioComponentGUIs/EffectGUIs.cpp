/*
  ================================================================================
  *      File                                        EffectGUIs.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/
#if 1
#include "EffectGUIs.h"

#include "AudioComponents/EffectsIMPL.h"
#include "ComponentManager/ComponentID.h"
#include "GUI/ColourScheme.h"
#include "Helpers/Utility.h"

namespace CLID = CamdenLabs::ComponentIDs;

namespace CamdenLabs
{

// Phaser
//==================================================================================

PhaserGUI::PhaserGUI()
{
    for (int i = 0; i < 3; ++i)
    {
        knobs.emplace_back(std::make_unique<Knob>());
        labels.emplace_back(std::make_unique<juce::Label>());
        labels[i]->setJustificationType(juce::Justification::centred);
        addAndMakeVisible(*knobs[i]);
        addAndMakeVisible(*labels[i]);
    }
    labels[0]->setText("Feedback", juce::dontSendNotification);
    labels[1]->setText("Rate", juce::dontSendNotification);
    labels[2]->setText("Depth", juce::dontSendNotification);

    labels.emplace_back(std::make_unique<juce::Label>());
    labels[3]->setText("Wet/Dry", juce::dontSendNotification);
    labels[3]->setJustificationType(juce::Justification::centred);

    addAndMakeVisible(wetDrySlider);
    addAndMakeVisible(*labels[3]);
    wetDrySlider.setTextFromValueFunction([&](double val) { return juce::String(static_cast<int>(val * 100 + 0.5)); });
    wetDrySlider.setValueFromTextFunction([&](const juce::String& text) { return text.getDoubleValue() / 100.0; });
    wetDrySlider.setParameterUnits("%", true);
}

void PhaserGUI::resized()
{
    constexpr float edgeOffset = 0.f;
    constexpr float knobGap = 0.f;
    constexpr float knobWidth = 1.f / 3.f;
    constexpr float knobHeight = 0.6f;
    constexpr float knobY = 0.f;
    constexpr float labelY = 0.6f;

    for (int i = 0; i < 3; ++i)
    {
        auto knobX = edgeOffset + i * (knobGap + knobWidth);
        knobs[i]->setBoundsRelative(knobX, knobY, knobWidth, knobHeight);
        labels[i]->setBoundsRelative (knobX, labelY, knobWidth, 0.15f);
    }
    wetDrySlider.setBoundsRelative(0.2f, 0.8f, 0.8f, 0.15f);
    labels[3]->setBoundsRelative  (0.0f, 0.8f, 0.2f, 0.15f);
}

void PhaserGUI::attachListener()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = Phaser::Parameters;
        switch (it->paramID<Phaser>())
        {
        case Param::Feedback:
            knobs[0]->setAudioParameter(it);
            knobs[0]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Rate:
            knobs[1]->setAudioParameter(it);
            knobs[1]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Depth:
            knobs[2]->setAudioParameter(it);
            knobs[2]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::WetGain:
            wetDrySlider.setAudioParameter(it);
            wetDrySlider.setCallbacks(this->listener(), it->paramID());
            break;
        }
    }
}

void PhaserGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = Phaser::Parameters;
        switch (it->paramID<Phaser>())
        {
        case Param::Feedback:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::Rate:
            knobs[1]->setValue(it->normalizedValue());
            break;

        case Param::Depth:
            knobs[2]->setValue(it->normalizedValue());
            break;

        case Param::WetGain:
            wetDrySlider.setValue(it->normalizedValue());
            break;
        }
    }
}

// Compressor
//==================================================================================

CompressorGUI::CompressorGUI()
{
    for (int i = 0; i < 6; ++i)
    {
        knobs.emplace_back(std::make_unique<Knob>());
        labels.emplace_back(std::make_unique<juce::Label>());
        labels[i]->setJustificationType(juce::Justification::centred);
        addAndMakeVisible(*knobs[i]);
        addAndMakeVisible(*labels[i]);
    }

    labels[0]->setText("Ratio", juce::dontSendNotification);
    labels[1]->setText("Threshold", juce::dontSendNotification);
    labels[2]->setText("Knee", juce::dontSendNotification);
    labels[3]->setText("Attack", juce::dontSendNotification);
    labels[4]->setText("Release", juce::dontSendNotification);
    labels[5]->setText("Gain", juce::dontSendNotification);

    knobs[1]->setParameterUnits("dB");
    knobs[3]->setParameterUnits("ms");
    knobs[4]->setParameterUnits("ms");

    auto min = Compressor::minGain;
    auto max = Compressor::maxGain;
    knobs[5]->setTextFromValueFunction([min, max](double val) 
    { 
        double denorm = min + (max - min) * val;
        return juce::String(Utility::amplitudeTodB(denorm), 2);
    });

    knobs[5]->setValueFromTextFunction([min, max](juce::String text) 
    { 
        double val = Utility::dBtoAmplitude(text.getDoubleValue());
        return (val - min) / (max - min); 
    });

    knobs[5]->setParameterUnits("dB");

    for (auto& it : labels)
    {
        it->setJustificationType(juce::Justification::centred);
    }
}

void CompressorGUI::resized()
{
    constexpr float edgeOffset = 0.f;
    constexpr float knobGap = 0.f;
    constexpr float knobWidth = 1.f / 3.f;
    constexpr float knobHeight = 0.4f;


    for (int i = 0; i < 3; ++i)
    {
        auto knobX = edgeOffset + i * (knobGap + knobWidth);
        constexpr float knobY = 0.f;
        constexpr float labelY = knobHeight;
        knobs[i]->setBoundsRelative(knobX, knobY, knobWidth, knobHeight);
        labels[i]->setBoundsRelative(knobX, labelY, knobWidth, 0.1f);
    }
    for (int i = 3; i < 6; ++i)
    {
        auto knobX = edgeOffset + (i - 3.f) * (knobGap + knobWidth);
        constexpr float knobY = 0.5f;
        constexpr float labelY = knobY + knobHeight;
        knobs[i]->setBoundsRelative(knobX, knobY, knobWidth, knobHeight);
        labels[i]->setBoundsRelative(knobX, labelY, knobWidth, 0.1f);
    }
}

void CompressorGUI::attachListener()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = Compressor::Parameters;
        switch (it->paramID<Compressor>())
        {
        case Param::Ratio:
            knobs[0]->setAudioParameter(it);
            knobs[0]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Threshold:
            knobs[1]->setAudioParameter(it);
            knobs[1]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Knee:
            knobs[2]->setAudioParameter(it);
            knobs[2]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Attack:
            knobs[3]->setAudioParameter(it);
            knobs[3]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Release:
            knobs[4]->setAudioParameter(it);
            knobs[4]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Gain:
            knobs[5]->setAudioParameter(it);
            knobs[5]->setCallbacks(this->listener(), it->paramID());
            break;
        }
    }
}

void CompressorGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = Compressor::Parameters;
        switch (it->paramID<Compressor>())
        {
        case Param::Ratio:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::Threshold:
            knobs[1]->setValue(it->normalizedValue());
            break;

        case Param::Knee:
            knobs[2]->setValue(it->normalizedValue());
            break;

        case Param::Attack:
            knobs[3]->setValue(it->normalizedValue());
            break;

        case Param::Release:
            knobs[4]->setValue(it->normalizedValue());
            break;

        case Param::Gain:
            knobs[5]->setValue(it->normalizedValue());
            break;
        }
    }
}

// Distortion
//==================================================================================

DistortionGUI::DistortionGUI()
{
    KnobComponent::setLabels({ "Drive", "Mix" });

    addAndMakeVisible(hardClipButton);
    hardClipButton.setButtonText("Hard Clip");
    hardClipButton.onClick = [&]() { setMode(Mode::HardClip); };

    addAndMakeVisible(softClipButton);
    softClipButton.setButtonText("Soft Clip");
    softClipButton.onClick = [&]() { setMode(Mode::SoftClip); };

    knobs[0]->setParameterUnits("dB");

    knobs[1]->setParameterUnits("%");
    knobs[1]->setTextFromValueFunction([](double val) { return juce::String(val * 100.0); });
    knobs[1]->setValueFromTextFunction([](juce::String text) { return text.getDoubleValue() / 100.0; });

    setLookAndFeel(&ColourScheme::getInstance());
}

void DistortionGUI::resized()
{
    constexpr float knobWidth = 0.5f;
    constexpr float knobHeight = 0.8f;
    constexpr float knobY = 0.f;
    constexpr float labelY = 0.8f;
    constexpr float labelHeight = 0.15f;
    constexpr float x1 = 0.1f;
    constexpr float x2 = 0.5f;
    constexpr float buttonWidth = 0.15f;
    constexpr float buttonHeight = 0.2f;
    constexpr float buttonX = 0.05f;
    constexpr float buttonY = 0.2f;

    hardClipButton.setBoundsRelative(buttonX, buttonY, buttonWidth, buttonHeight);
    softClipButton.setBoundsRelative(buttonX, buttonY + buttonHeight + 0.1f, buttonWidth, buttonHeight);

    knobs[0]->setBoundsRelative(x1, knobY, knobWidth, knobHeight);
    knobs[1]->setBoundsRelative(x2, knobY, knobWidth, knobHeight);

    labels[0]->setBoundsRelative(x1 , labelY, knobWidth, labelHeight);
    labels[1]->setBoundsRelative(x2, labelY, knobWidth, labelHeight);
}

void DistortionGUI::attachListener()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = Distortion::Parameters;
        switch (it->paramID<Distortion>())
        {
        case Param::Type:
            it->toBool() ? setMode(Mode::HardClip) : setMode(Mode::SoftClip);
            break;

        case Param::Drive:
            knobs[0]->setAudioParameter(it);
            knobs[0]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Mix:
            knobs[1]->setAudioParameter(it);
            knobs[1]->setCallbacks(this->listener(), it->paramID());
            break;
        }
    }
}

void DistortionGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = Distortion::Parameters;

        switch (it->paramID<Distortion>())
        {
        case Param::Type:
            it->toBool() ? setMode(Mode::HardClip) : setMode(Mode::SoftClip);
            break;

        case Param::Drive:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::Mix:
            knobs[1]->setValue(it->normalizedValue());
            break;
        }
    }
}

void DistortionGUI::setMode(Mode mode)
{
    if (mode == mMode)
    {
        return;
    }
    mMode = mode;

    const auto enableButton = [](juce::TextButton& button) 
    {
        button.setColour(juce::TextButton::ColourIds::buttonColourId, Colours::darkButtonColour);
        button.setColour(juce::TextButton::ColourIds::textColourOffId, Colours::textColour);
    };

    const auto disableButton = [](juce::TextButton& button)
    {
        button.setColour(juce::TextButton::ColourIds::buttonColourId, Colours::buttonDisabledColour);
        button.setColour(juce::TextButton::ColourIds::textColourOffId, Colours::textDisabledColour);
    };

    const auto parameterIndex = static_cast<unsigned>(CamdenLabs::Distortion::Parameters::Type);


    if (mode == HardClip)
    {
        enableButton(hardClipButton);
        disableButton(softClipButton);
        mListener->setParameterValue(parameterIndex, 1.0);
    }
    else
    {
        enableButton(softClipButton);
        disableButton(hardClipButton);
        mListener->setParameterValue(parameterIndex, 0.0);
    }
    repaint();
}

// Bit Crusher
//==================================================================================

BitCrusherGUI::BitCrusherGUI()
{
    KnobComponent::setLabels({ "Drive", "Mix" });

    knobs[0]->setParameterUnits("dB");

    knobs[1]->setParameterUnits("%");
    knobs[1]->setTextFromValueFunction([](double val) { return juce::String(val * 100.0); });
    knobs[1]->setValueFromTextFunction([](juce::String text) { return text.getDoubleValue() / 100.0; });
}

void BitCrusherGUI::attachListener()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = BitCrusher::Parameters;
        switch (it->paramID<BitCrusher>())
        {
        case Param::Drive:
            knobs[0]->setAudioParameter(it);
            knobs[0]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Mix:
            knobs[1]->setAudioParameter(it);
            knobs[1]->setCallbacks(this->listener(), it->paramID());
            break;
        }
    }
}

void BitCrusherGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = BitCrusher::Parameters;

        switch (it->paramID<BitCrusher>())
        {
        case Param::Drive:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::Mix:
            knobs[1]->setValue(it->normalizedValue());
            break;
        }
    }
}

// Chopper
//==================================================================================

ChopperGUI::ChopperGUI()
{
    KnobComponent::setLabels({"Rate", "Duty Cycle", "Depth", "Smoothing"});

    knobs[0]->setParameterUnits("Hz");

    knobs[1]->setParameterUnits("%");
    knobs[1]->setTextFromValueFunction([](double val) { return juce::String(val * 100.0); });
    knobs[1]->setValueFromTextFunction([](juce::String text) { return text.getDoubleValue() / 100.0; });

    knobs[2]->setParameterUnits("%");
    knobs[2]->setTextFromValueFunction([](double val) { return juce::String(val * 100.0); });
    knobs[2]->setValueFromTextFunction([](juce::String text) { return text.getDoubleValue() / 100.0; });


    knobs[3]->setParameterUnits("%");
}


void ChopperGUI::attachListener()
{   
    for (auto& it : mListener->getParameters())
    {
        using Param = Chopper::Parameters;

        switch (it->paramID<Chopper>())
        {
        case Param::Rate:
            knobs[0]->setAudioParameter(it);
            knobs[0]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::DutyCycle:
            knobs[1]->setAudioParameter(it);
            knobs[1]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Depth:
            knobs[2]->setAudioParameter(it);
            knobs[2]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Smoothing:
            knobs[3]->setAudioParameter(it);
            knobs[3]->setCallbacks(this->listener(), it->paramID());
            break;
        }
    }
}

void ChopperGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = Chopper::Parameters;

        switch (it->paramID<Chopper>())
        {
        case Param::Rate:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::DutyCycle:
            knobs[1]->setValue(it->normalizedValue());
            break;

        case Param::Depth:
            knobs[2]->setValue(it->normalizedValue());
        
        case Param::Smoothing:
            knobs[3]->setValue(it->normalizedValue());
            break;
        }
    }
}


// Expander
//==================================================================================

ExpanderGUI::ExpanderGUI()
{
    KnobComponent::setLabels({ "Size", "Mix" });

    knobs[1]->setParameterUnits("%");
    knobs[1]->setTextFromValueFunction([](double val) { return juce::String(val * 100.0); });
    knobs[1]->setValueFromTextFunction([](juce::String text) { return text.getDoubleValue() / 100.0; });
}


void ExpanderGUI::attachListener()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = Expander::Parameters;
        switch (it->paramID<Expander>())
        {
        case Param::Size:
            knobs[0]->setAudioParameter(it);
            knobs[0]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Mix:
            knobs[1]->setAudioParameter(it);
            knobs[1]->setCallbacks(this->listener(), it->paramID());
            break;
        }
    }
}

void ExpanderGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = Expander::Parameters;

        switch (it->paramID<Expander>())
        {
        case Param::Size:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::Mix:
            knobs[1]->setValue(it->normalizedValue());
            break;
        }
    }
}

// Chorus
//==================================================================================

ChorusGUI::ChorusGUI()
{
    KnobComponent::setLabels({ "Rate", "Depth", "Mix"});

    knobs[0]->setParameterUnits("Hz");

    knobs[1]->setParameterUnits("%");
    knobs[1]->setTextFromValueFunction([](double val) { return juce::String(val * 100.0); });
    knobs[1]->setValueFromTextFunction([](juce::String text) { return text.getDoubleValue() / 100.0; });

    knobs[2]->setParameterUnits("%");
    knobs[2]->setTextFromValueFunction([](double val) { return juce::String(val * 100.0); });
    knobs[2]->setValueFromTextFunction([](juce::String text) { return text.getDoubleValue() / 100.0; });
}


void ChorusGUI::attachListener()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = Chorus::Parameters;
        switch (it->paramID<Chorus>())
        {
        case Param::Rate:
            knobs[0]->setAudioParameter(it);
            knobs[0]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Depth:
            knobs[1]->setAudioParameter(it);
            knobs[1]->setCallbacks(this->listener(), it->paramID());
            break;

        case Param::Mix:
            knobs[2]->setAudioParameter(it);
            knobs[2]->setCallbacks(this->listener(), it->paramID());
            break;
        }
    }
}

void ChorusGUI::updateState()
{
    for(auto& it : mListener->getParameters())
    {
        using Param = Chorus::Parameters;

        switch (it->paramID<Chorus>())
        {
        case Param::Rate:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::Depth:
            knobs[1]->setValue(it->normalizedValue());
            break;

        case Param::Mix:
            knobs[2]->setValue(it->normalizedValue());
            break;
        }
    }
}


} // namespace CamdenLabs
#endif