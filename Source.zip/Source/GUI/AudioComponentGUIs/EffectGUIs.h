/*
  ================================================================================
  *      File                                          EffectGUIs.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#if 1
#include "CLHeader.h"

#include "GUI/GUIComponent.h"
#include "GUI/Widgets/KnobComponent.h"
#include "GUI/Widgets/KnobsAndSliders/Slider.h"

namespace CamdenLabs
{

class PhaserGUI : public CamdenLabs::GUIComponent
{
public:

    PhaserGUI();

    void resized() override;
    void attachListener() override;
    void updateState() override;

private:
    std::vector<std::unique_ptr<Knob>> knobs;
    std::vector<std::unique_ptr<juce::Label>> labels;

    Slider wetDrySlider;
};

class CompressorGUI : public CamdenLabs::GUIComponent
{
public:

    CompressorGUI();

    void resized() override;
    void attachListener() override;
    void updateState() override;

private:

    std::vector<std::unique_ptr<Knob>> knobs;
    std::vector<std::unique_ptr<juce::Label>> labels;

};

class DistortionGUI : public CamdenLabs::KnobComponent<2>
{
public:

    DistortionGUI();

    void resized() override;

    void attachListener() override;

    void updateState() override;

private:

    enum Mode : bool
    {
        SoftClip = false,
        HardClip = true
    };

    void setMode(Mode mode);

    Mode mMode{ SoftClip };

    juce::TextButton hardClipButton;
    juce::TextButton softClipButton;

};

class BitCrusherGUI : public CamdenLabs::KnobComponent<2>
{
public:

    BitCrusherGUI();

    void attachListener() override;

    void updateState() override;

};

class ChopperGUI : public CamdenLabs::KnobComponent<4>
{
public:

    ChopperGUI();

    void attachListener() override;

    void updateState() override;

};



class ExpanderGUI : public CamdenLabs::KnobComponent<2>
{
public:

    ExpanderGUI();

    void attachListener() override;

    void updateState() override;

};

class ChorusGUI : public CamdenLabs::KnobComponent<3>
{
public:

    ChorusGUI();

    void attachListener() override;

    void updateState() override;

};

} // namespace CamdenLabs

#endif