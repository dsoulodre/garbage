/*
  ================================================================================
  *      File                                          FilterGUIs.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/
#if 1
#pragma once
#include "CLHeader.h"
#include "GUI/Widgets/KnobComponent.h"
#include "GUI/GUIComponent.h" 

namespace CamdenLabs
{

class LowPassGUI : public KnobComponent<2>
{
public:
    LowPassGUI();
    void attachListener() override;

    void updateState() override;
};

class HighPassGUI : public KnobComponent<2>
{
public:
    HighPassGUI();
    void attachListener() override;

    void updateState() override;
};

class PeakGUI : public KnobComponent<3>
{
public:
    PeakGUI();
    void attachListener() override;
    void updateState() override;
};

class BandPassGUI : public KnobComponent<2>
{
public:
    BandPassGUI();
    void attachListener() override;
    void updateState() override;
};

class NotchGUI : public KnobComponent<2>
{
public:
    NotchGUI();
    void attachListener() override;
    void updateState() override;
};

class LowShelfGUI : public KnobComponent<3>
{
public:
    LowShelfGUI();
    void attachListener() override;
    void updateState() override;
};

class HighShelfGUI : public KnobComponent<3>
{
public:
    HighShelfGUI();
    void attachListener() override;
    void updateState() override;
};

class AllPassGUI : public KnobComponent<1>
{
public:
    AllPassGUI();
    void attachListener() override;
    void updateState() override;
};

class CombFilterGUI : public KnobComponent<3>
{
public:
    CombFilterGUI();
    void attachListener() override;
    void updateState() override;
};



} //namespace CamdenLabs

#endif