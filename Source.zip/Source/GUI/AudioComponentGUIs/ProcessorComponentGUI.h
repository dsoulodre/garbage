/*
  ================================================================================
  *      File                              ProcessorComponentGUIs.h              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#pragma once
#include "CLHeader.h"
#include "GUI/GUIComponent.h" 
#include "GUI/Widgets/PopupWindow.h"

#include "JuceHeader.h"
#include <vector>
#include <memory>
#include <optional>

namespace CamdenLabs
{

class PostProcessingGUI : public CamdenLabs::GUIComponent
{
public:

    PostProcessingGUI();

    ~PostProcessingGUI();

    void resized() override;

    void attachListener() override;

    void updateState() override;

    void addComponent(std::unique_ptr<GUIComponent>&& newComponent);

    void deleteAllComponents();

protected:

    struct ComponentData
    {
        std::shared_ptr<GUIComponent> component{ nullptr };
        unsigned index{ 0 };
        bool isBypassed{ false };
    };

    void componentSelected();
    void createNewComponent(unsigned int componentID);

    void deleteButtonClicked();
    void deleteComponent(unsigned int componentID);

    void bypassButtonClicked();
    void updateBypassButton();

    auto findComponent(int componentID) -> std::vector<ComponentData>::iterator;

    auto findComponent2(int dropdownID) -> std::optional<ComponentData>;

   //auto findComponent(int componentID) -> std::vector<std::pair<std::shared_ptr<GUIComponent>, int>>::iterator;
   //auto findBypass(int componentID) -> std::vector<std::pair<bool, int>>::iterator;

    void regenerateList(std::vector<std::pair<juce::String, int>> itemList);


    juce::ComboBox componentDropdown;
    juce::PopupMenu* componentDropdownPopup;
    juce::PopupMenu newComponentPopup;

    unsigned int componentIndex{ 0 };

    juce::TextButton deleteButton;
    juce::TextButton bypassButton;
    
    //std::vector<std::pair<bool, int>> componentIsBypassed;
    

    std::vector<ComponentData> mComponents;

   // std::vector<std::pair<std::shared_ptr<GUIComponent>, int>> components;
    std::shared_ptr<GUIComponent> activeComponent{ nullptr };

    // Number of items that are NOT user created components
    int numMenuItems{ 0 };
};

// Popup window version for saving space 
class PostProcessingPopup : public PostProcessingGUI
{
public:

    PostProcessingPopup();
    void setWindowTitle(const juce::String& title);
    void launch();
    void launch(int screenX, int screenY);
    void closeWindow();

    static constexpr int defaultWidth = 500;
    static constexpr int defaultHeight = 300;

private:

    std::unique_ptr<CamdenLabs::PopupWindow> window{ nullptr };
    juce::String windowTitle;
};


} // namespace CamdenLabs

