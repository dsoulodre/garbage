/*
  ================================================================================
  *      File                                        FilterGUIs.cpp              *
  *      Project                             Engine Sound Synthesis              *
  *      Company                                        Camden Labs              *
  *                        2022-2023, All rights reserved                        *
  ================================================================================
*/

#include "FilterGUIs.h"
#include "AudioComponents/FilterIMPL.h"
#include "AudioComponents/EffectsIMPL.h"

#if 1
namespace CLID = CamdenLabs::ComponentIDs;

namespace CamdenLabs
{

// Low Pass
//==================================================================================
LowPassGUI::LowPassGUI()
{
    setLabels({ "Cutoff", "Resonance" });
    knobs[0]->setParameterName(labels[0]->getText().toStdString());
    knobs[1]->setParameterName(labels[1]->getText().toStdString());

    knobs[0]->setParameterUnits("Hz");
}

void LowPassGUI::attachListener()
{
    knobs[0]->setCallbacks(this->listener(), LowPassFilter::Parameters::Cutoff);
    knobs[1]->setCallbacks(this->listener(), LowPassFilter::Parameters::Resonance);    
    //knobs[0]->automation.setCallbacks(this->listener(), LowPassFilter::Parameters::Cutoff);
    //knobs[1]->automation.setCallbacks(this->listener(), LowPassFilter::Parameters::Resonance);
    for (auto& it : mListener->getParameters())
    {
        using Param = LowPassFilter::Parameters;
        switch (it->paramID<LowPassFilter>())
        {
        case Param::Cutoff:
            knobs[0]->setAudioParameter(it);
            break;

        case Param::Resonance:
            knobs[1]->setAudioParameter(it);
            break;
        }
    }
}

void LowPassGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = LowPassFilter::Parameters;
        //uint64_t fullID = CLID::makeParameterID(this->componentID(), it->paramID());
        switch (it->paramID<LowPassFilter>())
        {
        case Param::Cutoff:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::Resonance:
            knobs[1]->setValue(it->normalizedValue());
            break;
        }
    }
}


// High Pass
//==================================================================================

HighPassGUI::HighPassGUI()
{
    setLabels({ "Cutoff", "Resonance" });
    knobs[0]->setParameterName(labels[0]->getText().toStdString());
    knobs[1]->setParameterName(labels[1]->getText().toStdString());

    knobs[0]->setParameterUnits("Hz");
}

void HighPassGUI::attachListener()
{
    knobs[0]->setCallbacks(this->listener(), HighPassFilter::Parameters::Cutoff);
    knobs[1]->setCallbacks(this->listener(), HighPassFilter::Parameters::Resonance);
    //knobs[0]->automation.setCallbacks(this->listener(), HighPassFilter::Parameters::Cutoff);
    //knobs[1]->automation.setCallbacks(this->listener(), HighPassFilter::Parameters::Resonance);

    for (auto& it : mListener->getParameters())
    {
        using Param = HighPassFilter::Parameters;
        switch (it->paramID<HighPassFilter>())
        {
        case Param::Cutoff:
            knobs[0]->setAudioParameter(it);
            break;

        case Param::Resonance:
            knobs[1]->setAudioParameter(it);
            break;
        }
    }
}

void HighPassGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = HighPassFilter::Parameters;
        //uint64_t fullID = CLID::makeParameterID(this->componentID(), it->paramID());
        switch (it->paramID<HighPassFilter>())
        {
        case Param::Cutoff:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::Resonance:
            knobs[1]->setValue(it->normalizedValue());
            break;
        }
    }
}


// Peak
//==================================================================================

PeakGUI::PeakGUI()
{
    setLabels({ "Frequency", "Q", "Gain" });
    knobs[0]->setParameterName(labels[0]->getText().toStdString());
    knobs[1]->setParameterName(labels[1]->getText().toStdString());
    knobs[2]->setParameterName(labels[2]->getText().toStdString());

    knobs[0]->setParameterUnits("Hz");
    knobs[2]->setParameterUnits("dB");
    
}

void PeakGUI::attachListener()
{
    knobs[0]->setCallbacks(this->listener(), PeakFilter::Parameters::Frequency);
    knobs[1]->setCallbacks(this->listener(), PeakFilter::Parameters::FilterQ);
    knobs[2]->setCallbacks(this->listener(), PeakFilter::Parameters::Gain);
    //knobs[0]->automation.setCallbacks(this->listener(), PeakFilter::Parameters::Frequency);
    //knobs[1]->automation.setCallbacks(this->listener(), PeakFilter::Parameters::FilterQ);
    //knobs[2]->automation.setCallbacks(this->listener(), PeakFilter::Parameters::Gain);

    for (auto& it : mListener->getParameters())
    {
        using Param = PeakFilter::Parameters;
        switch (it->paramID<PeakFilter>())
        {
        case Param::Frequency:
            knobs[0]->setAudioParameter(it);
            break;

        case Param::FilterQ:
            knobs[1]->setAudioParameter(it);
            break;

        case Param::Gain:
            knobs[2]->setAudioParameter(it);
            break;
        }
    }
}

void PeakGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = PeakFilter::Parameters;
        //uint64_t fullID = CLID::makeParameterID(this->componentID(), it->paramID());
        switch (it->paramID<PeakFilter>())
        {
        case Param::Frequency:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::FilterQ:
            knobs[1]->setValue(it->normalizedValue());
            break;

        case Param::Gain:
            knobs[2]->setValue(it->normalizedValue());
            break;
        }
    }
}


// Band Pass
//==================================================================================

BandPassGUI::BandPassGUI()
{
    setLabels({ "Frequency", "Bandwidth" });
    knobs[0]->setParameterName(labels[0]->getText().toStdString());
    knobs[1]->setParameterName(labels[1]->getText().toStdString());

    knobs[0]->setParameterUnits("Hz");
    knobs[1]->setParameterUnits("Octaves");
}

void BandPassGUI::attachListener()
{
    knobs[0]->setCallbacks(this->listener(), BandPassFilter::Parameters::Frequency);
    knobs[1]->setCallbacks(this->listener(), BandPassFilter::Parameters::BandWidth);
    //knobs[0]->automation.setCallbacks(this->listener(), BandPassFilter::Parameters::Frequency);
    //knobs[1]->automation.setCallbacks(this->listener(), BandPassFilter::Parameters::BandWidth);


    for (auto& it : mListener->getParameters())
    {
        using Param = BandPassFilter::Parameters;
        switch (it->paramID<BandPassFilter>())
        {
        case Param::Frequency:
            knobs[0]->setAudioParameter(it);
            break;

        case Param::BandWidth:
            knobs[1]->setAudioParameter(it);
            break;
        }
    }

}

void BandPassGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = BandPassFilter::Parameters;
        //uint64_t fullID = CLID::makeParameterID(this->componentID(), it->paramID());
        switch (it->paramID<BandPassFilter>())
        {
        case Param::Frequency:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::BandWidth:
            knobs[1]->setValue(it->normalizedValue());
            break;
        }
    }
}

// Notch
//==================================================================================

NotchGUI::NotchGUI()
{
    setLabels({ "Frequency", "Bandwidth" });
    knobs[0]->setParameterName(labels[0]->getText().toStdString());
    knobs[1]->setParameterName(labels[1]->getText().toStdString());

    knobs[0]->setParameterUnits("Hz");
    knobs[1]->setParameterUnits("Octaves");
}


void NotchGUI::attachListener()
{
    knobs[0]->setCallbacks(this->listener(), NotchFilter::Parameters::Frequency);
    knobs[1]->setCallbacks(this->listener(), NotchFilter::Parameters::Width);
    //knobs[0]->automation.setCallbacks(this->listener(), NotchFilter::Parameters::Frequency);
    //knobs[1]->automation.setCallbacks(this->listener(), NotchFilter::Parameters::Width);

    for (auto& it : mListener->getParameters())
    {
        using Param = NotchFilter::Parameters;
        switch (it->paramID<NotchFilter>())
        {
        case Param::Frequency:
            knobs[0]->setAudioParameter(it);
            break;

        case Param::Width:
            knobs[1]->setAudioParameter(it);
            break;
        }
    }
}

void NotchGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = NotchFilter::Parameters;
        //uint64_t fullID = CLID::makeParameterID(this->componentID(), it->paramID());
        switch (it->paramID<NotchFilter>())
        {
        case Param::Frequency:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::Width:
            knobs[1]->setValue(it->normalizedValue());
            break;
        }
    }
}

// Low Shelf
//==================================================================================

LowShelfGUI::LowShelfGUI()
{
    setLabels({ "Frequency", "Slope", "Gain" });
    knobs[0]->setParameterName(labels[0]->getText().toStdString());
    knobs[1]->setParameterName(labels[1]->getText().toStdString());
    knobs[2]->setParameterName(labels[2]->getText().toStdString());

    knobs[0]->setParameterUnits("Hz");
    knobs[1]->setParameterUnits("dB/oct");
    knobs[2]->setParameterUnits("dB");

    knobs[1]->setTextFromValueFunction( [](double val) { return juce::String(0.1 + (12.0 - 0.1) * val); } );
    knobs[1]->setValueFromTextFunction([](juce::String text) { return (text.getDoubleValue() - 0.1) / (12.0 - 0.1); });
}

void LowShelfGUI::attachListener()
{
    knobs[0]->setCallbacks(this->listener(), LowShelfFilter::Parameters::Frequency);
    knobs[1]->setCallbacks(this->listener(), LowShelfFilter::Parameters::Slope);
    knobs[2]->setCallbacks(this->listener(), LowShelfFilter::Parameters::Gain);

    for (auto& it : mListener->getParameters())
    {
        using Param = LowShelfFilter::Parameters;
        switch (it->paramID<LowShelfFilter>())
        {
        case Param::Frequency:
            knobs[0]->setAudioParameter(it);
            break;

        case Param::Slope:
            knobs[1]->setAudioParameter(it);
            break;

        case Param::Gain:
            knobs[2]->setAudioParameter(it);
            break;
        }
    }

}

void LowShelfGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = LowShelfFilter::Parameters;
        //uint64_t fullID = CLID::makeParameterID(this->componentID(), it->paramID());
        switch (it->paramID<LowShelfFilter>())
        {
        case Param::Frequency:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::Slope:
            knobs[1]->setValue(it->normalizedValue());
            break;

        case Param::Gain:
            knobs[2]->setValue(it->normalizedValue());
            break;
        }
    }
}


// High Shelf
//==================================================================================

HighShelfGUI::HighShelfGUI()
{
    setLabels({ "Frequency", "Slope", "Gain" });
    knobs[0]->setParameterName(labels[0]->getText().toStdString());
    knobs[1]->setParameterName(labels[1]->getText().toStdString());
    knobs[2]->setParameterName(labels[2]->getText().toStdString());

    knobs[0]->setParameterUnits("Hz");
    knobs[1]->setParameterUnits("dB/oct");
    knobs[2]->setParameterUnits("dB");

    knobs[1]->setTextFromValueFunction([](double val) { return juce::String(0.1 + (12.0 - 0.1) * val); });
    knobs[1]->setValueFromTextFunction([](juce::String text) { return (text.getDoubleValue() - 0.1) / (12.0 - 0.1); });
}

void HighShelfGUI::attachListener()
{
    knobs[0]->setCallbacks(this->listener(), HighShelfFilter::Parameters::Frequency);
    knobs[1]->setCallbacks(this->listener(), HighShelfFilter::Parameters::Slope);
    knobs[2]->setCallbacks(this->listener(), HighShelfFilter::Parameters::Gain);
    //knobs[0]->automation.setCallbacks(this->listener(), HighShelfFilter::Parameters::Frequency);
    //knobs[1]->automation.setCallbacks(this->listener(), HighShelfFilter::Parameters::Slope);
    //knobs[2]->automation.setCallbacks(this->listener(), HighShelfFilter::Parameters::Gain);

    for (auto& it : mListener->getParameters())
    {
        using Param = HighShelfFilter::Parameters;
        switch (it->paramID<HighShelfFilter>())
        {
        case Param::Frequency:
            knobs[0]->setAudioParameter(it);
            break;

        case Param::Slope:
            knobs[1]->setAudioParameter(it);
            break;

        case Param::Gain:
            knobs[2]->setAudioParameter(it);
            break;
        }
    }

}

void HighShelfGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = HighShelfFilter::Parameters;
        //uint64_t fullID = CLID::makeParameterID(this->componentID(), it->paramID());
        switch (it->paramID<HighShelfFilter>())
        {
        case Param::Frequency:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::Slope:
            knobs[1]->setValue(it->normalizedValue());
            break;

        case Param::Gain:
            knobs[2]->setValue(it->normalizedValue());
            break;
        }
    }
}

// All Pass
//==================================================================================

AllPassGUI::AllPassGUI()
{
    setLabels({ "Gain" });
    knobs[0]->setParameterName(labels[0]->getText().toStdString());
}

void AllPassGUI::attachListener()
{
    knobs[0]->setCallbacks(this->listener(), AllPassFilter::Parameters::Gain);
    //knobs[0]->automation.setCallbacks(this->listener(), AllPassFilter::Parameters::Gain);
    knobs[0]->setAudioParameter(mListener->getParameters()[0]);
    
}

void AllPassGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = AllPassFilter::Parameters;
        //uint64_t fullID = CLID::makeParameterID(this->componentID(), it->paramID());
        switch (it->paramID<AllPassFilter>())
        {
        case Param::Gain:
            knobs[0]->setValue(it->normalizedValue());
            break;
        }
    }
}

// Comb
//==================================================================================

CombFilterGUI::CombFilterGUI()
{
    setLabels({ "Pitch", "Damping", "Feedback" });
    knobs[0]->setParameterName(labels[0]->getText().toStdString());
    knobs[1]->setParameterName(labels[1]->getText().toStdString());
    knobs[2]->setParameterName(labels[2]->getText().toStdString());
}

void CombFilterGUI::attachListener()
{
    knobs[0]->setCallbacks(this->listener(), CombFilter::Parameters::Pitch);
    knobs[1]->setCallbacks(this->listener(), CombFilter::Parameters::Damping);
    knobs[2]->setCallbacks(this->listener(), CombFilter::Parameters::Feedback);
    //knobs[0]->automation.setCallbacks(this->listener(), CombFilter::Parameters::Pitch);
    //knobs[1]->automation.setCallbacks(this->listener(), CombFilter::Parameters::Damping);
    //knobs[2]->automation.setCallbacks(this->listener(), CombFilter::Parameters::Feedback);

    for (auto& it : mListener->getParameters())
    {
        using Param = CombFilter::Parameters;
        switch (it->paramID<CombFilter>())
        {
        case Param::Pitch:
            knobs[0]->setAudioParameter(it);
            break;

        case Param::Damping:
            knobs[1]->setAudioParameter(it);
            break;

        case Param::Feedback:
            knobs[2]->setAudioParameter(it);
            break;
        }
    }

}

void CombFilterGUI::updateState()
{
    for (auto& it : mListener->getParameters())
    {
        using Param = CombFilter::Parameters;
        switch (it->paramID<CombFilter>())
        {
        case Param::Pitch:
            knobs[0]->setValue(it->normalizedValue());
            break;

        case Param::Damping:
            knobs[1]->setValue(it->normalizedValue());
            break;

        case Param::Feedback:
            knobs[2]->setValue(it->normalizedValue());
            break;
        }
    }
}


} // namespace CamdenLabs

#endif