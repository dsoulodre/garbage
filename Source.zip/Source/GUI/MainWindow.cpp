/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "GUI/MainWindow.h"
#include "AppMain/JuceCode/AppMain.h"
#include "AppMain/CamdenDSPApp.h"
#include "GUI/ColourScheme.h"

namespace CLColour = CamdenLabs::Colours;
namespace CLID = CamdenLabs::ComponentIDs;

//==============================================================================
CamdenDSPMainWindow::CamdenDSPMainWindow (CamdenDSPAudioProcessor& p)
    :   AudioProcessorEditor (&p), 
        audioProcessor (p),
        tabbedComponent(juce::TabbedButtonBar::Orientation::TabsAtTop),
        mTooltipWindow(this, 600)
{

    juce::LookAndFeel::setDefaultLookAndFeel(&CamdenLabs::ColourScheme::getInstance());

    tabbedComponent.addTab("Stereo", CLColour::backgroundColour, &mStereoProcessing, false);
    tabbedComponent.addTab("L+R", CLColour::backgroundColour, &mMonoProcessing, false);
    tabbedComponent.addTab("Crossover", CLColour::backgroundColour, &mCrossover, false);
    tabbedComponent.addTab("Final", CLColour::backgroundColour, &mPerChannel, false);

    tabbedComponent.setColour(juce::TabbedComponent::ColourIds::backgroundColourId, CLColour::transparent);
    addAndMakeVisible(tabbedComponent);

    addAndMakeVisible(recordButton);
    recordButton.setButtonText("Record");
    recordButton.setColour(juce::TextButton::buttonColourId, juce::Colours::red);
    recordButton.setToggleable(true);
    recordButton.setClickingTogglesState(true);
    recordButton.setColour(juce::TextButton::buttonOnColourId, juce::Colours::darkred);
    recordButton.onClick = [this] { recordButtonClicked(); };

    addAndMakeVisible(dimButton);
    dimButton.setButtonText("Dim");
    dimButton.onClick = [this]() { dimButtonClicked(); };

    addAndMakeVisible(loadPresetButton);
    loadPresetButton.setButtonText("Load Preset");
    loadPresetButton.onClick = [this]() { loadPresetButtonClicked(); };

    addAndMakeVisible(savePresetButton);
    savePresetButton.setButtonText("Save Preset");
    savePresetButton.onClick = [this]() { savePresetButtonClicked(); };

    addAndMakeVisible(presetDropdown);
    presetDropdown.setTextWhenNothingSelected("Presets");
    auto builtInPresetDir = resourceDirectory().getChildFile("Presets/BuiltIn");
    if (builtInPresetDir.isDirectory())
    {
        int id = 1;
        for (auto& name : audioProcessor.camdenDSP.availablePresets())
        {
            presetDropdown.addItem(name, id);
        }
    }
    else
    {
        juce::AlertWindow::showMessageBox(juce::MessageBoxIconType::WarningIcon, "Error", "Could not find built-in preset directory", "OK");
    }

    presetDropdown.onChange = [this]() { presetSelected(); };

    addAndMakeVisible(noiseDropdown);
    noiseDropdown.setTextWhenNothingSelected("Test Output");
    noiseDropdown.addItem("None", 1);
    noiseDropdown.addItem("Tone", 2);
    noiseDropdown.addItem("Noise", 3);
    noiseDropdown.onChange = [this]() { noiseModeSelected(); };
    
    addAndMakeVisible(noiseOutputButton);
    noiseOutputButton.setTooltip("Send noise directly to output, bypassing all processing");
    noiseOutputButton.setToggleable(true);
    noiseOutputButton.onClick = [this]() { noiseModeSelected(); };

    setSize(1200, 600);
    setResizable(true, true);
    resized();
}

CamdenDSPMainWindow::~CamdenDSPMainWindow()
{
}

//==============================================================================
void CamdenDSPMainWindow::paint (juce::Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    g.fillAll (getLookAndFeel().findColour (juce::ResizableWindow::backgroundColourId));

    g.setColour (juce::Colours::white);
    g.setFont (15.0f);

}

void CamdenDSPMainWindow::resized()
{
    constexpr float paddingX = 0.02f;
    constexpr float tabY = 0.05f;

    constexpr float buttonYPad = 0.01;
    constexpr float buttonY = buttonYPad;
    constexpr float buttonW = 0.1f;
    constexpr float buttonH = 2.f * (tabY - buttonYPad);

    constexpr float dropdownX = 0.5f;
    constexpr float dropdownY = 0.025f;

    constexpr float dropdownW = 0.5f - (3.f * buttonW + paddingX);
    constexpr float dropdownH = 0.05f;

    constexpr float recordX = 0.375f;
    constexpr float buttonX = dropdownX + dropdownW;

    tabbedComponent.setBoundsRelative(paddingX, tabY, 1.f - 2.f * paddingX, 1.f - 2.f * tabY);
    recordButton.setBoundsRelative(recordX, buttonY, buttonW, buttonH);
    presetDropdown.setBoundsRelative(dropdownX, dropdownY, dropdownW, dropdownH);
    loadPresetButton.setBoundsRelative(buttonX+ buttonW * 0, buttonY, buttonW, buttonH);
    savePresetButton.setBoundsRelative(buttonX+ buttonW * 1, buttonY, buttonW, buttonH);
    dimButton.setBoundsRelative(buttonX + buttonW * 2, buttonY, buttonW, buttonH);

    constexpr float noiseX = 0.25f;
    constexpr float noiseW = 0.1f;
    noiseDropdown.setBoundsRelative(noiseX, dropdownY, noiseW, dropdownH);
    noiseOutputButton.setBoundsRelative(noiseX + noiseW, dropdownY, 0.05f, 0.05f);
}

void CamdenDSPMainWindow::setSampleRate(double sampleRate)
{
    for (auto& it : mPerChannel.channels)
    {
        it.setSampleRate(sampleRate);
    }
}

void CamdenDSPMainWindow::showErrorMessage(const std::string& message) const
{
    juce::AlertWindow::showMessageBox(juce::MessageBoxIconType::WarningIcon, "Error", message, "OK");
}

auto CamdenDSPMainWindow::resourceDirectory() -> juce::File
{
    return CamdenLabs::CamdenDSP::resourceDirectory();
}

void CamdenDSPMainWindow::updateSpectrumTest()
{
#if 0
    curveTest.showSpectrum(audioProcessor.spectrumBuffer);
#endif
}

void CamdenDSPMainWindow::presetSelected()
{
    int selectedIndex = presetDropdown.getSelectedItemIndex();
    if (selectedIndex < 0 || selectedIndex == currentPresetIndex)
    {
        return;
    }

#if CL_DEBUG
    auto range = audioProcessor.camdenDSP.availablePresets();
    CLAssert(range.end() != std::find(range.begin(), range.end(), presetDropdown.getItemText(selectedIndex).toStdString()));
#endif

    if (audioProcessor.camdenDSP.loadPreset(selectedIndex))
    {
        currentPresetIndex = selectedIndex;
        return;
    }
    else
    {
        showErrorMessage("Could not load preset");
        presetDropdown.setSelectedId(0, juce::dontSendNotification);
    }
}

void CamdenDSPMainWindow::presetInit(juce::File presetDir)
{
    int index = 1;
    for (auto& file : presetDir.findChildFiles(juce::File::TypesOfFileToFind::findFiles, false, "*.xml"))
    {
        if (!file.existsAsFile())
        {
            CLAssert(0);
            continue;
        }
        auto name = file.getFileNameWithoutExtension();
        presetDropdown.addItem(name, index++);
    }
}

void CamdenDSPMainWindow::loadPresetButtonClicked()
{
    juce::FileChooser chooser("Choose preset", juce::File::getSpecialLocation(juce::File::SpecialLocationType::userDesktopDirectory), "*.xml");

    if (!chooser.browseForFileToOpen())
    {
        return;
    }
    auto file = chooser.getResult();
    audioProcessor.camdenDSP.loadPreset(file.getFullPathName().toStdString());
}

void CamdenDSPMainWindow::savePresetButtonClicked()
{
    const auto hasExtension = [](const std::string& str) -> bool
    {
        constexpr size_t count = 4; // character count of ".xml"
        
        return str.substr(str.size() - count, count) == ".xml";
    };

    juce::FileChooser chooser("Save preset", juce::File::getSpecialLocation(juce::File::SpecialLocationType::userDesktopDirectory), "*.xml");
    if (!chooser.browseForFileToSave(true))
    {
        return;
    }
    auto filePath = chooser.getResult().getFullPathName().toStdString();

    {
        auto path = chooser.getResult().getFullPathName().toStdString();
        if (!hasExtension(path))
        {
            path.append(".xml");
        }
        audioProcessor.camdenDSP.savePreset(chooser.getResult().getFullPathName().toStdString());
    }
}

void CamdenDSPMainWindow::dimButtonClicked()
{
    isDimmed = !isDimmed;

    audioProcessor.camdenDSP.setDim(isDimmed);

    if (isDimmed)
    {
        dimButton.setColour(juce::TextButton::ColourIds::buttonColourId, CamdenLabs::Colours::buttonDisabledColour);
        dimButton.setColour(juce::TextButton::ColourIds::textColourOffId, CamdenLabs::Colours::textDisabledColour);
        dimButton.setButtonText("Undim");
    }
    else
    {
        dimButton.setColour(juce::TextButton::ColourIds::buttonColourId, CamdenLabs::Colours::darkButtonColour);
        dimButton.setColour(juce::TextButton::ColourIds::textColourOffId, CamdenLabs::Colours::textColour);
        dimButton.setButtonText("Dim");
        dimButton.setTooltip("Attenuate 20dB");
    }
    repaint();

}

void CamdenDSPMainWindow::noiseModeSelected()
{
    using Mode = CamdenLabs::CamdenDSP::NoiseMode;
    Mode mode;

    switch (noiseDropdown.getSelectedId())
    {
    case 1: // None
        mode = Mode::None;
        break;;

    case 2: // Tone
        mode = Mode::Tone;
        break;

    case 3: // Noise
        mode = Mode::Noise;
        break;

    default:
        return;
    }

    bool directToOutput = noiseOutputButton.getToggleState();

    audioProcessor.camdenDSP.setNoiseMode(mode, directToOutput);
}

void CamdenDSPMainWindow::recordButtonClicked()
{
    static juce::String fileName;
    static juce::File lastLocation = juce::File::getSpecialLocation(juce::File::userDesktopDirectory);

    if (recordButton.getToggleState())
    {
        juce::FileChooser fileBrowser("Choose or create file", lastLocation, "*.wav");
        if (!fileBrowser.browseForFileToSave(true))
        {
            // No file chosen
            recordButton.setToggleState(false, juce::dontSendNotification);
            return;
        }

        auto fileToRecordTo = fileBrowser.getResult();
        fileName = fileToRecordTo.getFileName();

        if (!audioProcessor.startRecording(fileToRecordTo))
        {
            // Couldn't start recording
            recordButton.setToggleState(false, juce::dontSendNotification);
            showErrorMessage("An error occured trying to record, please try again");
            return;
        }

        recordButton.setButtonText("Stop");
    }
    else
    {
        audioProcessor.stopRecording();
        recordButton.setButtonText("Record");
        juce::AlertWindow::showMessageBox(juce::MessageBoxIconType::InfoIcon, "Recorded Successfully", "File saved as " + fileName, "OK");
    }
}
